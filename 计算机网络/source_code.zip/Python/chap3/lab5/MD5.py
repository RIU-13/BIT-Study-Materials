# -*- coding: utf-8 -*-
import hashlib
import sys
import random

def md5value(s: bytes):
    # 计算md5的数据（bytes类型）
    md5 = hashlib.md5()
    md5.update(s)
    return md5.hexdigest()

def main():
    password = sys.argv[1]
    print("the password is: ", password)
    ram = "".join([random.choice("0123456789abcdef") for i in range(32)])
    print("the random number is: ", ram)
    origin_string = password + ram
    print("the origin string: ", origin_string)
    print("the MD5 value is:")
    md5_str = md5value(origin_string.encode())
    print(md5_str)

if __name__ == "__main__":
    main()
