from utils import bytes2BitStr
import time


def checkCRC(data: bytes) -> bool:
    remainder = genRem(data)
    if int.from_bytes(remainder, 'big') == 0:
        return True
    else:
        return False


def genRem(data: bytes):
    crc = 0x0000
    for b in data:
        for i in range(0, 8):
            bit = ((b >> (7 - i) & 1) == 1)
            c15 = ((crc >> 15 & 1) == 1)
            crc <<= 1
            if c15 ^ bit:
                crc ^= 0x1021
    crc &= 0xffff
    return crc.to_bytes(2, 'big')


def encodeCRC(origin_data: bytes, verbose=False, timer=False):
    st, ed = 0, 0
    if timer:
        st = time.time()
    remainder = genRem(origin_data)
    codeword = origin_data + remainder
    if timer:
        ed = time.time()
    if verbose:
        print("待发送的数据信息二进制比特串: ", bytes2BitStr(origin_data))
        print("多项式信息: 0x1021")
        print("CRC校验码: ", bytes2BitStr(remainder))
        print("最终发送的信息: ", bytes2BitStr(codeword))
        print('计算法耗时: %f' % (ed - st))
    return codeword


if __name__ == '__main__':
    # data = bytes.fromhex('ab120000')
    data = bytes(10000)
    res = encodeCRC(data, verbose=True, timer=True)
    print('检查结果: ', checkCRC(res))
