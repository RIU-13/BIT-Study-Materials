from threading import Timer
import time
import queue

class MyTimer(object):
    def __init__(self, interval, function, args=[], kwargs={}):
        self._interval = interval
        self._function = function
        self._args = args
        self._kwargs = kwargs
        self._timer = None
        self._isStarted = False

    def start(self):
        assert not self.isStart()
        self._timer = Timer(self._interval, self._function, self._args, self._kwargs)
        self._isStarted = True
        self._timer.start()

    def isStart(self):
        return self._isStarted

    def cancel(self):
        if self.isStart():
            self._timer.cancel()
        self._isStarted = False

    def restart(self):
        self.cancel()
        self.start()

    def isRunning(self):
        # 判断是否还在运行
        return self._timer.isAlive()


def hello():
    print("hello")


if __name__ == '__main__':
    a = MyTimer(3, hello)
    q = queue.Queue(maxsize=1)
    q.get()



