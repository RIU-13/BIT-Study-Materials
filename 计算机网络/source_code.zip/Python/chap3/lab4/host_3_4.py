import socket

from chap3.lab1.CRC16_LU import *
from chap3.lab1.CRC16_Calculate import *
from utils import *
from chap3.protocols import *
from threading import Thread, Event, Condition
import argparse
from chap3.lab4.timer import MyTimer
import time
import random
import queue
import logging
import os

from utils import bytes2HexStr

event_enable_network_layer = Event()
event_frame_arrival = Event()
event_time_out = Event()
event_ack_time_out = Event()
event_network_layer_ready = Event()

# 接受线程接受的内容
# 要用到生产者 消费者模型
rec_queen = queue.Queue(maxsize=1)
addr_queen = queue.Queue(maxsize=1)

# 总共发出数据的次数
cnt_send = 0
# 总共接受成功的次数
cnt_recieve = 0

# 控制事件选择的条件变量
cond = Condition()


def get_logger(log_name):
    logger = logging.getLogger("threading_eg")
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(log_name)
    fmt = '%(asctime)s - %(name)s - %(processName)s - %(threadName)s - %(levelname)s - %(message)s'
    formatter = logging.Formatter(fmt)
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    return logger


def set_timeout(i):
    # 超时之后触发的回调函数
    if DEBUG:
        return
    # print('timer[%d]' % i, '超时')
    event_time_out.set()
    with cond:
        cond.notify()


def set_ack_timeout():
    if DEBUG:
        return
    event_ack_time_out.set()
    with cond:
        cond.notify()


timers = [MyTimer(TIMEOUT, set_timeout, args=(i,)) for i in range(MAX_SEQ + 1)]
# ACK计时器 如果本地没有数据可供piggyback 则单独发送ACK
ack_timer = MyTimer(TIMEOUT, set_ack_timeout)


def is_between(a, b, c):
    if (a <= b < c) or (c < a <= b) or (b < c < a):
        return True
    else:
        return False


def send_data(frame_num, frame_expected, buffers, s, addr, kind=DATA):
    # 发送数据
    global cnt_send
    cnt_send += 1

    frame = Frame()
    frame.kind = kind
    if kind == DATA:
        frame.info = buffers[frame_num]
    frame.seq = frame_num
    # 相当于成功接受的上一帧
    frame.ack = (frame_expected + MAX_SEQ) % (MAX_SEQ + 1)
    bytes_to_send = frame.genBytes()
    # 在帧尾添加CRC检查码
    bytes_to_send = createCRCLU(bytes_to_send)

    if kind == DATA:
        # 只队DATA进行模拟出错
        if cnt_send % FilterLost == 0:
            # 模拟数据包丢失
            print(genStateLog('数据包丢失', '*'))
        elif cnt_send % FilterError == 0:
            # 模拟发生错误
            # 要先转化为bytearray才能修改
            array = bytearray(bytes_to_send)
            for i in range(10):
                array[i] = random.randint(0, 255)
            bytes_to_send = bytes(array)
            print(genStateLog('数据包出错', '*'))
            s.sendto(bytes_to_send, addr)
        else:
            print(genStateLog('正确发送帧'))
            s.sendto(bytes_to_send, addr)

        timers[frame_num].restart()

        print('第%d帧' % cnt_send)
        print('seq : %d' % frame.seq)
        print('ack : %d' % frame.ack)
        print('data : %s' % bytes2HexStr(bytes_to_send))
    elif kind == ACK:
        print(genStateLog('发送单独ACK'))
        s.sendto(bytes_to_send, addr)
        print('ack : %d' % frame.ack)

    # 此时已经有ACK发送了不用单独的ACK timer
    ack_timer.cancel()


def enable_network_layer():
    event_enable_network_layer.set()
    with cond:
        cond.notify()

def from_network_layer(f):
    # 模拟from_network_layer
    data = f.read(MAX_PKT)
    return data


def to_network_layer(f, data):
    f.write(data)


def frame_arrival(e, cond, s):
    while True:
        try:
            logger.info('开始阻塞等待接收信息')
            rec, addr = s.recvfrom(BUFSIZE)
        except Exception as e:
            # 发送完的时候会使套接字关闭，此时继续监听会抛出异常
            print(e)
            return

        logger.info('成功接收到信息 data : %s' % bytes2HexStr(rec))
        logger.info('准备放入queue')
        # 生产者生产
        rec_queen.put(rec)
        logger.info('成功放入queue')

        e.set()
        with cond:
            logger.info('通知主线程')
            cond.notify()


def event_happen():
    return event_enable_network_layer.is_set() or event_frame_arrival.is_set() or event_time_out.is_set()


def main(host_num, file_path):
    # 对方的地址
    oppo_addr = (LOCAL_IP, HOSTS[host_num ^ 1])
    print('对方地址 : ', oppo_addr)
    
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((LOCAL_IP, HOSTS[host_num]))
    print('本地地址 : ', (LOCAL_IP, HOSTS[host_num]))

    fread = open(file_path, 'rb')
    fwirte = open('copy%d' % host_num, 'wb')

    next_frame_to_send = 0
    ack_expected = 0
    frame_expected = 0

    buffers = [None] * (MAX_SEQ + 1)
    nbuffered = 0

    event_enable_network_layer.set()

    # 开启接受子线程
    thread_reciever = Thread(target=frame_arrival, name='receiver', args=(event_frame_arrival, cond, s))
    thread_reciever.start()

    # 两个程序稍微错开一点
    time.sleep(3 + host_num * 2)

    # 发送是否结束
    is_send_over = False
    # 对方是否全部接收
    is_oppo_recieve_over = False
    # 本地是否接受完毕
    is_recieve_over = False

    with cond:
        while True:
            while not event_happen():
                # 如果没有事件就等待事件
                cond.wait()

            if event_frame_arrival.is_set():
                event_frame_arrival.clear()
                print(genStateLog('接收到帧'))

                # 消费者消费
                rec = rec_queen.get()

                # 检测CRC
                check = checkCRC(rec)
                if check:
                    print('校验通过')
                    # 抛弃CRC校验码
                    rev_frame = Frame.fromData(rec[:-2])
                    print('data : %s' % bytes2HexStr(rec))

                    if rev_frame.kind == DATA:
                        print('数据包类型: DATA')
                        if rev_frame.seq == frame_expected:
                            if rev_frame.info == b'':
                                is_recieve_over = True

                            global cnt_recieve
                            cnt_recieve += 1
                            to_network_layer(fwirte, rev_frame.info)

                            frame_expected = inc(frame_expected)
                            print('成功接收 seq : %d ' % rev_frame.seq)
                            print('共成功接收 %d帧' % cnt_recieve)
                            print('期望的下一帧序号 frame_expected : %d' % frame_expected)
                        else:
                            print('不是所期望接收的帧 seq : %d' % rev_frame.seq)
                            print('frame_expected : %d' % frame_expected)
                    elif rev_frame.kind == ACK:
                        print('数据包类型: ACK')

                    print(ack_expected, rev_frame.ack, next_frame_to_send)

                    # 就算不是frame expected，ACK也可以收缩发送窗口
                    while is_between(ack_expected, rev_frame.ack, next_frame_to_send):
                        # 接收到ACK了，可把发送缓存区的部分清空。同时停止计时器
                        print('对方已成功接收到发送缓存区的 seq : %d 该帧' % ack_expected)
                        nbuffered -= 1
                        timers[ack_expected].cancel()
                        ack_expected = inc(ack_expected)
                        ack_timer.restart()

                    print('ACK已不在发送缓存区范围内 ack : %d' % rev_frame.ack)
                    print('发送缓存区范围 [%d, %d)' % (ack_expected, next_frame_to_send))
                    print('nbuffered : ', nbuffered)

                    if nbuffered == 0 and is_send_over:
                        # 缓冲区为空而且文件已经读完则说明对方全部接受
                        is_oppo_recieve_over = True
                else:
                    print('校验失败')
                    print('frame_expected : %d' % frame_expected)
            if event_enable_network_layer.is_set():
                # 可以进行读取
                buffers[next_frame_to_send] = from_network_layer(fread)
                nbuffered += 1
                send_data(next_frame_to_send, frame_expected, buffers, s, oppo_addr)

                if buffers[next_frame_to_send] == b'':
                    # 之后再也不会进入此事件
                    is_send_over = True
                    event_enable_network_layer.clear()
                    print('数据已经全部放入缓存')

                next_frame_to_send = inc(next_frame_to_send)

                print('nbuffered : ', nbuffered)
            if event_time_out.is_set():
                print(genStateLog('ACK超时'))

                # 计时器超时，重发缓冲区内所有数据包，同时重启计时器
                next_frame_to_send = ack_expected
                for i in range(0, nbuffered):
                    send_data(next_frame_to_send, frame_expected, buffers, s, oppo_addr)
                    next_frame_to_send = inc(next_frame_to_send)

                # 这个放在下面更好，因为重启计时器的中途可能会有timeout事件
                event_time_out.clear()

            if event_ack_time_out.is_set():
                print(genStateLog('等待数据piggyback超时'))
                send_data(0, frame_expected, buffers, s, oppo_addr, kind=ACK)

                event_ack_time_out.clear()

            if not is_send_over:
                if nbuffered < MAX_SEQ:
                    print(genStateLog('缓存区有空余'))
                    event_enable_network_layer.set()
                else:
                    print(genStateLog('缓存区已满'))
                    event_enable_network_layer.clear()

            if is_oppo_recieve_over and is_recieve_over:
                # 接受完并且发送完
                print('本地及对方均收发完毕')
                send_data(0, frame_expected, buffers, s, oppo_addr, kind=ACK)
                break

    fread.close()
    fwirte.close()
    s.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host_num', type=int, required=False, default=0)
    parser.add_argument('--file_path', type=str, required=True, default=0)
    args = parser.parse_args()

    log_name = 'log%d.txt' % args.host_num
    try:
        os.remove(log_name)
    except Exception as e:
        print(e)
    logger = get_logger(log_name)

    print('Host number : %d' % args.host_num)

    main(args.host_num, args.file_path)
