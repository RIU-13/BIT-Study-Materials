from utils import bytes2HexStr, bytes2BitStr
import math

bitFlag = b'\x7e'
ESC = b'\x7d'

def bitStuffing(data: bytes):
    dataBit = bytes2BitStr(data)
    print("帧起始标志: ", bytes2BitStr(bitFlag))
    print("待发送数据为: ", dataBit)
    print("帧结束标志: ", bytes2BitStr(bitFlag))
    flag = 0
    ans = ""
    for i in range(0, len(dataBit)):
        if dataBit[i] == '1':
            flag += 1
        else:
            flag = 0
        ans += dataBit[i]
        if flag == 5:
            ans += '0'
            flag = 0

    # print("比特填充后信息为: ", ans)
    # 把二进制字符串转为为int型之后，再根据长度转化为bytes类型
    dataBitStuffing = int(ans, 2).to_bytes(math.ceil(len(ans) / 8), 'big')
    # 添加帧开始和结束的标志二进制比特串
    dataBitStuffing = bitFlag + dataBitStuffing + bitFlag
    print("比特填充后的发送帧: ", bytes2BitStr(dataBitStuffing))
    return dataBitStuffing

def decodeBitStuffing(data: bytes):
    dataBit = bytes2BitStr(data)
    # print("接收的原始数据为: ", dataBit)
    flag = 0
    ans = ""
    first = True
    if dataBit[0 : 8] == "01111110" and dataBit[-8:] == "01111110":
        dataBit = dataBit[8 : -8]
    # print(dataBit)
    for i in range(0, len(dataBit)):
        if dataBit[i] == '0' and first:
            # 这里目的是删除进行比特填充之后的前导0
            continue
        else:
            first = False
        if flag == 5:
            flag = 0
            continue
        if dataBit[i] == '1':
            flag += 1
        else:
            flag = 0
        ans += dataBit[i]
    print("比特删除后的接收帧为: ", ans)
    # 把二进制字符串转为为int型之后，再根据长度转化为bytes类型
    dataBitStuffingDecode = int(ans, 2).to_bytes(math.ceil(len(ans) / 8), 'big')
    return dataBitStuffingDecode

def byteStuffing(data: bytes):
    dataBit = bytes2BitStr(data)
    print("帧起始标志: ", bytes2BitStr(bitFlag))
    print("待发送数据为: ", dataBit)
    print("帧结束标志: ", bytes2BitStr(bitFlag))
    flag = 0
    dataByteStuffing = b''
    for b in data:
        # print(b, bytes([b]))
        if b == 126 or b == 125:
            dataByteStuffing += ESC
            dataByteStuffing += bytes([b])
        else:
            dataByteStuffing += bytes([b])

    dataByteStuffing = bitFlag + dataByteStuffing + bitFlag
    print("字节填充后的发送帧: ", bytes2BitStr(dataByteStuffing))
    return dataByteStuffing

def decodeByteStuffing(data: bytes):
    data = data[1:-1]
    flag = True
    dataByteStuffingDecode = b''
    for b in data:
        if b == 125 and flag:
            flag = False
            continue
        else:
            dataByteStuffingDecode += bytes([b])
            flag = True

    print("字节删除后的接收帧为: ", bytes2BitStr(dataByteStuffingDecode))
    return dataByteStuffingDecode

if __name__ == '__main__':
    data = bytes.fromhex('ff7e7dff')
    dataBitStuffing = bitStuffing(data)
    rec = decodeBitStuffing(dataBitStuffing)
    dataByteStuffing = byteStuffing(data)
    rec = decodeByteStuffing(dataByteStuffing)