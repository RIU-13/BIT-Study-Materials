# 本次实验UDP使用的协议
import pickle
from collections import namedtuple
from struct import *
from enum import Enum, unique

# 每次读取文件的长度以及放在帧中信息字段的字节数
MAX_PKT = 1024
# socket读取的字节数
BUFSIZE = 2048

LOCAL_IP = '127.0.0.1'

SEND_PORT = 10000
RECEIVER_PORT = 8888

HOSTS = [10245, 11302]

# socket超时限制
TIMEOUT = 5
# DEBUG模式下会忽略timeout事件
DEBUG = False

# 错误模拟参数
FilterError = 13
FilterLost = 10

# kind的种类
DATA = 0
ACK = 1
NAK = 2

MAX_SEQ = 7

# 结构体的形式
# 大端
# unsigned char(kind)
# unsigned int(seq)
# unsigned int(ack)
# unsigned int(length)
# char[MAX_PKT] (info)
STRUCT_FORMAT = '>BIII%ds' % MAX_PKT


# 帧
class Frame:
    def __init__(self, kind=-1, seq=-1, ack=-1, length=-1, info=b''):
        self.kind = kind
        self.seq = seq
        self.ack = ack
        self.info = info
        self.length = length

    @classmethod
    def fromData(cls, data):
        """
        根据接收到的字符串来构构建帧
        会自动删除info中多余的空白符!
        :param data:
        """
        kind, seq, ack, length, info = unpack(STRUCT_FORMAT, data)
        info = info[:length]
        return cls(kind, seq, ack, length, info)

    def genBytes(self) -> bytes:
        """
        根据类中的属性生成待发送的bytes
        会自动计算所发送数据的长度
        :return:
        """
        self.length = len(self.info)
        assert self.kind != -1 and self.seq != -1 and self.ack != -1 and self.length != -1
        bytes_to_send = pack(STRUCT_FORMAT, self.kind, self.seq, self.ack, self.length, self.info)
        return bytes_to_send


def inc(seq):
    if seq < MAX_SEQ:
        return seq + 1
    else:
        return 0

