import socket

from chap3.lab1.CRC16_LU import *
from chap3.protocols import *
from utils import *
import random

from utils import bytes2HexStr


def main():
    cnt = 0

    addr = ('127.0.0.1', RECEIVER_PORT)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(TIMEOUT)

    next_frame_to_send = 0
    frame = Frame()

    file_path = input("输入要传输的文件路径:")
    f = open(file_path, 'rb')
    data = f.read(MAX_PKT)

    while True:
        cnt += 1
        # 装配帧
        frame.info = data
        frame.seq = next_frame_to_send
        frame.kind = DATA
        frame.ack = 0

        # 发送数据
        bytes_to_send = frame.genBytes()

        # 在帧尾添加CRC检查码
        bytes_to_send = createCRCLU(bytes_to_send)

        if cnt % FilterLost == 0:
            # 模拟数据包丢失
            print(genStateLog('数据包丢失', '*'))
        elif cnt % FilterError == 0:
            # 模拟发生错误
            # 要先转化为bytearray才能修改
            array = bytearray(bytes_to_send)
            for i in range(10):
                array[i] = random.randint(0, 255)
            bytes_to_send = bytes(array)

            print(genStateLog('数据包出错', '*'))
            s.sendto(bytes_to_send, addr)
        else:
            print(genStateLog('正确发送帧'))
            s.sendto(bytes_to_send, addr)

        print('seq : %d' % frame.seq)
        print('next_frame_to_send : %d' % next_frame_to_send)
        print('data : %s' % bytes2HexStr(bytes_to_send))

        # 发送结束
        if data == b'':
            print('发送结束')
            break

        # 接收数据:
        print(genStateLog('等待ACK'))
        try:
            rec, addr = s.recvfrom(BUFSIZE)
            print('成功接收ACK')
            rev_frame = Frame.fromData(rec)
            if rev_frame.ack == next_frame_to_send:
                data = f.read(MAX_PKT)
                next_frame_to_send ^= 1
                print('ACK == frame_sended')
                print('对方成功接收 seq = %d 该帧' % rev_frame.ack)
                print('读取下一段文件内容')
                print('next_frame_to_send : %d' % next_frame_to_send)
            else:
                print('ACK != frame_sended')
                print('对方未成功接收 seq = %d 该帧' % next_frame_to_send)
                print('准备重发该帧')
                print('next_frame_to_send : %d' % next_frame_to_send)
        except:
            print(genStateLog('等待超时'))
            print('对方未能成功接收seq : %d该帧' % next_frame_to_send)
            print('准备重发该帧')
            print('next_frame_to_send : %d' % next_frame_to_send)

    s.close()
    f.close()


if __name__ == '__main__':
    main()
