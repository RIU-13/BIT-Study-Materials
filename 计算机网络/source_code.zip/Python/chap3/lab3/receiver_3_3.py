#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import socket
from chap3.lab1.CRC16_Calculate import *
from chap3.protocols import *
from utils import *


def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # 绑定端口:
    s.bind(('127.0.0.1', RECEIVER_PORT))

    # 设置超时
    # s.settimeout(TIMEOUT)

    print('Bind UDP on %d' % RECEIVER_PORT)

    frame_expected = 0
    frame = Frame()

    f = open('copy', 'wb')

    while True:
        # 接收数据:
        rec, addr = s.recvfrom(BUFSIZE)

        print(genStateLog('接收到帧'))

        # 检测CRC
        check = checkCRC(rec)
        if check:
            print('校验通过')

            # 抛弃CRC校验码
            rec = rec[:-2]
            rev_frame = Frame.fromData(rec)

            if rev_frame.seq == frame_expected:
                f.write(rev_frame.info)
                if rev_frame.info == b'':
                    print('接收完毕')
                    break
                frame_expected ^= 1

                print('成功接收 seq : %d ' % rev_frame.seq)
                print('期望的下一帧序号 frame_expected : %d' % frame_expected)
        else:
            print('校验失败')

        frame.ack = frame_expected ^ 1
        frame.kind = ACK
        frame.seq = frame.ack

        # 发送数据
        print(genStateLog('发送确认帧'))
        print('ack : %d' % frame.ack)
        print('seq : %d' % frame.seq)
        bytes_to_send = frame.genBytes()
        s.sendto(bytes_to_send, addr)

    s.close()
    f.close()


if __name__ == '__main__':
    main()
