from scapy.layers.inet import TCP

from utils import bytes2BitStr, bytes2HexStr
from scapy.all import *
import ctypes

tcpSeg = "4500008441d3400080060000c0a8010f70031b2215912c22ccb0d64e8499b5f6501802034d53000011425047115b65a85ced05f011f8fef4e584d805d1b3a703a29dcb37617422589dc7816449d98b5b9b7113e085e5cee678cd6c530198f87e7917ef2d4781f173126dc17400f89acb9005ded3b2eba5a53746fae19ca181c2e422a5b8"
sourceIP = 'c0a8010f'
destIP = '70031b22'
zeros = '00'

tcpSeg = bytes.fromhex(tcpSeg)

# 校验位清0
tcpSeg = bytearray(tcpSeg)
# tcpSeg[16] = tcpSeg[17] = 0
tcpSeg = bytes(tcpSeg)

tcpPkt = TCP(tcpSeg)
print('TCP包内容如下:')
tcpPkt.show()


sourceIP = bytes.fromhex(sourceIP)
destIP = bytes.fromhex(destIP)
zeros = bytes.fromhex(zeros)

tcpProNum = 6
protocol = tcpProNum.to_bytes(length=1, byteorder='big')

tcpSegLen = len(tcpSeg)
# print(tcpSegLen)
tcpSegLen = tcpSegLen.to_bytes(length=2, byteorder='big')

psdHeader = sourceIP + destIP + zeros + protocol + tcpSegLen
print('伪首部内容如下:')
print('源IP地址: ', bytes2HexStr(sourceIP))
print('目的IP地址: ', bytes2HexStr(destIP))
print('0填充:', bytes2HexStr(zeros))
print('协议号: ', bytes2HexStr(protocol))
print('tcp包长度: ', bytes2HexStr(tcpSegLen))


pkt = psdHeader + tcpSeg

if len(pkt) % 2 != 0:
    # 长度为奇数要补一个字节的0
    pkt += bytes(1)

checksum = 0

for i in range(0, len(pkt), 2):
    num = int.from_bytes(pkt[i:i + 2], byteorder='big')
    checksum += num

while checksum >> 16:
    checksum = (checksum & 0xFFFF) + (checksum >> 16)

checksum = ~checksum
unInt = ctypes.c_ushort(checksum)
checksum = unInt.value
# print(checksum)

print('校验和: ', bytes2HexStr(checksum.to_bytes(2, 'big')))
