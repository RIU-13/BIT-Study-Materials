import socket
from chap6.TCP_conf import *

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, SERVER_PORT))

    while True:
        stringToSend = input('input string to send:')
        s.sendall(bytes(stringToSend, encoding='utf8'))
        if stringToSend == 'quit':
            break
        data = s.recv(1024)
        string = data.decode(encoding='utf8')
        print('receive: ', string)


