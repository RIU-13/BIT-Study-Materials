import socket

from Python.chap6.UDP_conf import HOST, CLIENT_PORT, SERVER_PORT

if __name__ == "__main__":
    addServer = (HOST, SERVER_PORT)
    addClient = (HOST, CLIENT_PORT)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.bind(addClient)
        s.connect(addServer)
        while True:
            stringToSend = input('input string to send:')
            s.sendall(bytes(stringToSend, encoding='utf8'))
            if stringToSend == 'quit':
                break
            data = s.recv(1024)
            string = data.decode(encoding='utf8')
            print('receive: ', string)

