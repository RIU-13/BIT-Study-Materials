import socket
from chap6.TCP_conf import *

if __name__ == "__main__":
    addServer = (HOST, SERVER_PORT)
    addClient = (HOST, CLIENT_PORT)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(addServer)
        s.listen()
        conn, addr = s.accept()
        print('Connected by', addr)
        roundCnt = 1
        while True:
            data = conn.recv(MSS)
            print("Round: ", roundCnt)
            print("Receive Data: {} bytes".format(len(data)))
            roundCnt += 1
            if len(data) == 0:
                break