import socket
import time

from chap6.TCP_conf import *

if __name__ == "__main__":

    addServer = (HOST, SERVER_PORT)
    addClient = (HOST, CLIENT_PORT)

    windowSize = 1
    roundCnt = 1
    flag = False  # 判断wondowsize是否超过阈值
    threshold = Threshold
    print("MSS: ", MSS)
    print("初始Threshold: ", threshold)
    print('开始传输：')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(addClient)
        s.connect(addServer)
        while roundCnt <= EndRound:
            print("Round: ", roundCnt)
            print("当前拥塞窗口大小：", windowSize)

            stringToSend = ""
            for i in range(windowSize):
                stringToSend += 'a'

            s.send(bytes(stringToSend, encoding='utf8')[:MSS])

            if roundCnt % TriACKRound == 0:
                print("3 duplicate ACKs")
                threshold = int(windowSize / 2)
                windowSize = threshold
            elif roundCnt % TimeoutRound == 0:
                print("Timeout")
                threshold = int(windowSize / 2)
                windowSize = 1
                #重新进行slow start，flag置为False
                flag = False
            else:
                if flag:
                    windowSize += 1
                else:
                    windowSize *= 2

            if windowSize >= threshold and not flag:
                #超过阈值
                windowSize = threshold
                flag = True
            #手动sleep 1s，防止数据短时间连续发送，接受端无法区分两次数据
            time.sleep(1)
            roundCnt += 1