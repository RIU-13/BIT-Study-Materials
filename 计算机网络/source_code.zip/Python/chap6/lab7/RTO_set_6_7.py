RTTs = [26, 32, 24, 28, 30, 26, 28, 33, 31, 35]
alpha = 0.125
beta = 0.25

initRTT = RTTs[0]
estimatedRTT = devRTT = initRTT

print('初始RTT: ', initRTT)

for i in range(1, len(RTTs)):
    print('本次RTT: ', RTTs[i])
    sampleRTT = RTTs[i]
    estimatedRTT = (1 - alpha) * estimatedRTT + alpha * sampleRTT
    devRTT = (1 - beta) * devRTT + beta * abs(sampleRTT - estimatedRTT)
    timoutInterval = estimatedRTT + 4 * devRTT

    print("平滑后RTT: ", estimatedRTT)
    print('当前的RTO: ', timoutInterval)
