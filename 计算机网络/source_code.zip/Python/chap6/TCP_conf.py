HOST = '127.0.0.1'
CLIENT_PORT = 1224
SERVER_PORT = 1130

MSS = 1024
Threshold = 32768
TriACKRound = 16
TimeoutRound = 22
EndRound = 26