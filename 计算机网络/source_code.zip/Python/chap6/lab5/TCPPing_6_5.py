from scapy.all import *
import socket
import argparse

from scapy.layers.inet import TCP, IP

parser = argparse.ArgumentParser()
parser.add_argument("-host_name", default="183.232.231.172")
parser.add_argument("-port", default="80", type=int)

args = parser.parse_args()
dstIp = socket.gethostbyname(args.host_name)

addr = (dstIp, args.port)
print(addr)

firstShake = IP() / TCP()
firstShake[IP].dst = dstIp
firstShake[TCP].dport = args.port

firstShake = IP(raw(firstShake))
print('第一次握手:')
firstShake[TCP].show()

secondShake = sr1(firstShake, filter='tcp', timeout=2)

secondShake = IP(secondShake)[TCP]
print('第二次握手:')
secondShake[TCP].show()

thirdShake = IP() / TCP()
thirdShake[IP].dst = dstIp
thirdShake[TCP].dport = args.port
thirdShake[TCP].flags = 0x010
thirdShake[TCP].ack = secondShake.seq + 1
thirdShake[TCP].seq = firstShake.seq + 1

print('第三次握手:')
thirdShake[TCP].show()
send(thirdShake)
