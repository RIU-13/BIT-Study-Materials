from utils import bytes2BitStr, bytes2HexStr
import ctypes

if __name__ == '__main__':
    udpSegStr = "f5420035002895f36df80100000100000000000003777777036269740365647502636e0000010001"
    sourceIP = "c0a80a68"
    destIP = "c0a80a01"
    protocol = 4


    # 校验位清0
    udpSeg = bytes.fromhex(udpSegStr)
    udpSeg = bytearray(udpSeg)
    orgChecksum = udpSeg[6:8]
    print(int.from_bytes(orgChecksum, byteorder="big"))
    udpSeg[6] = udpSeg[7] = 0
    udpSeg = bytes(udpSeg)
    udpSegLen = len(udpSeg)

    print("伪首部各字段值：")
    print("Source IP address:" + sourceIP)
    print("Destination IP address: " + destIP)
    print("protocol: " + str(protocol))
    print("udp length: " + str(udpSegLen))
    print("UDP首部各字段值：")
    print("Source port: ", udpSegStr[0:4])
    print("Destination port: ", udpSegStr[4:8])
    print("UDP Length: ", int.from_bytes(bytes(udpSeg[4:6]), byteorder="big"))


    sourceIP = bytes.fromhex(sourceIP)
    destIP = bytes.fromhex(destIP)
    protocol = protocol.to_bytes(1,byteorder="big")
    udpSegLen = udpSegLen.to_bytes(2,byteorder="big")

    psdHeader = sourceIP + destIP + bytes(1) + protocol + udpSegLen
    # print(len(psdHeader))
    # print(udpSegLen)
    pkt = psdHeader + udpSeg
    # print(len(firstShake), firstShake)

    if len(pkt) % 2 != 0:
        # 长度为奇数要补一个字节的0
        pkt += bytes(1)

    checksum = 0

    for i in range(0, len(pkt), 2):
        num = int.from_bytes(pkt[i:i + 2], byteorder='big')
        checksum += num

    while checksum >> 16:
        checksum = (checksum & 0xFFFF) + (checksum >> 16)

    sumWithoutCheck = checksum

    checksum = ~checksum

    unInt = ctypes.c_ushort(checksum)
    checksum = unInt.value
    print("udp checksum: ", checksum)
    print("16进制表示校验码: ", bytes2HexStr(checksum.to_bytes(2, 'big')))

    print("\n验证： 将校验码和原码一起计算，结果如下：")
    ans = ctypes.c_ushort(sumWithoutCheck).value + checksum
    print(bytes2HexStr(ans.to_bytes(2, 'big')))

