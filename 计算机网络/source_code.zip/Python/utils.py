def genStateLog(content: str, pad='='):
    """
    打印信息
    :param content:
    :return:
    """
    return (' ' + content + ' ').center(40, pad)


def bytes2HexStr(data: bytes):
    '''
    用十六进制的形式打印bytes
    :param data:
    :return:
    '''
    return ' '.join('%02X' % i for i in data)


def bytes2BitStr(src: bytes) -> str:
    return ''.join(f'{byte:08b}' for byte in src)