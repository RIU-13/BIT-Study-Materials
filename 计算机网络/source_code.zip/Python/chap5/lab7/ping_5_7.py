import os
import time
import socket
import struct
from scapy.all import *

# from dpkt.icmp import ICMP
from scapy.layers.inet import ICMP

ICMP_ECHO_REQUEST = 8


class Pinger:

    def __init__(self, dstName, timeout=5, dataSize=8):
        self.protoNum = socket.getprotobyname('icmp')
        # 原始套接字可以读写内核没有处理的IP数据包，
        # 而流套接字只能读取TCP协议的数据，数据报套接字只能读取UDP协议的数据。
        # 因此，如果要访问其他协议发送数据必须使用原始套接字
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, self.protoNum)
        self.socket.settimeout(5)

        socket.timeout = 5
        self.processID = os.getpid() & 0xFFFF
        self.dstIp = None
        self.dstName = dstName
        # ICMP包中data的数据大小(字节)
        self.dataSize = dataSize

    def send_ping(self, seq):
        self.dstIp = socket.gethostbyname(self.dstName)
        icmpPkt = ICMP()
        icmpPkt.type = ICMP_ECHO_REQUEST
        icmpPkt.code = 0
        icmpPkt.id = self.processID
        icmpPkt.seq = seq
        icmpPkt.add_payload(struct.pack('>d', time.clock()))
        # 生成checksum
        icmpPkt = ICMP(raw(icmpPkt))
        # icmpPkt.show2()

        packet = raw(icmpPkt)

        self.socket.sendto(packet, (self.dstIp, 0))

    def recevie_ping(self):
        try:
            # 每个 socket 被创建后，都会分配输入缓冲区和输出缓冲区
            pkt, addr = self.socket.recvfrom(100)
            timeRecv = time.clock()
            # print('recv: ', firstShake)
            ttl = pkt[8]
            icmp_header = pkt[20: 28]
            ip_type, code, checksum, id, sequence = struct.unpack(">bbHHh", icmp_header)
            if id == self.processID and ip_type == 0:
                # ping 成功
                timeSend = struct.unpack(">d", pkt[28: 28 + self.dataSize])[0]
                return self.dstIp, self.dataSize, timeRecv - timeSend, ttl
            else:
                return None
        except Exception as e:
            return None

    def ping(self, n=5):
        for i in range(5):
            self.send_ping(i)
            res = self.recevie_ping()
            if res:
                fromIp, bytesNum, timeDelay, ttl = res
                print('Reply from %s: bytes=%d time=%fms TTL=%d' % (fromIp, bytesNum, timeDelay * 1000, ttl))
            else:
                print('Timeout')


if __name__ == '__main__':
    dstName = input('输入目的网址: ')
    # dstName = 'www.baidu.com'
    pinger = Pinger(dstName)
    pinger.ping()
