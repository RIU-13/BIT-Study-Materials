from utils import bytes2HexStr, bytes2BitStr

config = {
    '135.46.56.0/22': 'Interface0',
    '136.46.60.0/22 ': 'Interface1',
    '192.53.40.0/23': 'Router1',
    '0/0': 'Router2'
}


class TableItem:
    def __init__(self, ip_mask: str, next_hop: str):
        ipStr, subnetMask = ip_mask.split('/')
        self.ip = ipStr2Bytes(ipStr)
        self.subnetMask = subnetMask2Bytes(subnetMask)
        self.next_hop = next_hop

    def __str__(self):
        return bytes2ipStr(self.ip) + '/' + str(bytes2subnetMask(self.subnetMask)) + '\t' + self.next_hop


def generateTable(config: dict) -> list:
    items = []
    for key, val in config.items():
        tableItem = TableItem(key, val)
        items.append(tableItem)
    return items


def ipStr2Bytes(ipStr: str) -> bytes:
    # 把ip地址转化为bytes
    bytes_list = [int(string).to_bytes(length=1, byteorder='big') for string in ipStr.split('.')]
    res = bytes()
    for i in bytes_list:
        res += i
    return res


def bytes2ipStr(ip: bytes) -> str:
    if len(ip) == 1:
        return '0'
    return '%d.%d.%d.%d' % (ip[0], ip[1], ip[2], ip[3])


def subnetMask2Bytes(subnetMask: str) -> bytes:
    subnetMask = int(subnetMask)
    # 转化为bytes的字节数
    len = (subnetMask + 8 - 1) // 8
    # 还要补0
    binaryStr = '0b' + (subnetMask * '1') + (32 - subnetMask) * '0'
    num = int(binaryStr, 2)
    return num.to_bytes(length=4, byteorder='big')


def bytes2subnetMask(subnetMask: bytes) -> int:
    return bin(int.from_bytes(subnetMask, byteorder='big')).count('1')


def getCmpInfo(itemIp: bytes, dstIp: bytes) -> str:
    ipStr = bytes2BitStr(itemIp)
    dstIpStr = bytes2BitStr(dstIp)
    for i in range(len(ipStr)):
        if ipStr[i] != dstIpStr[i]:
            break
    return ipStr[:i]


def andbytes(abytes, bbytes):
    return bytes(map(lambda a, b: a & b, abytes, bbytes))


def lookUpTable(dstIp: str, table: list, verbose=True):
    dstIpByte = ipStr2Bytes(dstIp)
    maxLen = 0
    next_hop = table[-1].next_hop
    for item in table[:-1]:
        dstIpByte = andbytes(dstIpByte, item.subnetMask)
        cmpRes = getCmpInfo(item.ip, dstIpByte)
        if verbose:
            print(item)
            print('匹配信息: ', cmpRes, '\n')
        if len(cmpRes) > maxLen:
            maxLen = len(cmpRes)
            next_hop = item.next_hop
    print('next hop: ', next_hop)


if __name__ == '__main__':
    table = generateTable(config)

    # dstIp = '135.46.32.0'
    dstIp = input('请输入目的IP地址')

    lookUpTable(dstIp, table)
