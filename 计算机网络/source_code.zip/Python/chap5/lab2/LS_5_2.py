import numpy as np

def displayTable(table):
    for idx, line in enumerate(table):
        print("router %d: " % idx, line)

def initialization():
    N.append(u)
    for i in range(num):
        for j in range(num):
            if isNeighbor[i][j]:
                p[i].append(j)

    for i in range(num):
        if isNeighbor[u][i]:
            D.append(cost[u][i])
        else:
            D.append(99)
    D[u] = 0

def findnext():
    ans = 0
    tmp = 99
    for i in range(num):
        if i not in N:
            if tmp > D[i]:
                ans = i
                tmp = D[i]
    return ans

def dijkstra():
    step = 0
    while len(N) != num:
        print("Step %d: " % step, D)
        step += 1
        w = findnext()
        N.append(w)
        routingTable[u][w] = D[w]
        for i in p[w]:
            if i not in N:
                D[i] = min(D[i], D[w] + cost[w][i])


if __name__ == '__main__':
    routingTable = np.array([
        [0, 7, 99, 99, 10],
        [7, 0, 1, 99, 8],
        [99, 1, 0, 2, 99],
        [99, 99, 2, 0, 2],
        [10, 8, 99, 2, 0]
    ])
    isNeighbor = np.array(routingTable != 99)
    num = isNeighbor.shape[0]
    isNeighbor[range(num), range(num)] = False
    # print(isNeighbor)
    print('初始链路状态：')
    displayTable(routingTable)

    # 原始距离，c(x,y): link cost from node x to y;  = 99 if not direct neighbors
    cost = np.array(routingTable)
    #所有路由节点
    node = [0, 1, 2, 3, 4]

    for i in range(num):
        u = i
        print("计算router %d" % u)
        # set of nodes whose least cost path definitively known
        N = []
        #D(v): current value of cost of path from source to dest. v
        D = []
        #p(v): predecessor node along path from source to v
        p = [[] for i in range(num)]

        initialization()
        dijkstra()

    print('最终态路由表：')
    displayTable(routingTable)
