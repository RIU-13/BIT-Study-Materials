
def fromhex_str(s):
    ans = '0x' + s
    # print(ans)
    return int(ans, 16)

def dec2bin(dec_num, bit_wide=16):
    #十进制数转化为二进制数，并且指定位数
    _, bin_num_abs = bin(dec_num).split('b')
    if len(bin_num_abs) > bit_wide:
        raise ValueError           # 数值超出bit_wide长度所能表示的范围
    else:
        if dec_num >= 0:
            bin_num = bin_num_abs.rjust(bit_wide, '0')
        else:
            _, bin_num = bin(2**bit_wide + dec_num).split('b')
    return bin_num

def analysisDFMF(s):
    DFMF = ''
    for i in s:
        DFMF += dec2bin(int('0x' + i, 16), 4)
    # print(DFMF)
    DF = DFMF[1]
    MF = DFMF[2]
    offset = DFMF[3:]
    return DF, MF, str(int(offset))

def getIPfromhex(s):
    IPaddress = ''
    for i in range(4):
        tmp = s[i*2:i*2+2]
        IPaddress += str(fromhex_str(tmp)) + '.'
    return IPaddress[0:-1]

def getchecksum_sender(s):
    sum = 0
    for i in range(10):
        if i == 5:
            continue
        tmp = '0x' + s[i*4+2:i*4+6]
        sum += int(tmp, 16)
    sum += (sum >> 16)
    t = dec2bin(sum, 20)[4:]
    # print(len(t), t)
    b = ''
    for i in t:
        if i == '0':
            b += '1'
        else:
            b += '0'

    ans = int('0b' + b, 2)
    # print(b, hex(ans))
    return hex(ans)[2:]

def getchecksum_receiver(s):
    sum = 0
    for i in range(10):
        tmp = '0x' + s[i*4+2:i*4+6]
        sum += int(tmp, 16)
    sum += (sum >> 16)
    t = dec2bin(sum, 20)[4:]
    # print(len(t), t)
    b = ''
    for i in t:
        if i == '0':
            b += '1'
        else:
            b += '0'

    ans = int('0b' + b, 2)
    # print(b, hex(ans))
    return hex(ans)[2:]

if __name__ == '__main__':
    IPHeader = 0x4500003CB53040008006E251C0A80168D83AC8EE
    str_IPHeader = hex(IPHeader)
    print('IP数据报首部的十六进制值: ', hex(IPHeader))
    print(len(str_IPHeader))
    version = str_IPHeader[2]
    IHL = str_IPHeader[3]
    Type_of_service = str_IPHeader[4:6]
    Total_length = str_IPHeader[6:10]
    Identification = str_IPHeader[10:14]
    DF, MF, Fragment_offset = analysisDFMF(str_IPHeader[14:18])
    TTL = str_IPHeader[18:20]
    Protocol = str_IPHeader[20:22]
    Header_checksum = str_IPHeader[22:26]
    src = str_IPHeader[26:34]
    dst = str_IPHeader[34:]

    print('version: ' , version)
    print('IHL: ', IHL)
    print('Type of service: ', fromhex_str(Type_of_service))
    print('Total length: ', fromhex_str(Total_length))
    print('Identification: ', fromhex_str(Identification))
    print('DF: ', DF)
    print('MF: ', MF)
    print('Fragment_offset: ', Fragment_offset)
    print('Time to live: ', fromhex_str(TTL))
    print('Protocol: ', fromhex_str(Protocol))
    print('Header checksum: ', fromhex_str(Header_checksum))
    print('Source address: ', getIPfromhex(src))
    print('Destination address: ', getIPfromhex(dst))

    # print(Header_checksum)
    checksum = getchecksum_sender(str_IPHeader)
    print('计算显示首部校验和: ', checksum)

    rec_check = getchecksum_receiver(str_IPHeader)
    print('验证接收端校验和: ', rec_check)
    if rec_check == '0':
        print('校验和为0，验证通过')
