from scapy.all import *
import scapy_http.http


sniff(prn=lambda x:x.show2(), filter='udp')
