from scapy.layers.inet import ICMP, IP, traceroute, UDP, TCP, TracerouteResult
import sys
import logging
from scapy.all import *
import time
import re
import optparse


def Tracert_one(dst, dport, ttl):  # 发一个Traceroute包，参数需要目的地址，目的端口，TTL。
    send_time = time.time()  # 记录发送时间
    # a, b = traceroute(target=dst, dport=dport, minttl = ttl, maxttl=ttl, verbose=False)
    a, b = sr(IP(dst=ip, id=RandShort(), ttl=(ttl, ttl)) / TCP(), timeout=2, verbose=False)
    received_time = time.time()
    time_to_passed = (received_time - send_time) * 1000
    try:
        if a.res:
            hop_ip = a.res[0][1].src
        elif b.res:
            hop_ip = b.res[0][1].src
        if hop_ip != dst:
            return 1, hop_ip, time_to_passed  # 返回1表示并未抵达目的地
        else:
            return 2, hop_ip, time_to_passed  # 返回2表示抵达目的地
    except Exception as e:
        if re.match('.*NoneType.*', str(e)):
            return None  # 测试失败返回None


def Tracert(dst, hops):
    dport = 33000  # Traceroute的目的端口从33000开始计算
    hop = 0
    while hop < hops:
        dport = dport + hop
        hop += 1
        results = []
        time_to_pass_result = ''
        for i in range(3):
            Result = Tracert_one(dst, dport, hop)
            results.append(Result)
            if Result != None:
                time_to_pass_result += '%4.2fms  ' % Result[2]
            else:
                time_to_pass_result += '     *  '
            if i == 2:
                if Result == None:
                    print(str(hop) + '    *      *      *          请求超时')
                else:
                    # time_to_pass_result = '%4.2fms  %4.2fms  %4.2fms' % (results[0][2], results[1][2], results[2][2])
                    print(str(hop) + ' ' + time_to_pass_result + ' ' + str(Result[1]))

        if Result != None and Result[0] == 2:
            print("跟踪完成。")
            break


if __name__ == '__main__':
    dstName = input('输入目的IP地址: ')
    # dstName = 'www.baidu.com'
    ip = socket.gethostbyname(dstName)
    print('通过最多 30 个跃点跟踪\n到 %s [%s] 的路由:' % (dstName, ip))
    hops = 30
    # traceroute(dstName)
    Tracert(ip, hops)
