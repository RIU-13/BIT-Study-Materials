from scapy.all import *
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import ARP, Ether

import socket

class NAT(threading.Thread):
    def __init__(self, dev1, dev2, OutsideIP, isTest=False):
        threading.Thread.__init__(self)
        self.insideDev = dev1
        self.forwardDev = dev2
        self.isTest = isTest
        self.OutsideIP = OutsideIP
        self.NATTable = []

    def initialization(self):
        self.NATTable.append(['211.68.9.10', '5001', '192.168.0.0', '3345'])


    def run(self):
        self.initialization()
        if not  self.isTest:
            self.listenInside()
        else:
            self.sendTest()

    def listenInside(self):
        sniff(filter="", iface=self.insideDev, prn=lambda x: x.summary(), stop_filter=lambda x:self.forwordData(x))

    def displaytTable(self):
        print('NAT Table: ')
        for i in self.NATTable:
            print(i)

    def forwordData(self, pData: scapy.layers.l2.Ether):
        print('从内网截获到MAC帧: ')
        pData.show()
        macSrc = pData['Ethernet'].src
        macDst = pData['Ethernet'].dst
        ipSrc = pData['IP'].src
        sport = pData['TCP'].sport
        ipDst = pData['IP'].dst
        dport = pData['TCP'].dport
        data = pData['Raw']
        print('IP数据报的源地址: ', ipSrc)
        print('TCP源端口: ', sport)
        print('IP数据报的目的地址: ', ipDst)
        print('TCP目的端口: ', dport)

        for i in self.NATTable:
            if str(ipSrc) == i[2] and str(sport) == i[3]:
                ipOut = i[0]
                portOut = i[1]
        print('转换后的IP数据报的源地址和TCP源端口: ' + ipOut + ', ' + portOut)
        newpkt = Ether(dst=macDst, src=macSrc) / IP(dst=ipDst, src=ipOut) / TCP(sport=int(portOut), dport=int(dport))/data
        newpkt = Ether(bytes(newpkt))
        print('IP校验和: ', newpkt['IP'].chksum)
        print('TCP校验和: ', newpkt['TCP'].chksum)
        self.displaytTable()

        print('外网端口转发的MAC帧: ')
        newpkt.show()
        sendp(newpkt, iface=self.forwardDev)

    def sendTest(self):
        print('发送测试数据包')
        macSrc = Ether().src
        dstIP = '192.168.2.229'
        InsideIP = '192.168.0.0'
        DestMAC = '11:11:11:11:11:11'
        data = 'Hello world'
        pkt = Ether(dst=DestMAC, src=macSrc) / IP(dst=dstIP, src=InsideIP) / TCP(sport=3345, dport=80)/data
        # firstShake.show()
        sendp(pkt, iface=self.insideDev)

if __name__ == '__main__':
    show_interfaces()
    # devIdx1 = int(input('选择内网捕获适配器编号:'))
    devIdx1 = 7
    devIdx2 = 23
    devName1 = IFACES.dev_from_index(devIdx1)
    # devIdx2 = int(input('选择外网转发适配器编号:'))
    devName2 = IFACES.dev_from_index(devIdx2)
    myNAT = NAT(devName1, devName2, OutsideIP = '211.68.9.10')
    myNAT.start()
    myNAT.sendTest()



