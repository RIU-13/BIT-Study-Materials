from scapy.all import *
import scapy_http.http
import pcap
import dpkt
import getopt
import sys
import datetime
import time
import os

# 是否生成数据包
from scapy.layers.inet import IP

MAKE_PKT = 0

BigIPTotalLen = 4000
fragSize = 185


def make_pkt(pkt, BigIPTotalLen, pcap_filepath):
    ipPkt = pkt[IP]
    # print(ipPkt.payload)

    dummyData = bytes(BigIPTotalLen - len(ipPkt))
    # # 修改长度
    ipPkt.len = BigIPTotalLen
    del ipPkt.len
    # 修改flags
    ipPkt.flags = 0
    ipPkt.add_payload(dummyData)
    # 重新生成checksum
    ipPkt.show2()
    # print(ipPkt.payload)
    print(len(ipPkt.payload))

    # 写回pcap文件
    with open(pcap_filepath, 'wb') as pcap_file:
        writer = dpkt.pcap.Writer(pcap_file)
        writer.writepkt(raw(pkt))
        writer.close()


def print_ip_pkt(ipPkt, show=False):
    print('总长度:', ipPkt.len)
    print('标识:', ipPkt.id)
    print('标志:', int(ipPkt.flags))
    print('片段偏移:', ipPkt.frag)
    if show:
        ipPkt.show()


def fragment(ipPkt, fragSize):
    fragLen = fragSize * 8
    n = (len(ipPkt) + fragLen - 1) // fragLen
    payload = raw(ipPkt.payload)
    ipPkt_list = []
    for i in range(n):
        tmp_ipPkt = ipPkt.copy()
        tmp_ipPkt.remove_payload()

        if i != n - 1:
            # 不是最后一个分片, MF = 1代表片未完
            tmp_ipPkt.flags |= 1
        tmp_ipPkt.frag = i * fragSize
        r = conf.raw_layer(load=payload[i * fragLen:(i + 1) * fragLen])
        tmp_ipPkt.add_payload(r)

        # 重新生成checksum, len
        del tmp_ipPkt.chksum
        del tmp_ipPkt.len

        tmp_ipPkt = tmp_ipPkt.__class__(raw(tmp_ipPkt))

        ipPkt_list.append(tmp_ipPkt)

    return ipPkt_list


def reassemble(ipPkt_list: list):
    print('共%d个分片' % len(ipPkt_list))
    for pkt in ipPkt_list:
        print_ip_pkt(pkt)
        print()
    order_ipPkt_list = sorted(ipPkt_list, key=lambda x: x.frag)
    payload = bytes()
    for ipPkt in ipPkt_list:
        payload += raw(ipPkt.payload)

    reassemble_ipPkt = ipPkt_list[0].copy()
    del reassemble_ipPkt.len
    del reassemble_ipPkt.chksum

    reassemble_ipPkt.remove_payload()
    reassemble_ipPkt.add_payload(payload)

    reassemble_ipPkt.flags = 0
    reassemble_ipPkt.frag = 0

    reassemble_ipPkt = reassemble_ipPkt.__class__(raw(reassemble_ipPkt))

    return reassemble_ipPkt

if __name__ == "__main__":
    pcap_filepath = '../test.pcap'
    pcaps = rdpcap(pcap_filepath)
    # 默认处理第一个包
    pkt = pcaps[0]

    if MAKE_PKT:
        make_pkt(pkt, BigIPTotalLen, pcap_filepath)

    ipPkt = pkt[IP]

    print('原始大数据报信息:')
    print_ip_pkt(ipPkt)

    print('\n开始分片:')
    print('分片的信息:')
    ipPkt_list = fragment(ipPkt, fragSize)
    for pkt in ipPkt_list:
        print_ip_pkt(pkt)
        print()

    reassemble_ipPkt = reassemble(ipPkt_list)
    print('重装后数据报的信息:')
    print_ip_pkt(reassemble_ipPkt)
