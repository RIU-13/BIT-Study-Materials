import numpy as np

routingTable = np.array([
    [0, 1, 99, 99, 99],
    [1, 0, 1, 99, 99],
    [99, 1, 0, 1, 99],
    [99, 99, 1, 0, 1],
    [99, 99, 99, 1, 0]
])

# 原始距离
originDis = np.array(routingTable)

isNeighbor = np.array(routingTable != 99)
n = isNeighbor.shape[0]
isNeighbor[range(n), range(n)] = False


def displayTable(table):
    for idx, line in enumerate(table):
        print("router %d: " % idx, line)


def update(routingTable):
    num = len(routingTable)
    for i in range(num):
        cur_line = routingTable[i]
        for j in range(num):
            if i == j:
                continue
            # 所有路由器到j的距离
            dis_to_j = routingTable[:, j]
            # 经过各个路由器到j的距离, 并提取出邻居的距离
            all_dis_to_j = (dis_to_j + originDis[i])[isNeighbor[i]]
            # print(i, j, '\n', cur_line, dis_to_j, all_dis_to_j, '\n')
            if len(all_dis_to_j) == 0:
                cur_line[j] = 99
                continue
            cur_line[j] = min(min(all_dis_to_j), 99)


def getTableSum(routingTable):
    return sum([sum(i) for i in routingTable])


def converge(routingTable):
    last_sum = getTableSum(routingTable)
    cnt = 0
    while True:
        cnt += 1
        update(routingTable)
        cur_sum = getTableSum(routingTable)
        if last_sum == cur_sum:
            break
        last_sum = cur_sum
    print('共更新%d次' % cnt)
    print('稳定状态:')
    displayTable(routingTable)


if __name__ == '__main__':
    print('初始状态:')
    displayTable(routingTable)

    converge(routingTable)

    i, j, val = (int(_) for _ in input('输入要修改的坐标和值').split(' '))
    # i, j, val = 0, 1, 99
    originDis[i, j] = originDis[j, i] = val
    if val == 99:
        isNeighbor[i, j] = isNeighbor[j, i] = False
    else:
        isNeighbor[i, j] = isNeighbor[j, i] = True


    converge(routingTable)
