from scapy.all import *
from scapy.layers.inet import IP, ICMP
from scapy.layers.l2 import ARP, Ether

import socket

cache = {}


def getIP():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


def send_receive_ARP(ipDst: str = "192.168.2.229", macSrc: str = "96:97:94:19:3e:aa"):
    pktARP = ARP(hwsrc=macSrc, pdst=ipDst)
    print('要发送的请求ARP包内容如下:')
    pktARP.show()
    p = sr1(pktARP, filter='arp', timeout=2)
    return ARP(p)


def send_recive(ipDst, macSrc):
    arpPkt = send_receive_ARP(ipDst=ipDst, macSrc=macSrc)

    print('ARP响应包内容如下:')
    arpPkt.show()

    if arpPkt.op == 2 and arpPkt.psrc == ipDst:
        global cache
        cache[arpPkt.psrc] = arpPkt.hwsrc
        print('缓冲区内容:')
        for i in cache.items():
            print(i)
        return True
    else:
        return False


if __name__ == '__main__':
    show_interfaces()
    devIdx = int(input('选择网卡设备:'))
    # devIdx = 25
    devName = IFACES.dev_from_index(devIdx)
    # decIdx = input('选择捕获适配器编号:')

    macSrc = Ether().src
    ipDst = input('输入对方的IP地址:')
    # ipDst = '192.168.1.1'
    send_recive(ipDst, macSrc)
