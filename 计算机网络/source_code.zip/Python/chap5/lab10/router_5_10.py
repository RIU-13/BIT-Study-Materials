from scapy.all import *
from scapy.layers.inet import IP, TCP
from scapy.layers.l2 import ARP, Ether

import socket

class myThread(threading.Thread):
    def __init__(self, name, idx, dev1, dev2, mac, ip):
        threading.Thread.__init__(self)
        self.name = name
        self.idx = idx  # 网卡序号
        self.dev1 = dev1  # 设备名称
        self.dev2 = dev2  # 设备名称
        self.mac = mac
        self.ip = ip
        self.routeTable = []

    def addRouteTable(self, IP, next, type):
        self.routeTable.append([IP, next, type])

    def run(self):
        self.listenInside()

    def listenInside(self):
        sniff(filter="", iface=self.dev1, prn=lambda x: x.summary(), stop_filter=lambda x:self.forwordData(x))

    def displaytTable(self):
        print(self.name, '\nRouteTable Table: ')
        for i in self.routeTable:
            print(i)

    def routerTableMatch(self, ipDst):
        # 在路由表中查找下一跳
        for item in self.routeTable:
            if item[2] == 'static':
                mask = item[0].split('/')[-1]
                flag = True
                for i in range(len(ipDst)):
                    if i > 9:
                        break
                    if ipDst[i] != item[0][i]:
                        flag = False
                        break
                if flag:
                    return item[1]
            else:
                continue

        return None


    def forwordData(self, pData: scapy.layers.l2.Ether):
        print(self.name, ' 截获到MAC帧: ')
        pData.show()
        macSrc = pData['Ethernet'].src
        macDst = pData['Ethernet'].dst
        ipSrc = pData['IP'].src
        ipDst = pData['IP'].dst
        ttl = pData['IP'].ttl
        data = pData['Raw']
        # print('IP数据报的源地址: ', ipSrc)
        # print('TCP源端口: ', sport)
        print('IP数据报的目的地址: ', ipDst)
        # print('TCP目的端口: ', dport)
        self.displaytTable()
        ipNext = self.routerTableMatch(ipDst)
        ttl = ttl - 1
        if not ipNext:
            print('到达', ipDst)
            return

        print('下一跳：', ipNext)
        newpkt = Ether(dst=macDst, src=macSrc) / IP(dst=ipDst, src=ipSrc, ttl=ttl) / data
        newpkt = Ether(bytes(newpkt))
        print('IP校验和: ', newpkt['IP'].chksum)

        # print('外网端口转发的MAC帧: ')
        # newpkt.show()
        sendp(newpkt, iface=self.dev2)

    def ping(self, dstIP):
        print('ping ', dstIP)
        macSrc = self.mac
        InsideIP = self.ip
        DestMAC = '00:0c:29:c2:4b:82'
        data = 'Hello world'
        pkt = Ether(dst=DestMAC, src=macSrc) / IP(dst=dstIP, src=InsideIP) / data
        # firstShake.show()
        sendp(pkt, iface=self.dev1)



if __name__ == '__main__':
    show_interfaces()
    devIdx1 = int(input('选择第一块捕获适配器编号: '))
    # devIdx1 = 7
    # devIdx2 = 23
    devName1 = IFACES.dev_from_index(devIdx1)
    devIdx2 = int(input('选择第二块捕获适配器编号: '))
    devName2 = IFACES.dev_from_index(devIdx2)
    myThreadA = myThread('RouterA', devIdx1, devName1, devName2, '00:0c:29:c2:4b:80', '192.168.10.10')
    myThreadB = myThread('RouterB', devIdx2, devName2, devName1, '00:0c:29:c2:4b:82', '192.168.20.20')

    myThreadA.addRouteTable('192.168.10.0/24', '-', 'direct')
    myThreadA.addRouteTable('10.1.1.0/24', '-', 'direct')
    myThreadA.addRouteTable('192.168.20.0/24', '10.1.1.2', 'static')
    myThreadB.addRouteTable('192.168.20.0/24', '-', 'direct')
    myThreadB.addRouteTable('10.1.1.0/24', '-', 'direct')
    myThreadB.addRouteTable('192.168.10.0/24', '10.1.1.2', 'static')

    myThreadA.start()
    myThreadB.start()

    myThreadA.ping('192.168.20.20')




