# encoding: utf-8
from scapy.all import rdpcap
import scapy_http.http
import pcap
import dpkt
from scapy.all import *
from scapy.layers.inet import IP, UDP, ICMP
from scapy.layers.l2 import Ether, ARP

class myThread (threading.Thread):
    def __init__(self, idx, mac, ip, pc):
        threading.Thread.__init__(self)
        self.idx = idx #网卡序号
        self.dev = devices[idx] #设备名称
        self.mac = mac
        self.ip = ip
        self.pc = pc
        self.pcap_filepath = dev+'.pcap'

    def run(self):
        self.captureData()

    def send_data(self, mac_dst, ip_dst, dev_idx, data):
        dev = devices[dev_idx]
        pkt = Ether(dst=mac_dst)/IP(src=self.ip, dst=ip_dst)/UDP(sport=100, dport=200)/data
        # print(firstShake.show())
        sendp(pkt, inter=1, count=1, iface=dev)

    def captureData(self):
        print('开始抓包...' + self.dev)
        try:
            pkts_count = 0
            for ptime, pdata in self.pc:
                with open(self.pcap_filepath, 'wb') as pcap_file:
                    writer = dpkt.pcap.Writer(pcap_file)
                    writer.writepkt(pdata)
                    writer.close()
                pcaps = rdpcap(self.pcap_filepath)
                self.receivePacket(pcaps[0])
                pkts_count += 1
        except KeyboardInterrupt as e:
            print('%d packets received' % (pkts_count))

    def receivePacket(self, pdata):
        print("网卡设备：" + self.dev + "捕获数据帧")
        # print(pdata.show())
        src_mac = self.mac
        dst_mac = pdata['Ethernet'].dst
        print("源MAC地址: " + src_mac)
        print("目的MAC地址: " + dst_mac)
        print("当前的路由表：(长度：" + str(len(routeMap)) + ")")
        print_routeMap()
        if src_mac == dst_mac:
            print("到达目的端，接受这一帧")
            print("----------------------------------------------------------------------------------------------")
        else:
            if src_mac in routeMap:
                print("路由表中已有，无需添加")
            else:
                print("进行逆向学习，添加源地址端口到路由表")
                routeMap[src_mac] = self.idx

            if dst_mac in routeMap:
                print("在路由表中找到目的地址")
                if routeMap[dst_mac] == self.idx:
                    print("目的地址与源地址在同一端，丢弃该数据帧")
                    print("----------------------------------------------------------------------------------------------")
                else:
                    print("目的地址与源地址在不同端，转发数据帧")
                    print("----------------------------------------------------------------------------------------------")
                    self.send_data(dst_mac, pdata['IP'].dst, routeMap[dst_mac], pdata['Raw'])
            else:
                print("路由表中无目标端口，使用泛洪法")
                print("----------------------------------------------------------------------------------------------")
                for key in routeMap:
                    if key != src_mac:
                        self.send_data(key, pdata['IP'].dst, routeMap[key], pdata['Raw'])

def print_routeMap():
    print("     MAC地址     : 对应端口号")
    for key in routeMap:
        print(key + ': ' + str(routeMap[key]))

def createpcap(dev):
    print('所选网卡: ', dev)
    pc = pcap.pcap(dev, promisc=True, immediate=True, timeout_ms=50)
    # filter method
    filters = {
        'DNS': 'udp port 200',
        'HTTP': 'tcp port 80'
    }
    pc.setfilter(filters['DNS'])
    return pc

if __name__ == "__main__":
    routeMap = {}
    print('网卡设备如下:')
    devices = pcap.findalldevs()
    for i, dev in enumerate(devices):
        print(i, dev)
    idx1 = int(input('请选择网卡1: '))
    pcap1 = createpcap(devices[idx1])
    idx2 = int(input('请选择网卡2: '))
    pcap2 = createpcap(devices[idx2])
    # thread1 = myThread(devices[idx1], '0e:1d:f8:ad:eb:d1', 1, pcap1)
    # thread2 = myThread(devices[idx2], '5e:27:93:1f:65:20', 2, pcap2)
    thread1 = myThread(idx1, '00:0c:29:c2:4b:85', '192.168.157.129', pcap1)
    thread2 = myThread(idx2, '00:00:00:00:00:00', '127.0.0.1', pcap2)

    thread1.start()
    thread2.start()

    #测试
    # thread1.send_data("00:00:00:00:00:00", '127.0.0.1', idx2, "test1")
    # thread2.send_data("00:0c:29:c2:4b:85", '192.168.157.129', idx1, "test2")
    # thread1.send_data("00:00:00:00:00:00", '127.0.0.1', idx2, "test3")
    # thread1.send_data("00:0c:29:c2:4b:85", '192.168.157.129', idx2, "test1")
    thread1.send_data("00:0c:29:c2:4b:85", '192.168.157.129', idx2, "test1")
    thread2.send_data("00:00:00:00:00:00", '127.0.0.1', idx1, "test2")
    thread1.send_data("00:0c:29:c2:4b:85", '192.168.157.129', idx2, "test3")


