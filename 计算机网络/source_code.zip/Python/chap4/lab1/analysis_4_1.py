from scapy.all import rdpcap
import scapy_http.http
import pcap
import dpkt
import getopt
import sys
import datetime
import time
import os


def mac_addr(mac):
    return '%02x:%02x:%02x:%02x:%02x:%02x' % tuple(mac)


def ip_addr(ip):
    return '%d.%d.%d.%d' % tuple(ip)


def captureData(dev):
    print('所选网卡: ', dev)

    pc = pcap.pcap(dev, promisc=True, immediate=True, timeout_ms=50)
    # filter method
    filters = {
        'DNS': 'udp port 53',
        'HTTP': 'tcp port 80'
    }
    # pc.setfilter(filters['HTTP'])
    pcap_filepath = 'test.pcap'

    print('开始抓包...')
    try:
        pkts_count = 0
        for timestamp, buf in pc:
            with open(pcap_filepath, 'wb') as pcap_file:
                writer = dpkt.pcap.Writer(pcap_file)
                writer.writepkt(buf)
                writer.close()

            pcaps = rdpcap(pcap_filepath)
            print(pcaps[0].show())
            pkts_count += 1
    except KeyboardInterrupt as e:
        print(e)
        print('%d packets received' % (pkts_count))


def analysisPacket(timestamp, data: bytes):
    eth = analysisMACLayer(timestamp, data)

    analysisNetLayer(eth)


def analysisNetLayer(eth):
    # 取出网络层数据
    print('\n网络层:')
    if not isinstance(eth.data, dpkt.ip.IP):
        print('不包含IP信息，忽略')
        return

    ip = eth.data
    do_not_fragment = bool(ip.off & dpkt.ip.IP_DF)
    more_fragments = bool(ip.off & dpkt.ip.IP_MF)
    fragment_offset = ip.off & dpkt.ip.IP_OFFMASK
    print('IP: %s -> %s (len=%d ttl=%d DF=%d MF=%d offset=%d)\n' % (
        ip_addr(ip.src), ip_addr(ip.dst), ip.len, ip.ttl,
        do_not_fragment, more_fragments, fragment_offset))


def analysisMACLayer(timestamp, data):
    print('数据链路层:')
    # 打印UTC时间
    print('Timestamp: ', str(datetime.datetime.utcfromtimestamp(timestamp)))

    eth = dpkt.ethernet.Ethernet(data)
    print('种类:%d\n源MAC地址: %s\n目的MAC地址: %s' % (eth.type,
                                              mac_addr(eth.src), mac_addr(eth.dst)))
    return eth


if __name__ == "__main__":
    print('网卡设备如下:')
    devices = pcap.findalldevs()
    for i, dev in enumerate(devices):
        print(i, dev)
    idx = int(input('请选择网卡: '))
    captureData(devices[0])
