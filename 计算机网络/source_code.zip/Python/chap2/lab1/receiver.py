import json
from chap2.lab1.sender import Serial

if __name__ == '__main__':
    with open('config.json', 'r') as f:
        config = json.load(f)

    ports, baudrate, bytesize, parity, stopbits = config['ports'], config['baudrate'], config['bytesize'], config[
        'parity'], config['stopbits']

    ser2 = Serial(ports[1], 'READ', baudrate, bytesize, parity, stopbits)

    ser2.begin()
