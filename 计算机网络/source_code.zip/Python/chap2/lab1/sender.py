import serial
import serial.tools.list_ports
import threading
import json


class Serial:
    def __init__(self, port, mode='WRITE', baudrate=9600, bytesize=8, parity='PARITY_EVEN', stopbits=1):
        super().__init__()
        self.ser = serial.Serial(port, baudrate=baudrate,
                                 bytesize=bytesize, stopbits=stopbits)
        parity_map = {
            'PARITY_EVEN': serial.PARITY_EVEN,
            'PARITY_ODD': serial.PARITY_ODD
        }

        self.ser.parity = parity_map[parity]
        self.mode = mode

        # 打印信息
        self.display_info()

    def display_info(self):
        print('设备名: %s\n波特率: %d\n数据位: %d\n校验位: %s\n停止位: %d\n' % (
            self.ser.port, self.ser.baudrate, self.ser.bytesize, self.ser.parity, self.ser.stopbits))

    def begin(self):
        if self.mode == 'WRITE':
            while True:
                s = input('%s发出: ' % self.ser.port)
                self.ser.write((s + '\n').encode('utf-8'))
                if s.startswith('quit'):
                    return
        elif self.mode == 'READ':
            while True:
                s = self.ser.readline().decode('utf-8')
                if s.startswith('quit'):
                    return
                print('%s接受: ' % self.ser.port + s)


if __name__ == '__main__':
    with open('config.json', 'r') as f:
        config = json.load(f)

    ports, baudrate, bytesize, parity, stopbits = config['ports'], config['baudrate'], config['bytesize'], config[
        'parity'], config['stopbits']

    ser1 = Serial(ports[0], 'WRITE', baudrate, bytesize, parity, stopbits)

    ser1.begin()
