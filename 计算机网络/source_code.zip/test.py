import math

a = [25, 20, 15, 10, 8, 8, 5, 4, 3, 2]
for idx, i in enumerate(a):
    print(chr(idx + ord('A')) * i, end='')

print('\n')

H = 0
for i in a:
    per = i / 100
    H -= per * math.log2(per)

print(H)
