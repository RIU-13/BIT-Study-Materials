import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class LS {
    final static int maxn = 5;
    static String inputFile = "topo.txt";

    static int V;
    static int[][] topo = new int[maxn][maxn];
    static int[] d;
    static boolean[] used;

    static int[][] nextHop = new int[maxn][maxn];
    static int[][] minCost = new int[maxn][maxn];

    public static void main(String[] args) throws IOException {
        readTopo();
        printLinkStatus();
        d = new int[V];
        used = new boolean[V];
        for (int i = 0; i < V; i++) {
            Arrays.fill(nextHop[i], Router.inf);
            dijkstra(i);
        }
        printTable();
    }

    private static void readTopo() throws IOException {
        String line;
        BufferedReader in = new BufferedReader(new FileReader(inputFile));
        for (int i = 0; null != (line = in.readLine()); i++) {
            if (line.startsWith("//")) {
                i--;
                continue;
            }
            String[] nums = line.split(" ");
            V = nums.length;
            for (int j = 0; j < V; j++) {
                topo[i][j] = Integer.parseInt(nums[j]);
            }
        }
    }

    private static void printLinkStatus() {
        System.out.println("Link status:");
        for (int i = 0; i < V; i++) {
            System.arraycopy(topo[i], 0, minCost[i], 0, V);
            System.out.println("Router " + i + ": " + Arrays.toString(minCost[i]));
        }
        System.out.println("");
    }

    private static void dijkstra(int s) {
        System.out.println("Router " + s);
        Arrays.fill(d, Router.inf);
        Arrays.fill(used, false);
        d[s] = 0;
        int step = 0;
        while (true) {
            int v = -1;

            for (int u = 0; u < V; u++) {
                if (!used[u] && (v == -1 || d[u] < d[v])) v = u;
            }

            if (v == -1) break;
            used[v] = true;

            for (int u = 0; u < V; u++) {
                if (d[u] > d[v] + topo[v][u]) {
                    d[u] = d[v] + topo[v][u];
                    if (v == s)
                        // v = s的话，说明u、v是相邻的
                        nextHop[s][u] = u;
                    else if (nextHop[s][v] != Router.inf)
                        // 填过nextHop，说明v是间接访问的
                        nextHop[s][u] = nextHop[s][v];
                    // 没有别的else了，其实这个elseif可以删掉if
                }
            }
            System.out.println("Step " + step++ + ": " + Arrays.toString(d));
        }
        System.out.println("");
        System.arraycopy(d, 0, minCost[s], 0, V);
    }

    private static void printTable() {
        for (int i = 0; i < V; i++) {
            System.out.println("Router " + i);
            System.out.println("to\tcost\tnext hop");
            for (int j = 0; j < V; j++) {
                System.out.println(j + "\t" + minCost[i][j] + "\t\t" + (nextHop[i][j] == Router.inf ? "-" : nextHop[i][j]));
            }
            System.out.println("");
        }
    }
}
