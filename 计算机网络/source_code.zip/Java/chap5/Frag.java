import java.util.stream.IntStream;

public class Frag {
    static final int ipv4_header = 20;

    public static void main(String[] args) {
        Ip bigIp = new Ip(4000, 666);
        System.out.println("Big IP");
        System.out.println(bigIp);
        frag(bigIp, 1500);

        Ip ip1 = new Ip(1500, 888, 1, 0);
        Ip ip2 = new Ip(1500, 888, 1, 185);
        Ip ip3 = new Ip(1040, 888, 0, 370);
        reasm(ip1, ip2, ip3);
    }

    private static void frag(Ip ip, int mtu) {
        System.out.println("MTU：" + mtu);
        System.out.println("分组：");
        int data_len = ip.len - ipv4_header;
        int data_field = mtu - ipv4_header;
        int fragNum = (int) Math.ceil(data_len / (double) data_field);
        IntStream.rangeClosed(1, fragNum).forEach(i -> {
            boolean last_one = i == fragNum; // 👇 data_len + ipv4_header == ip.len，不过分开写更清楚
            Ip small_ip = new Ip(last_one ? data_len - (fragNum - 1) * data_field + ipv4_header : mtu, ip.id);
            small_ip.mf = i == fragNum ? 0 : 1;
            small_ip.offset = Math.floorDiv(data_field, 8) * (i - 1);
            System.out.println(small_ip);
        });
    }

    private static void reasm(Ip... ips) {
        System.out.println("\nFrag IP");
        for (Ip ip : ips) {
            System.out.println(ip);
        }
        System.out.println("重装：");
        Ip last_frag = ips[ips.length - 1];                 // 👇 可以删，但这样清楚
        int ip_len = last_frag.offset * 8 + last_frag.len - ipv4_header + ipv4_header;
        Ip new_ip = new Ip(ip_len, last_frag.id);
        System.out.println(new_ip);
    }

    private static class Ip {
        public final int df = 0; // 分段实验，df必定为0
        public int len, id, mf = 0, offset = 0;

        private Ip(int len, int id) {
            this.len = len;
            this.id = id;
        }

        private Ip(int len, int id, int mf, int offset) {
            this.len = len;
            this.id = id;
            this.mf = mf;
            this.offset = offset;
        }

        @Override
        public String toString() {
            return "Ip{" +
                    "len=" + len +
                    ", id=" + id +
                    ", mf=" + mf +
                    ", offset=" + offset +
                    ", df=" + df +
                    '}';
        }
    }
}
