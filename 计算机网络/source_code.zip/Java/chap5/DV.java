import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DV {
    final static int maxn = 5;
    static String inputFile = "topo.txt";

    static int n;
    static List<List<Integer>> neighbourList = new ArrayList<>(maxn);
    static Router[] routers = new Router[maxn];

    static String oldTopo;

    public static void main(String[] args) throws IOException {
        readTopo();
        System.out.println("==initially==");
        printTopo();
        iter();
        // 让用户改
        Scanner scanner = new Scanner(System.in);
        System.out.println("input `'x 'y 'distance` to alter topo");
        if (scanner.hasNextInt()) {
            int x = scanner.nextInt();
            int y = scanner.nextInt();
            int dis = scanner.nextInt();
            // xy之间距离变了，要改router[x].table[y][y]和反过来
            routers[x].table[y][y] = routers[y].table[x][x] = dis;
            routers[x].updateNextHop(y);
            routers[y].updateNextHop(x);
        }
        System.out.println("==initially==");
        printTopo();
        iter();
    }

    private static void printRouterTable() {
        for (int i = 0; i < n; i++) {
            System.out.println(routers[i]);
        }
    }

    static void readTopo() throws IOException {
        String line;
        // 👴 就不 try
        BufferedReader in = new BufferedReader(new FileReader(inputFile));
        for (int i = 0; null != (line = in.readLine()); i++) {
            if (line.startsWith("//")) {
                i--;
                continue;
            }
            String[] nums = line.split(" ");
            n = nums.length;
            routers[i] = new Router(i, n);
            neighbourList.add(new ArrayList<>());
            for (int j = 0; j < n; j++) {
                int cost = Integer.parseInt(nums[j]);
                routers[i].table[j][j] = cost;
                if (i != j && cost != Router.inf) {
                    neighbourList.get(i).add(j);
                    routers[i].next_hop[j] = j;
                }
            }
        }
        in.close();
    }

    private static void printTopo() {
        for (int i = 0; i < n; i++) {
            // routers[i]
            for (int j = 0; j < n; j++) {
                System.out.printf("%d ", routers[i].minCost(j));
            }
            System.out.print("\n");
        }
        printRouterTable();
    }

    private static boolean topoChanged() {
        // 本质就是检查和上回比每个路由有没有更短的路了
        // 也可以直接调用mincost比，不过还是字符串爽啊
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        PrintStream old = System.out;
        System.setOut(ps);
        printTopo();
        System.out.flush();
        System.setOut(old);
        if (baos.toString().equals(oldTopo)) return false;
        oldTopo = baos.toString();
        return true;
    }

    private static void iter() {
        int round = 0;
        while (true) {
            for (int number = 0; number < n; number++) {
                // 更新当前路由thisRouter的路由表
                for (int neighbour : neighbourList.get(number)) {
                    Router thisRouter = routers[number];
                    Router nighRouter = routers[neighbour];

                    // 给thisRouter.table填写via neighbour[]
                    for (int to = 0; to < n; to++) {
                        if (to == number || nighRouter.minCost(to) >= Router.inf) continue;
                        thisRouter.table[to][neighbour] = thisRouter.table[neighbour][neighbour] + nighRouter.minCost(to);
                        thisRouter.updateNextHop(to);
                    }
                }
            }
            if (topoChanged()) {
//            if (round != 16) {
                System.out.println("\n\n==after " + ++round + (round == 1 ? " exchange==" : " exchanges=="));
                printTopo();
            } else {
                break;
            }
        }
    }
}
