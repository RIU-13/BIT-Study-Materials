package network;

import java.util.HashMap;
import java.util.Scanner;

import jpcap.JpcapCaptor;
import jpcap.JpcapSender;
import jpcap.NetworkInterface;
import jpcap.PacketReceiver;
import jpcap.packet.EthernetPacket;
import jpcap.packet.IPPacket;
import jpcap.packet.Packet;
import jpcap.packet.TCPPacket;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
//InsideIP=192.168.0.0
//OutsideIP=211.68.9.10
//DestMAC=11-11-11-11-11-11

public class Nat {
	static HashMap<InetAddress,InetAddress>natMap;
	static NetworkInterface[] devices;
	static int index2;
	static class NatTranslate implements PacketReceiver {

		  public void receivePacket(Packet packet) {
			  System.out.println("转换前：");
	           EthernetPacket a=(EthernetPacket) packet.datalink;
				  System.out.print("	源MAC地址");
				  for (byte b : a.src_mac)
					  System.out.print(":"+Integer.toHexString(b&0xff));
				  System.out.println();
				  System.out.print("	目标MAC地址");
				  for (byte b : a.dst_mac)
					    System.out.print(":"+Integer.toHexString(b&0xff));
				  System.out.println();		
				  IPPacket ip = (IPPacket)packet;
	              System.out.println("	源地址 " + ip.src_ip.getHostAddress());
	              System.out.println("	目的地址 " + ip.dst_ip.getHostAddress());
	              TCPPacket tcp = (TCPPacket)ip;
              	System.out.println("	目标端口号：" + tcp.dst_port);
              	System.out.println("	源端口号：" + tcp.src_port);
              	System.out.println("NAT表：");
              	System.out.println("outsideIP	insideIP");
              	for (InetAddress key : natMap.keySet())
              	{
              		System.out.println(key.getHostAddress()+"	"+natMap.get(key).getHostAddress());
              	}
              	if(natMap.containsKey(ip.src_ip))
              	{	
              		System.out.println("该ip在NAT表中，开始转换并发送");
              		tcp.src_ip=natMap.get(ip.src_ip);
              		a.dst_mac=new byte[]{(byte)0x11,(byte)0x11,(byte)0x11,(byte)0x11,(byte)0x11,(byte)0x11};
              		tcp.datalink=a;
                    JpcapSender sender = null;
            		try {
            			sender = JpcapSender.openDevice(devices[index2]);
            			sender.sendPacket(tcp);
            		} catch (IOException e) {
            			// TODO Auto-generated catch block
            			e.printStackTrace();
            		}
            		sender.close();
                  System.out.println("转换后：");
  				  System.out.print("	源MAC地址");
  				  for (byte b : a.src_mac)
  					  System.out.print(":"+Integer.toHexString(b&0xff));
  				  System.out.println();
  				  System.out.print("	目标MAC地址");
  				  for (byte b : a.dst_mac)
  					    System.out.print(":"+Integer.toHexString(b&0xff));
  				  System.out.println();		
  				  IPPacket ip1 = (IPPacket)packet;
  	              System.out.println("	源地址 " + ip1.src_ip.getHostAddress());
  	              System.out.println("	目的地址 " + ip1.dst_ip.getHostAddress());
  	              TCPPacket tcp1 = (TCPPacket)ip1;
              	System.out.println("	目标端口号：" + tcp1.dst_port);
              	System.out.println("	源端口号：" + tcp1.src_port);
              		
              	}

		  }
		  }
	 public static void main(String[] args)
	    {
		 //NAT表初始化
		 natMap=new HashMap<InetAddress, InetAddress>();
		try {
			InetAddress insideIP=InetAddress.getByName("192.168.0.0");
			InetAddress outsideIP=InetAddress.getByName("211.68.9.10");
			natMap.put(insideIP, outsideIP);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		devices = JpcapCaptor.getDeviceList();
		for (int i = 0; i < devices.length; i++) {
		  System.out.println(i+": "+devices[i].name + "(" + devices[i].description+")");
		}
		Scanner scanner =new Scanner(System.in);
		System.out.println("请输入你选择的内网捕获适配器编号");
		int index1=scanner.nextInt();
		System.out.println("请输入你选择的外网转发适配器编号");
		index2=scanner.nextInt();
		scanner.close();
        JpcapCaptor jpcap = null;
        int caplen = 65535;//最大字节数
        boolean promiscCheck = true;//混杂模式
        int timeout=50;
        try{
            jpcap = JpcapCaptor.openDevice(devices[index1], caplen, promiscCheck, timeout);
            jpcap.setFilter("tcp", true);
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        jpcap.loopPacket(10,new NatTranslate());
        jpcap.close();
    }
		
	}