import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RoutingFind {
    static IpMask[] ipMasks = new IpMask[4];
    static String[] next_hops = new String[4];

    public static void main(String[] args) {
        ipMasks[0] = new IpMask("135.46.56.0", 22);
        next_hops[0] = "Interface0";
        ipMasks[1] = new IpMask("136.46.60.0", 22);
        next_hops[1] = "Interface1";
        ipMasks[2] = new IpMask("192.53.40.0", 23);
        next_hops[2] = "Router1";
        ipMasks[3] = new IpMask("0", 0);
        next_hops[3] = "Router2";
        for (int i = 0; i < ipMasks.length; i++) {
            IpMask im = ipMasks[i];
            System.out.println("network ip: " + im.ip_str + "\tmask: " + im.mask + "\tnext hop: " + next_hops[i]);
        }

        System.out.println("输入你的IP地址");
        Scanner scanner = new Scanner(System.in);
        long input_ip = string2ip(scanner.nextLine());
        match(input_ip);
        scanner.close();
    }

    static long string2ip(String ip_str) {
        String[] ip_parts = ip_str.split("\\.");
        List<Integer> ip_nums = Arrays.stream(ip_parts).map(Integer::parseInt).collect(Collectors.toCollection(ArrayList::new));
        return (ip_nums.get(0) << 24) + (ip_nums.get(1) << 16) + (ip_nums.get(2) << 8) + ip_nums.get(3);
    }

    static void match(long ip) {
        int max = 0;
        int next_hop = 0;
        for (int i = 0; i < ipMasks.length; i++) {
            IpMask im = ipMasks[i];
            if (ip >> im.shr == im.ip >> im.shr || im.ip == 0) {
                System.out.printf("第%d条路由：匹配\n", i + 1);
                if (max < im.mask) {
                    next_hop = i;
                }
            } else {
                System.out.printf("第%d条路由：不匹配\n", i + 1);
            }
        }
        System.out.println("下一跳是" + next_hops[next_hop]);
    }

    private static class IpMask {
        int mask;
        int shr;
        long ip;
        String ip_str;

        IpMask(String ip_str, int mask) {
            ip = ip_str.equals("0") ? 0 : RoutingFind.string2ip(ip_str);
            this.ip_str = ip_str;
            this.mask = mask;
            shr = 32 - mask;
        }
    }
}
