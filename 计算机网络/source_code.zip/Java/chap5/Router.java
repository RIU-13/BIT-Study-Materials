import java.util.Arrays;


public class Router {
    final static int inf = 99;

    public int number;
    public int[][] table;
    public int[] next_hop;

    public Router(int no, int n) {
        number = no;
        table = new int[n][n];
        for (int[] row : table) {
            Arrays.fill(row, inf);
        }
        next_hop = new int[n];
        Arrays.fill(next_hop, inf);
    }

    public int minCost(int to) {
        if (next_hop[to] != inf) return table[to][next_hop[to]];
        int min = inf;
        for (int from = 0; from < table[to].length; from++) {
            min = Math.min(min, table[to][from]);
        }
        return min;
    }

    public void updateNextHop(int to) {
        int cost = inf;
        for (int from = 0; from < table[to].length; from++) {
            if (cost > table[to][from]) {
                next_hop[to] = from;
                cost = table[to][from];
            }
        }
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("from ").append(number);
        for (int i = 0; i < table.length; i++) {
            sb.append("\tvia ").append(i);
        }
        sb.append(" next hop").append("\n");
        for (int to = 0; to < table.length; to++) {
            sb.append("to   ").append(to);
            for (int from = 0; from < table[to].length; from++) {
                sb.append("\t\t").append(table[to][from] >= inf ? "-" : table[to][from]);
            }
            sb.append(" \t\t").append(next_hop[to] >= inf? "-": next_hop[to]);
            sb.append("\n");
        }
        return sb.toString();
    }
}