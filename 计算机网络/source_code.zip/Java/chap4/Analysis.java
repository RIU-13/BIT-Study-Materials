package network;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Scanner;

import jpcap.JpcapCaptor;
import jpcap.NetworkInterface;
import jpcap.PacketReceiver;
import jpcap.packet.ARPPacket;
import jpcap.packet.EthernetPacket;
import jpcap.packet.ICMPPacket;
import jpcap.packet.IPPacket;
import jpcap.packet.Packet;
import jpcap.packet.TCPPacket;
import jpcap.packet.UDPPacket;

public class Analysis {
	static class PacketPrinter implements PacketReceiver {

		  public void receivePacket(Packet packet) {
			  //数据链路帧解析
			  System.out.println("数据链路层：");
	           EthernetPacket a=(EthernetPacket) packet.datalink;
	            String Ethernettype ="";
	            switch(new Integer(a.frametype))
	            {
	                case 0x0800:Ethernettype = "IP";break;
	                case 0x86DD:Ethernettype = "IPv6";break;
	                case 0x0806:Ethernettype = "ARP";break;
	               
	                default : Ethernettype = "其他未定义的帧类型";break;
	            }
				  System.out.println("	帧类型："+Ethernettype);
				  System.out.print("	源MAC地址");
				  for (byte b : a.src_mac)
					  System.out.print(":"+Integer.toHexString(b&0xff));
				  System.out.println();
				  System.out.print("	目标MAC地址");
				  for (byte b : a.dst_mac)
					    System.out.print(":"+Integer.toHexString(b&0xff));
				  System.out.println();
	         	//网络层解包
				  System.out.println("网络层解包：");
	            if(packet instanceof IPPacket)//ip数据包解包
	            {
	                IPPacket ip = (IPPacket)packet;//强转
	                System.out.println("	版本：IPv"+((IPPacket)packet).version);
	                System.out.println("	优先权：" + ip.priority);
	                System.out.println("	IP flag bit: [D]elay："+ip.d_flag);
	                System.out.println("	IP flag bit: [T]hrough：" + ip.t_flag);
	                System.out.println("	IP flag bit: [R]eliability：" + ip.r_flag);
	                System.out.println("	长度：" + ip.length);
	                System.out.println("	标识：" + ip.ident);
	                System.out.println("	Fragmentation reservation flag：" + ip.rsv_frag);
	                System.out.println("	Don't fragment flag: " + ip.dont_frag);
	                System.out.println("	More fragment flag  " + ip.more_frag);
	                System.out.println("	片偏移：" + ip.offset);
	                System.out.println("	生存时间："+ ip.hop_limit);
	                System.out.println("	源地址 " + ip.src_ip.getHostAddress());
	                System.out.println("	目的地址 " + ip.dst_ip.getHostAddress());
	                
	                String protocol ="";
	                System.out.println("运输层解包");
	                switch(new Integer(ip.protocol))
	                {
	                    case 1:
	                    	protocol = "ICMP";
	                    	System.out.println("	协议类型：" + protocol);
	                    	ICMPPacket icmp =(ICMPPacket)ip;
	                    	System.out.println("	Address entry size：" + icmp.addr_entry_size);
	                    	System.out.println("	The number of advertised addresses：" + icmp.addr_num);
	                    	System.out.println("	Address alive time：" + icmp.alive_time);
	                    	System.out.println("	Checksum：" + icmp.checksum);
	                    	System.out.println("	ICMP code：" + icmp.code);
	                    	System.out.println("	ID：" + icmp.id);
	                    	System.out.println("	MTU：" + icmp.mtu);
	                    	System.out.println("	Originate timestamp：" + icmp.orig_timestamp);
	                    	System.out.println("	Receive timestamp：" + icmp.recv_timestamp);
	                    	System.out.println("	Sequence number：" + icmp.seq);
	                    	System.out.println("	Subnet mask：" + icmp.subnetmask);
	                    	System.out.println("	Transmit timestamp：" + icmp.trans_timestamp);
	                    	System.out.println("	Redirect address：" + icmp.redir_ip);
	                    	System.out.print("	Advertised addresses:");
	                    	for (InetAddress x:icmp.router_ip)
	                    	{
	                    		System.out.print(" "+x);	               
	                    	}
	                    	System.out.println();
	                    	System.out.println("	ICMP type：" + icmp.type);
	                    	//router_ip还没写
	                    	break;
	                    case 6:
	                    	protocol = "TCP";
	                    	System.out.println("	协议类型：" + protocol);
	                    	TCPPacket tcp = (TCPPacket)ip;
	                    	System.out.println("	ACK flag：" + tcp.ack);
	                    	System.out.println("	ACK number：" + tcp.ack_num);
	                    	System.out.println("	目标端口号：" + tcp.dst_port);
	                    	System.out.println("	FIN flag：" + tcp.fin);
	                    	System.out.println("	PSH flag：" + tcp.psh);
	                    	System.out.println("	RST flag：" + tcp.rst);
	                    	System.out.println("	RSV1 flag：" + tcp.rsv1);
	                    	System.out.println("	RSV2 flag：" + tcp.rsv2);
	                    	System.out.println("	Sequence number：" + tcp.sequence);
	                    	System.out.println("	源端口号：" + tcp.src_port);
	                    	System.out.println("	SYN flag：" + tcp.syn);
	                    	System.out.println("	URG flag：" + tcp.urg);
	                    	System.out.println("	Urgent pointer：" + tcp.urgent_pointer);
	                    	System.out.println("	Window size：" + tcp.window);
	                    	System.out.println("应用层解析：");//TODO:应用层不知道怎么解析
	                    	if((tcp.dst_port==80||tcp.src_port==80)) {
	                    		System.out.println("	协议类型：HTTP协议");
	                        }else if(tcp.dst_port==443||tcp.src_port==443) {
	                        	System.out.println("	协议类型：HTTPS协议");
	                        }
	                    	break;
	                    case 17:
	                    	protocol = "UDP";
	                    	System.out.println("	协议类型：" + protocol);
	                    	UDPPacket udp = (UDPPacket)ip;
	                    	System.out.println("	目标端口号：" + udp.dst_port);
	                    	System.out.println("	源端口号：" + udp.src_port);
	                    	System.out.println("	包长度：" + udp.length);
	                    	break;
	                    case 41:
	                    	protocol = "IPv6";
	                    	System.out.println("	协议类型：" + protocol);
	                    	break;
	                    default :
	                    	protocol = "其他未定义的类型"; 
	                    	System.out.println("	协议类型：" + protocol);
	                    	break;
	                }
	                System.out.println("----------------------------------------------");
	            }else if (packet instanceof ARPPacket) {//ARP数据包解包
	            	ARPPacket arp = (ARPPacket)packet;
	            	System.out.println("	硬件地址的类型：" + arp.hardtype);
	            	System.out.println("	表示硬件地址的长度：" + arp.hlen);	            	System.out.println("	硬件地址的类型：" + arp.hardtype);
	            	System.out.println("	发送方要映射的协议地址类型：" + arp.prototype);	            	System.out.println("	硬件地址的类型：" + arp.hardtype);
	            	System.out.println("	协议地址的长度：" + arp.plen);
	            	System.out.print("	操作类型：");
		            switch(arp.operation)
		            {
		                case 1:System.out.println("ARP请求");break;
		                case 2:System.out.println("ARP应答");break;
		                case 3:System.out.println("RARP请求");break;
		                case 4:System.out.println("RARP应答");break;
		                default : break;
		            }
					  System.out.print("	发送方以太网地址");
					  for (byte b : arp.sender_hardaddr)
						  System.out.print(":"+Integer.toHexString(b&0xff));
					  System.out.println();
					  System.out.print("	发送方的IP地址");
					  for (byte b : arp.sender_protoaddr)
						  System.out.print(","+((int)b& 0xff));
					  System.out.println();
					  System.out.print("	接收方的以太网地址");
					  for (byte b : arp.target_hardaddr)
						  System.out.print(":"+Integer.toHexString(b&0xff));
					  System.out.println();
					  System.out.print("	接收方的IP地址");
					  for (byte b : arp.target_protoaddr)
						  System.out.print(","+((int)b&0xff));
					  System.out.println();
	            	System.out.println("----------------------------------------------");
				}
		 
		  }
		}
    public static void main(String[] args)
    {
    	NetworkInterface[] devices = JpcapCaptor.getDeviceList();
    	for (int i = 0; i < devices.length; i++) {
    	  System.out.println(i+": "+devices[i].name + "(" + devices[i].description+")");
    	}
    	Scanner scanner =new Scanner(System.in);
    	System.out.println("请输入你选择的网卡序号");
    	int outindex=scanner.nextInt();
    	scanner.close();
        JpcapCaptor jpcap = null;
        int caplen = 65535;//最大字节数
        boolean promiscCheck = true;//混杂模式
        int timeout=50;
        try{
            jpcap = JpcapCaptor.openDevice(devices[outindex], caplen, promiscCheck, timeout);
            //jpcap.setFilter("arp", true);
        }catch(IOException e)
        {
            e.printStackTrace();
        }
        jpcap.loopPacket(10,new PacketPrinter());
        jpcap.close();
    }
}
