package network;

import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import com.sun.org.apache.bcel.internal.generic.NEW;

import jpcap.JpcapCaptor;
import jpcap.JpcapSender;
import jpcap.NetworkInterface;
import jpcap.PacketReceiver;
import jpcap.packet.EthernetPacket;
import jpcap.packet.Packet;

public class Bridge {
	static NetworkInterface[] devices;
	static HashMap<String,Integer>routeMap;
	static class MutiThread extends Thread{
		public int index;
		public JpcapCaptor jCaptor;
		public MutiThread(int i,JpcapCaptor j) {
			index=i;
			jCaptor=j;
		}
		 @Override 
		 public void run() {
			 jCaptor.loopPacket(-1,new PacketPrinter(index));
		 }
	}
	static class PacketPrinter implements PacketReceiver {
		int index;
		public PacketPrinter(int i) {
			index=i;
		}
	  public void receivePacket(Packet packet) {
		  //数据链路帧解析
		  System.out.println("网卡序号:"+index);
		  System.out.println("当前路由表：");
		  for (String key : routeMap.keySet()) {
			 byte[] keybytes=hexStrToByteArray(key);
			  for (byte b : keybytes)
				  System.out.print(":"+Integer.toHexString(b&0xff));
			  System.out.println("	"+routeMap.get(key));
			 }
		  System.out.println("接收到数据帧：");
           EthernetPacket a=(EthernetPacket) packet.datalink;
            String Ethernettype ="";
            switch(new Integer(a.frametype))
            {
                case 0x0800:Ethernettype = "IP";break;
                case 0x86DD:Ethernettype = "IPv6";break;
                case 0x0806:Ethernettype = "ARP";break;         
                default : Ethernettype = "其他未定义的帧类型";break;
            }
			  System.out.println("	帧类型："+Ethernettype);
			  System.out.print("	源MAC地址");
			  for (byte b : a.src_mac)
				  System.out.print(":"+Integer.toHexString(b&0xff));
			  System.out.println();
			  System.out.print("	目标MAC地址");
			  for (byte b : a.dst_mac)
				    System.out.print(":"+Integer.toHexString(b&0xff));
			  System.out.println();
			  if(routeMap.containsKey(byteArrayToHexStr(a.src_mac)))
			  {
				  System.out.println("路由表中已有，无需添加");
//				  System.out.println("存在！");
//				  System.out.print("	源MAC地址");
//				  for (byte b : a.src_mac)
//					  System.out.print(":"+Integer.toHexString(b&0xff));
//				  System.out.println();
//				  System.out.println(routeMap.get(new String(a.src_mac)));
			  }else {
				  System.out.println("添加路由表");
				  routeMap.put(byteArrayToHexStr(a.src_mac), new Integer(index));
			}
			  if(routeMap.containsKey(byteArrayToHexStr(a.dst_mac)))
			  {
				  System.out.println("在路由表中找到目的地址");
				  if(routeMap.get(byteArrayToHexStr(a.dst_mac)).equals(new Integer(index)))
				  {
					  System.out.println("目的地址与源地址在同一端，废弃该数据帧");
				  }else {
					  System.out.println("目的地址与源地址在不同端，转发数据帧");
				        JpcapSender sender = null;
						try {
							sender = JpcapSender.openDevice(devices[(int)routeMap.get(new String(a.dst_mac))]);
							sender.sendPacket(packet);
							sender.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
				}
			  }
			  else {
				System.out.println("路由器中并没有找到目的地址，采用泛洪算法发送");
				JpcapSender sender = null;
		    	for (int i = 0; i < devices.length; i++) {
		    		if (index ==i) continue;
		    		try {
						sender = JpcapSender.openDevice(devices[i]);
						sender.sendPacket(packet);
						sender.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
			    	}		
			}
			  System.out.println("----------------------------------------------------------------------------------------------");
			}
	
		}
	 public static void main(String[] args)
	    {
	    	devices = JpcapCaptor.getDeviceList();
	    	for (int i = 0; i < devices.length; i++) {
	    	  System.out.println(i+": "+devices[i].name + "(" + devices[i].description+")");
	    	}
	    	Scanner scanner =new Scanner(System.in);
	    	System.out.println("请输入你选择的网卡1序号");
	    	int index1=scanner.nextInt();
	    	System.out.println("请输入你选择的网卡2序号");
	    	int index2=scanner.nextInt();
	    	scanner.close();
	        JpcapCaptor jpcap1 = null;
	        JpcapCaptor jpcap2 = null;
	        int caplen = 65535;//最大字节数
	        boolean promiscCheck = true;//混杂模式
	        int timeout=50;
	        routeMap=new HashMap<String,Integer>();
	        try{
	            jpcap1 = JpcapCaptor.openDevice(devices[index1], caplen, promiscCheck, timeout);
	            jpcap2 = JpcapCaptor.openDevice(devices[index2], caplen, promiscCheck, timeout);
	        }catch(IOException e)
	        {
	            e.printStackTrace();
	        }  
	        //jpcap1.loopPacket(10,new PacketPrinter(index1));
	        MutiThread thread1=new MutiThread(index1, jpcap1);
	        MutiThread thread2=new MutiThread(index2, jpcap2);
	        thread1.start();
	        thread2.start();
	        	             	      	 	        
	        
	    }
	 public static String byteArrayToHexStr(byte[] byteArray) {
		    if (byteArray == null){
		        return null;
		    }
		    char[] hexArray = "0123456789ABCDEF".toCharArray();
		    char[] hexChars = new char[byteArray.length * 2];
		    for (int j = 0; j < byteArray.length; j++) {
		        int v = byteArray[j] & 0xFF;
		        hexChars[j * 2] = hexArray[v >>> 4];
		        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		    }
		    return new String(hexChars);
		}
	 public static byte[] hexStrToByteArray(String str)
	 {
	     if (str == null) {
	         return null;
	     }
	     if (str.length() == 0) {
	         return new byte[0];
	     }
	     byte[] byteArray = new byte[str.length() / 2];
	     for (int i = 0; i < byteArray.length; i++){
	         String subStr = str.substring(2 * i, 2 * i + 2);
	         byteArray[i] = ((byte)Integer.parseInt(subStr, 16));
	     }
	     return byteArray;
	 }
}
