import java.security.MessageDigest;
import java.security.SecureRandom;

public class Chap {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Please specify your password.");
            return;
        }

        String password = args[0];
        System.out.println("Your password is: " + password);

        MessageDigest md5 = MessageDigest.getInstance("MD5");

        SecureRandom random = new SecureRandom();
        byte[] challenge = new byte[16];
        random.nextBytes(challenge);
        System.out.println("Challenge is: " + bytes2hex(challenge));

        System.out.println("Digest is: " + bytes2hex(md5.digest((password + bytes2hex(challenge)).getBytes())));

    }

    private static String bytes2hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        String tmp;
        for (byte b :
                bytes) {
            tmp = Integer.toHexString(0xff & b);
            if (1 == tmp.length()) {
                tmp = "0" + tmp;
            }
            sb.append(tmp);
        }
        return sb.toString();
    }
}
