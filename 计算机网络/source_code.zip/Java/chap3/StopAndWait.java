import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class StopAndWait {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        InetSocketAddress recvAddr = new InetSocketAddress("localhost", 8889);
        InetSocketAddress sendAddr = new InetSocketAddress("localhost", 8888);

        System.out.println("recv/send?");
        String option = scanner.nextLine();

        String filePath = null;
        if (option.equals("recv") || option.equals("send")) {
            System.out.println(option + "file path?");
            filePath = scanner.nextLine();
        } else {
            System.err.println("Invalid option!");
            System.exit(1);
        }
        File file = new File(filePath);

        System.out.println("start?[y/n]");
        if (scanner.nextLine().equals("y")) {
            System.out.println(option + "er started.");
            if (option.equals("recv")) {
                Host host = new Host(recvAddr, sendAddr);
                host.recvFile(file);
            } else {
                Host host = new Host(sendAddr, recvAddr);
                host.sendFile(file);
            }
        } else {
            System.out.println("OK, bye.");
        }
    }

    private static class Host {
        Frame s = new Frame();
        DatagramSocket udpSocket;
        DatagramPacket packet;
        ThreadLocalRandom random = ThreadLocalRandom.current();
        final int filterError = 10, filterLost = 10;

        private Host(InetSocketAddress selfAddr, InetSocketAddress peerAddr) throws IOException {
            udpSocket = new DatagramSocket(selfAddr);
            // 👇 只是初始化一下大小
            byte[] data = convertToBytes(s);
            packet = new DatagramPacket(data, data.length, peerAddr);
        }

        private void sendFile(File file) throws IOException, ClassNotFoundException {
            udpSocket.setSoTimeout(5000);

            FileInputStream inputStream = new FileInputStream(file);
            int next_frame_to_send = 0;
            s.length=inputStream.read(s.info);
            while (true) {
                s.seq = next_frame_to_send;
                s.crc = crc_ccitt(s.info);

                if (0 == random.nextInt(0, filterLost)) {
                    System.out.println("********模拟丢帧********");
                } else {
                    if (0 == random.nextInt(0, filterError)) {
                        System.out.println("********模拟出错********");
                        s.crc++;
                    } else {
                        System.out.println("--------正确发送--------");
                    }
                    packet.setData(convertToBytes(s));
                    udpSocket.send(packet);
                }
                System.out.println("next_frame_to_send = " + next_frame_to_send);
                System.out.println("seq = " + s.seq);
                System.out.println("data = " + bytesToHex(s.info));
                System.out.println("CRC-CCITT = " + Integer.toHexString(s.crc));
                System.out.println("-----------------------");

                try {
                    udpSocket.receive(packet);
                } catch (SocketTimeoutException e) {
                    // 没收到ack，重发
                    continue;
                }

                s = (Frame) convertFromBytes(packet.getData());
                if (next_frame_to_send == s.ack) {
                    System.out.println("--------收到确认--------");
                    System.out.println("ack = " + s.ack);
                    System.out.println("-----------------------");

                    // 重要，否则最后一次读文件若没装够整个s.info，接收方收到的是残留上次信息的s.info
                    // 也可以每次都new一个Frame出来，但要改循环，再说吧。

                    Arrays.fill(s.info, (byte) 0);
                    if (-1 == (s.length=inputStream.read(s.info))) {
                        inputStream.close();
                        break;
                    }
                 
                    next_frame_to_send++;
                }
            }
            udpSocket.close();
        }

        private void recvFile(File file) throws IOException, ClassNotFoundException {
            FileOutputStream outputStream = new FileOutputStream(file);
            udpSocket.setSoTimeout(15000);

            int frame_expected = 0;

            while (true) {
                try {
                    udpSocket.receive(packet);
                } catch (SocketTimeoutException e) {
                    System.out.println("RECV TIME OUT!");
                    break;
                }
                s = (Frame) convertFromBytes(packet.getData());

                if (crc_ccitt(s.info) != s.crc) {
                    System.out.println("********接受出错********");
                    System.out.println("校验和出错！");
                    System.out.println("frame_expected = " + frame_expected);
                    System.out.println("-----------------------");
                } else if (frame_expected == s.seq) {
                    System.out.println("--------接收正确--------");
                    System.out.println("frame_expected = " + frame_expected);
                    System.out.println("seq = " + s.seq);
                    System.out.println("data = " + bytesToHex(s.info));
                    System.out.println("CRC-CCITT = " + Integer.toHexString(s.crc));
                    System.out.println("-----------------------");

                    outputStream.write(s.info, 0, s.length);
                    outputStream.flush();

                    frame_expected++;
                }
                s.ack = frame_expected - 1;

                System.out.println("--------发送确认--------");
                System.out.println("ack = " + s.ack);
                System.out.println("-----------------------");

                packet.setData(convertToBytes(s));
                udpSocket.send(packet);
            }
            outputStream.close();
            udpSocket.close();
        }

        private byte[] convertToBytes(Object object) throws IOException {
            try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
                 ObjectOutput out = new ObjectOutputStream(bos)) {
                out.writeObject(object);
                out.flush();
                return bos.toByteArray();
            }
        }

        private Object convertFromBytes(byte[] bytes) throws IOException, ClassNotFoundException {
            try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
                 ObjectInput in = new ObjectInputStream(bis)) {
                return in.readObject();
            }
        }

        private int crc_ccitt(byte[] bytes) {
//            https://introcs.cs.princeton.edu/java/61data/CRC16CCITT.java.html
            int crc = 0x0000;          // initial value
            int polynomial = 0x1021;  
            for (byte b : bytes) {
                for (int i = 0; i < 8; i++) {
                    boolean bit = ((b >> (7 - i) & 1) == 1);
                    boolean c15 = ((crc >> 15 & 1) == 1);
                    crc <<= 1;
                    if (c15 ^ bit) crc ^= polynomial;
                }
            }
            crc &= 0xffff;
            return crc;
        }

        // https://stackoverflow.com/a/9855338
        private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

        public static String bytesToHex(byte[] bytes) {
            char[] hexChars = new char[bytes.length * 2];
            for (int j = 0; j < bytes.length; j++) {
                int v = bytes[j] & 0xFF;
                hexChars[j * 2] = HEX_ARRAY[v >>> 4];
                hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
            }
            return new String(hexChars);
        }

        private static class Frame implements Serializable {
            int seq;
            int ack;
            int length;
            byte[] info = new byte[1024];
            int crc;
        }
    }
}
