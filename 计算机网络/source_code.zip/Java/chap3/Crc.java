public class Crc {
	public static void main(String[] args) {
		String InfoString1="10101011000100101010101010101010";
		String GenXString="10001000000100001";
		String infoString2;//1010101100010010101010101010101011111101111111
		Long n;
		n=Long.parseLong(InfoString1, 2);//16修改为2为输入比特流
		System.out.println("明文信息："+InfoString1);
		System.out.println("生成多项式："+GenXString);
		Long crccode =get_CRC_CCITT(n, GenXString);
		String crcString=Long.toBinaryString(crccode);
		while (crcString.length()<16) {
			crcString="0"+crcString;
		}
		System.out.println("生成CRC校验码："+crcString);
		infoString2=InfoString1+crcString;
		System.out.println("最后生成："+infoString2);
		Long modLong;
		if((modLong=check_crc(Long.parseLong(infoString2, 2)))==0)
		{
			System.out.println("余数为0，检验成功！");
		}else {
			System.out.println("余数为"+Long.toBinaryString(modLong)+",校验失败！");
		}
	}
	public static Long get_CRC_CCITT(Long data,String GenXString) {
		Long crc = new Long(0);
		Long ax = new Long(0), bx =new Long(0), cx = new Long(0);
		Long px = Long.parseLong(GenXString, 2); //生成多项式
	    data <<= 16;        //信息左移16位，共48位 
	    ax = data >>> 31;  //将前17位存在ax中，准备与多项式px做异或操作 存在ax的低位 
	    data <<= 33;   //除了前17位后剩下的31位 33=17+16 在64位的高位 
	    for (cx = (long) 31; cx > 0; cx--)
	    {     
	        if (((ax >>> 16) & 0x1) == 0x1)
	        {
	            ax = ax ^ px;
	        } 

	        ax <<= 1;
	        bx = data >>> 63;
	        ax = ax + bx;        
	        data <<= 1;
	    }

	    if (((ax >>> 16) & 0x1) == 0x1)  //最后一位的异或操作
	    {
	        ax = ax ^ px;        
	    }

	    crc = ax; 
		return crc;
	}
	static Long check_crc(Long data)    //计算 加密信息%多项式==0则正确 
	{
	    Long  ax = (long) 0, bx = (long) 0, cx = (long) 0;
	    Long px = (long) 0x11021;
	    ax = data >>> 31;
	    data <<= 33;
	    for (cx = (long) 31; cx > 0; cx--)
	    {        
	        if (((ax >>> 16) & 0x1) == 0x1)
	        {
	            ax = ax ^ px;
	        }
	        ax <<= 1;        
	        bx = data >>> 63;        
	        ax = ax + bx;        
	        data <<= 1;
	    }
	    if (((ax >>> 16) & 0x1) == 0x1)
	    {
	        ax = ax ^ px;        
	    }
	    return ax;
	}

}
