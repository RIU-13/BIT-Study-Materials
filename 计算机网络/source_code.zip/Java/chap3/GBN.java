
import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Scanner;

public class GBN {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        InetSocketAddress recvAddr = new InetSocketAddress("localhost", 8889);
        InetSocketAddress sendAddr = new InetSocketAddress("localhost", 8888);

//        System.out.println("recv/send?");
//        String option = scanner.nextLine();
//
//        if (!option.equals("recv") && !option.equals("send")) {
//            System.err.println("Invalid option!");
//            System.exit(1);
//        }
//        System.out.println("file to recv");
//        String recvFilePath = scanner.nextLine();
//        System.out.println("file to send");
//        String sendFilePath = scanner.nextLine();
//
//        File recvFile = new File(recvFilePath);
//        File sendFile = new File(sendFilePath);
//
//        System.out.println("start?[y/n]");
//        if (scanner.nextLine().equals("y")) {
//            System.out.println(option + "er started.");
//            if (option.equals("recv")) {
//                Host host = new Host(recvAddr, sendAddr, option, recvFile, sendFile);
//                host.start();
//            } else {
//                Host host = new Host(sendAddr, recvAddr, option, recvFile, sendFile);
//                host.start();
//            }
//        } else {
//            System.out.println("OK, bye.");
//        }2
        System.out.println(">>>");
        if (scanner.nextLine().equals("1")) {
            Host host = new Host(recvAddr, sendAddr, "send", new File("1.txt"), new File("test1.txt"));
            host.start();
        } else {
            Host host = new Host(sendAddr, recvAddr, "recv", new File("2.txt"), new File("test2.txt"));
            host.start();
        }
    }
}
