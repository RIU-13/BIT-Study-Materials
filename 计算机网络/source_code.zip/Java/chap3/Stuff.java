public class Stuff {
	public static void main(String[] args) {
		System.out.println("字节填充");
		bytestuff();
		System.out.println("比特填充");
		bitstuff();//比特填充
	}
	public static void bytestuff() {
		StringBuilder InfoString1=new StringBuilder("347D7E807E40AA7D");
		String FlagString="7E";
		String EscString="00";
		System.out.println("帧起始标志和结束标志为:"+FlagString);
		System.out.println("转义字符:"+EscString);
		System.out.println("待发送数据:"+InfoString1);
		int offset=-4;
		while ((offset=InfoString1.indexOf(EscString,offset+4))>=0&&offset%2==0) {//先判断转义
			InfoString1.insert(offset, EscString);
		}
		while ((offset=InfoString1.indexOf(FlagString,offset+4))>=0&&offset%2==0) {//再判断Flag
			InfoString1.insert(offset, EscString);
		}
		InfoString1=InfoString1.insert(0, FlagString).append(FlagString);
		System.out.println("字节填充后数据:"+InfoString1);
		offset=0;
		while (!(InfoString1.toString().subSequence(offset, offset+2).equals(FlagString)&&(offset<2||!InfoString1.toString().subSequence(offset-2, offset).equals(EscString)))) {
			//找到起始标志：找到FlagString且前一个字节不为EscString
			offset+=2;
		}
		InfoString1.delete(0, offset+2);//去掉起始标志以及之前
//		offset=0;
//		while (!(InfoString1.toString().subSequence(offset, offset+2).equals(FlagString)&&(offset<2||!InfoString1.toString().subSequence(offset-2, offset).equals(EscString)))) {
//			//找到结束标志：找到FlagString且前一个字节不为EscString，似乎不能这么找，可能之前正好是00 00 7E,先不管
//			offset+=2;
//		}
//		InfoString1.delete(offset,InfoString1.length());//去掉结束标志及之后
		StringBuilder InfoString2=new StringBuilder();
		offset=0;
		while (offset<InfoString1.length()) {
			if (InfoString1.toString().subSequence(offset, offset+2).equals(EscString))
			{
				InfoString2.append(InfoString1.toString().subSequence(offset+2, offset+4));
				InfoString1.delete(offset, offset+2);
				offset=offset+2;
			}else if (InfoString1.toString().subSequence(offset, offset+2).equals(FlagString)) {
				break;//找到结束标志结束
			}else {
				InfoString2.append(InfoString1.toString().subSequence(offset, offset+2));
				offset=offset+2;
			}
			
		}System.out.println("删除比特填充后接受数据帧:"+InfoString2.toString());
	}
	public static void bitstuff() {
		StringBuilder InfoString1=new StringBuilder("01100110111111111111101001010110");
		String FlagString="01111110";
		System.out.println("帧起始标志和结束标志为:"+FlagString);
		System.out.println("待发送数据:"+InfoString1);
		int offset=-6;
		while ((offset=InfoString1.indexOf("11111",offset+6))>=0) {
			InfoString1.insert(offset+5, "0");
		}
		InfoString1=InfoString1.insert(0, FlagString).append(FlagString);
		System.out.println("比特填充后数据:"+InfoString1);
		offset=0;
		while ((offset=InfoString1.indexOf("01111110"))>=0) {//删去起始结束标志
			InfoString1.delete(offset, offset+8);
		}
		offset=-5;
		while ((offset=InfoString1.indexOf("111110",offset+5))>=0) {//删去起始结束标志
			InfoString1.delete(offset+5, offset+6);
		}
		System.out.println("删除比特填充后接受数据帧:"+InfoString1);
	}
}
