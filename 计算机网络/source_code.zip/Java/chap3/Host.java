import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Host {
    DatagramSocket udpSocket;
    String option;
    FileOutputStream outputStream;
    FileInputStream inputStream;
    InetSocketAddress peerAddr;
    boolean read_finished = false;
    boolean send_finished = false;
    boolean recv_finished = false;
    ThreadLocalRandom random = ThreadLocalRandom.current();
    final int filterError = 10, filterLost = 10;
    final int timeout = 500;


    List<Frame> sent_list = new ArrayList<>();

    public Host(InetSocketAddress selfAddr, InetSocketAddress peerAddr, String option, File recvFile, File sendFile) throws IOException {
        udpSocket = new DatagramSocket(selfAddr);
        udpSocket.setSoTimeout(timeout);
        this.option = option;
        this.peerAddr = peerAddr;

        outputStream = new FileOutputStream(recvFile);
        inputStream = new FileInputStream(sendFile);
    }

    public void start() throws IOException, ClassNotFoundException {
        if (option.equals("recv")) {
            startRecv();
        } else {
            startSend();
        }
    }

    private void send_data(Frame s) throws IOException {
        s.time = System.currentTimeMillis();
        byte[] data = convertToBytes(s);
        DatagramPacket packet = new DatagramPacket(data, data.length, peerAddr);

       if (0 == random.nextInt(0, filterLost)) {
           System.out.println("���� " + s);
       } else {
           if (0 == random.nextInt(0, filterError)) {
               System.out.println("���� " + s.seq);
               s.crc++;
           }
            udpSocket.send(packet);
            System.out.println("sent " + s);
       }
        sent_list.add(s);
    }

    private void startRecv() throws IOException, ClassNotFoundException {
        int frame_expected = 0;
        int next_frame_to_send = 0;
        int ack_expected = 0;
        boolean first_time = true;

        while (true) {
            byte[] data = convertToBytes(new Frame());
            Arrays.fill(data, (byte) 0);
            DatagramPacket packet = new DatagramPacket(data, data.length);
            try {
                udpSocket.receive(packet);
            } catch (SocketTimeoutException e) {
                if (first_time) {
                    continue;
                }
            }

            first_time = false;

            Frame r;
            data = packet.getData();
            byte cnt = 0;
            for (byte datum : data) {
                cnt += datum;
            }
            if ((byte) 0 == cnt) {
                // �ǿռ䴫����ȫ�����
                r = new Frame();
            } else {
                r = (Frame) convertFromBytes(packet.getData());
            }

            frame_expected = frame_arrival(frame_expected, r);

            Frame s = new Frame();
            s.ack = frame_expected - 1;
            s.seq = next_frame_to_send++;

            from_network_layer(s);
            if (-1 == s.length) {
                read_finished = true;
                inputStream.close();
                System.out.println("READ finished");
            }

            s.crc = crc_ccitt(s.info);
            send_data(s);

            check_timer();
            if (read_finished && sent_list.isEmpty()) {
                send_finished = true;
                System.out.println("SEND finished");
            }
            if ((send_finished && recv_finished) || ((cnt == 0) && recv_finished)) {
                break;
            }
        }
    }

    private void startSend() throws IOException, ClassNotFoundException {
        int frame_expected = 0;
        int next_frame_to_send = 0;
        int ack_expected = 0; //sent_list����С��seq
        while (true) {
            Frame s = new Frame();
            s.seq = next_frame_to_send++;
            s.ack = frame_expected - 1;
            from_network_layer(s);
            if (-1 == s.length) {
                read_finished = true;
                inputStream.close();
                System.out.println("READ finished");
            }
            s.crc = crc_ccitt(s.info);
            send_data(s);
            DatagramPacket packet = new DatagramPacket(convertToBytes(s), convertToBytes(s).length);
            try {
                udpSocket.receive(packet);
            } catch (SocketTimeoutException ignored) {
            }

            Frame r = (Frame) convertFromBytes(packet.getData());
            assert r != null;

            frame_expected = frame_arrival(frame_expected, r);

            check_timer();


            if (read_finished && sent_list.isEmpty()) {
                send_finished = true;
                System.out.println("SEND finished");
            }

            if (send_finished && recv_finished) {
                break;
            }
        }
    }

    private int frame_arrival(int frame_expected, Frame r) throws IOException {
        System.out.println("recv " + r);
        if (frame_expected == r.seq && -1 == r.length) {
            recv_finished = true;
            System.out.println("RECV finished");
            outputStream.close();
        }

        if (r.crc == crc_ccitt(r.info) && r.seq == frame_expected) {
            // ���������л�Ʈ��infoȫ0��length=-1�İ�������д�ļ�����
            if (r.length > 0) {
                to_network_layer(r);
            }
            frame_expected++;
        }
        //todo while ack
        sent_list.removeIf((Frame ss) -> ss.seq <= r.ack);
        return frame_expected;
    }

    private void check_timer() throws IOException {
        if (!sent_list.isEmpty()) {
            long current = System.currentTimeMillis();
            List<Frame> timeout_list = new ArrayList<>(sent_list);

            System.out.println("----------------");
            sent_list.removeIf((Frame ss) -> current - ss.time > timeout);
            timeout_list.removeAll(sent_list);

            timeout_list.forEach((Frame ss) -> System.out.println("��ʱ " + ss));
            System.out.println("----------------");

            for (Frame ss : timeout_list) {
                send_data(ss);
            }
        }
    }

    private void from_network_layer(Frame s) throws IOException {
        // ��ʵ���Ƕ��ļ�
        if (read_finished) {
            s.length = 0;
            Arrays.fill(s.info, (byte) 1);
        } else {
            s.length = inputStream.read(s.info);
            System.out.println("��ȡ " + s.length + "�ֽ�");
        }
    }

    private void to_network_layer(Frame r) throws IOException {
        // ��ʵ����д�ļ�
        System.out.println("д�� " + r.length + "�ֽ�");
        outputStream.write(r.info, 0, r.length);
        outputStream.flush();
    }

    private int crc_ccitt(byte[] bytes) {
//            https://introcs.cs.princeton.edu/java/61data/CRC16CCITT.java.html
        int crc = 0x0000;          // initial value
        int polynomial = 0x1021;
        for (byte b : bytes) {
            for (int i = 0; i < 8; i++) {
                boolean bit = ((b >> (7 - i) & 1) == 1);
                boolean c15 = ((crc >> 15 & 1) == 1);
                crc <<= 1;
                if (c15 ^ bit) crc ^= polynomial;
            }
        }
        crc &= 0xffff;
        return crc;
    }

    private static class Frame implements Serializable {
        int seq;
        int ack;
        int length;
        byte[] info = new byte[1024];
        int crc;
        long time;

        @Override
        public String toString() {
            return "Frame{" +
                    "seq=" + seq +
                    ", ack=" + ack +
                    ", length=" + length +
                    ", crc=" + crc +
                    ", time=" + time +
                    '}';
        }
    }

    private byte[] convertToBytes(Object object) throws IOException {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutput out = new ObjectOutputStream(bos)) {
            out.writeObject(object);
            out.flush();
            return bos.toByteArray();
        }
    }

    private Object convertFromBytes(byte[] bytes) throws IOException, ClassNotFoundException {
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
             ObjectInput in = new ObjectInputStream(bis)) {
            return in.readObject();
        }
    }
}
