import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;

public class UdpCs {
    static byte[] data_buf = new byte[1024];
    static DatagramPacket packet = new DatagramPacket(data_buf, data_buf.length);

    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            System.err.println("Are you kidding me?");
        }

        if (args[0].toLowerCase().equals("server")) {
            server(args[1], Integer.parseInt(args[2]));
        } else {
            if (args.length < 5) {
                System.err.println("You should provide server ip, server port, your ip, your port and message");
            }
            client(args[1], Integer.parseInt(args[2]), args[3], Integer.parseInt(args[4]), args[5]);
        }
    }

    private static void client(String server_ip_str, int server_port, String ip_str, int port, String message) throws IOException {
        DatagramSocket udp_sock = new DatagramSocket(new InetSocketAddress(ip_str, port));
        packet.setSocketAddress(new InetSocketAddress(server_ip_str, server_port));
        packet.setData(message.getBytes(StandardCharsets.US_ASCII));
        udp_sock.send(packet);

        udp_sock.setSoTimeout(5000);
        while (true) {
            try {
                udp_sock.receive(packet);
            } catch (SocketTimeoutException e) {
                continue;
            }
            String new_message = new String(packet.getData(), StandardCharsets.US_ASCII);
            System.out.println("I received: " + new_message);
            break;
        }
        udp_sock.close();
    }

    private static void server(String ip_str, int port) throws IOException {
        DatagramSocket udp_sock = new DatagramSocket(new InetSocketAddress(ip_str, port));

        udp_sock.setSoTimeout(5000);
        int timeout_times = 0;
        while (true) {
            try {
                udp_sock.receive(packet);
            } catch (SocketTimeoutException e) {
                timeout_times++;
                if (timeout_times == 10) break;
                continue;
            }
            String message = new String(packet.getData(), StandardCharsets.US_ASCII);
//            System.out.println("I received: " + message);
            packet.setData(message.toUpperCase().getBytes());
            udp_sock.send(packet);
        }
        udp_sock.close();
    }
}
