import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class TcpCs {
    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            System.err.println("Are you kidding me?");
        }

        if (args[0].toLowerCase().equals("server")) {
            tcp_server(Integer.parseInt(args[1]));
        } else {
            if (args.length < 3) {
                System.err.println("You should provide server ip, server port and message");
            }
            tcp_client(args[1], Integer.parseInt(args[2]), args[3] + "\n");
        }
    }

    private static void tcp_client(String server_ip_str, int server_port, String message) throws IOException {
        Socket socket = new Socket(InetAddress.getByName(server_ip_str), server_port);
        OutputStream os = socket.getOutputStream();
        os.write(message.getBytes());
        os.flush();

        InputStream is = socket.getInputStream();
        Scanner scanner = new Scanner(is);
        System.out.println(scanner.nextLine());
    }

    private static void tcp_server(int port) throws IOException {
        ServerSocket serverSocket = new ServerSocket(port);
        Socket socket = serverSocket.accept();
        InputStream is = socket.getInputStream();
        Scanner scanner = new Scanner(is);

        String message = scanner.nextLine();
        System.out.println(message);
        OutputStream os = socket.getOutputStream();
        os.write(message.toUpperCase().getBytes());
        os.flush();
    }
}
