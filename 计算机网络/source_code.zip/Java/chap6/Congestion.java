import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.stream.IntStream;

public class Congestion {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("send/recv?");
        if (scanner.nextLine().equals("send")) {
            send();
        } else {
            recv();
        }
    }

    private static void send() throws IOException {
        int MSS = 1024;
        int Threshold = 32768;
        int TriACKRound = 16;
        int TimeoutRound = 22;
        int EndRound = 26;

        System.out.println("MSS: " + MSS + " Threshold: " + Threshold);
        int round = 1;
        int windowSize = 1;
        boolean exceeded = false;
        Socket socket = new Socket("localhost", 9999);
        OutputStream os = socket.getOutputStream();
        StringBuilder sb = new StringBuilder();
        while (round < EndRound) {
            System.out.println("Round: " + round + " Window Size: " + windowSize);
            IntStream.rangeClosed(1, windowSize).forEach(i -> sb.append('a'));
            String sendStr = sb/*.append('\n')*/.toString();
            System.out.println("Send: " + sendStr);
            os.write(sendStr.getBytes());
            os.write("\n".getBytes());
            os.flush();

            if (0 == round % TriACKRound) {
                System.out.println("TriACKRound");
                Threshold = windowSize / 2;
                windowSize = Threshold;
            } else if (0 == round % TimeoutRound) {
                System.out.println("TimeoutRound");
                Threshold = windowSize / 2;
                windowSize = 1;
                exceeded = true;
            } else {
                if (exceeded) {
                    windowSize += MSS;
                } else {
                    windowSize *= 2;
                }
            }
            if (windowSize > Threshold && !exceeded) {
                windowSize = Threshold;
                exceeded = true;
            }
            round++;
        }
        os.close();
        socket.close();
    }

    private static void recv() throws IOException {
        ServerSocket serverSockets = new ServerSocket(9999);
        Socket socket = serverSockets.accept();
        InputStream is = socket.getInputStream();
        Scanner scanner = new Scanner(is);
        while (true) {
            try {
                System.out.println(scanner.nextLine());
            } catch (NoSuchElementException e) {
                break;
            }
        }
        is.close();
        socket.close();
        serverSockets.close();
    }
}
