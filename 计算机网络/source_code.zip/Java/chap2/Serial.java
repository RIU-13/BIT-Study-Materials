import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Scanner;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;
import jdk.internal.dynalink.beans.StaticClass;

public class Serial {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		 Enumeration<CommPortIdentifier> portList = CommPortIdentifier.getPortIdentifiers();
//	        while (portList.hasMoreElements()) {
//	        	CommPortIdentifier portIdentifier =portList.nextElement();
//	            String portName = portIdentifier.getName();
//	            System.out.println("串口名:"+portName);
//	        } 
	        String name1 = "COM1";
			String name2 = "COM2";
			Integer BaudRate=9600;//波特率
			Integer	DataBits=8;//数据位
			Integer Parity=0;//校验位
			Integer StopBits=1;//停止位
	        SerialPort port1=null;
	        SerialPort port2=null;
	        Scanner scan = new Scanner(System.in);
	        if (args.length>0){
	        if (args[0].equals("READ"))
	        {
	        	System.out.println("串口名称："+name2);
	        	System.out.println("串口属性");
	        	System.out.println("波特率："+BaudRate);
	        	System.out.println("数据位："+DataBits);
	        	System.out.println("校验位："+Parity);
	        	System.out.println("停止位："+StopBits);
	        	try {
					port2=openPort(name2, BaudRate,DataBits, StopBits, Parity);
					while (true) {
						InputStream in=port2.getInputStream();
						if (in.available()>0) {
							byte[] bytes =readFromPort(port2);
							String getString =new String(bytes);
							System.out.println(getString);}
					}
				} catch (PortInUseException e) {
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					if(port2!=null)
					closePort(port2);
				}
	        
	        }else if (args[0].equals("WRITE"))
	        {
	        	try {
		        	System.out.println("串口名称："+name1);
		        	System.out.println("串口属性");
		        	System.out.println("波特率："+BaudRate);
		        	System.out.println("数据位："+DataBits);
		        	System.out.println("校验位："+Parity);
		        	System.out.println("停止位："+StopBits);
					port1=openPort(name1, BaudRate,DataBits, StopBits, Parity);
					System.out.println("成功打开串口"+name1);
					while (true) {
					System.out.println("输入要发送的内容");
					String message = scan.nextLine();
					sendToPort(port1, message.getBytes());
					}

				} catch (PortInUseException e) {
					e.printStackTrace();
				}finally {
					if(port1!=null)
					closePort(port1);
				}
		}
	        }
	        }
			
	 public static final SerialPort openPort(String portName,Integer BaudRate,Integer DataBits,Integer StopBits,Integer Parity) throws PortInUseException {
	        try {
	            // 通过端口名识别端口
	            CommPortIdentifier portIdentifier = CommPortIdentifier.getPortIdentifier(portName);
	            CommPort commPort = portIdentifier.open(portName, 2000);
	            // 判断是不是串口
	            if (commPort instanceof SerialPort) {
	                SerialPort serialPort = (SerialPort) commPort;
	                try {
	                    serialPort.setSerialPortParams(BaudRate, DataBits, StopBits,
	                    		Parity);
	                } catch (UnsupportedCommOperationException e) {
	                    e.printStackTrace();
	                }
	                return serialPort;
	            }
	        } catch (NoSuchPortException e1) {
	            e1.printStackTrace();
	        }
	        return null;
	    }
	 public static void closePort(SerialPort serialPort) {
	        if (serialPort != null) {
	            serialPort.close();
	        }
	    }
	    public static void sendToPort(SerialPort serialPort, byte[] order) {
	        OutputStream out = null;
	        try {
	            out = serialPort.getOutputStream();
	            out.write(order);
	            out.flush();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (out != null) {
	                    out.close();
	                    out = null;
	                }
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    public static byte[] readFromPort(SerialPort serialPort) {
	        InputStream in = null;
	        byte[] bytes = null;
	        try {
	            in = serialPort.getInputStream();
	            int bytesNum = in.available();
	            if (bytesNum > 0) {
	            	bytes = new byte[bytesNum];
	            	in.read(bytes);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (in != null) {
	                    in.close();
	                    in = null;
	                }
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	        return bytes;
	    }
}
