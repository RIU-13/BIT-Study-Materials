# import matplotlib.pyplot as plt
# import pylab
import pandas as pd
import copy

StartCycle = list()
RealStartCycle = list()
InitialConflictVector = str()


def Create_Initial_Conflict_Vector(a: int, b: int, Table: list) -> str:
    dis = set()
    for i in range(a):
        tmp = []
        for j in range(b):
            if (Table[i][j] == 1):
                tmp.append(j)
        for m in range(0, len(tmp)):
            for n in range(m + 1, len(tmp)):
                dis.add(abs(tmp[m] - tmp[n]))
    result = str()
    for i in range(1, b):
        if i in dis:
            result = '1' + result
        else:
            result = '0' + result
    return result


def String_Right_Move(s: str, k: int) -> str:
    while (k != 0):
        s = '0' + s
        s = s[:-1]
        k = k - 1
    return s


def String_And(s1: str, s2: str):
    s = str()
    for i in range(len(s1)):
        if s1[i] == '0' and s2[i] == '0':
            s = s + '0'
        else:
            s = s + '1'
    return s


def Find_Real_Circle(ConVector: str, CVTable: set, CVVector: list, NowStartCycle: list, lenth: int) -> None:
    if ConVector in CVTable:
        StartCycle.append(copy.deepcopy(NowStartCycle))
        numhead = 0
        while (ConVector != CVVector[numhead]):
            numhead = numhead + 1
        RealStartCycle.append(copy.deepcopy(NowStartCycle[numhead:len(NowStartCycle)]))
        CVTable.remove(ConVector)
        CVVector.pop()
        return
    else:
        CVTable.add(copy.deepcopy(ConVector))
        CVVector.append(copy.deepcopy(ConVector))
        for i in range((lenth - 1), -1, -1):
            if (ConVector[i] == '0'):
                TmpVector = String_Right_Move(ConVector, lenth - i)
                TmpResult = String_And(TmpVector, ConVector)
                NowStartCycle.append(lenth - i)
                Find_Real_Circle(TmpResult, copy.deepcopy(CVTable), copy.deepcopy(CVVector), NowStartCycle, lenth)
                NowStartCycle.pop()
        NowStartCycle.append(lenth + 1)
        RealStartCycle.append(copy.deepcopy(NowStartCycle))
        StartCycle.append(copy.deepcopy(NowStartCycle))
        NowStartCycle.pop()
        return


def Create_Cycle_Using_List(Cycle1: list, Cycle2: list, kth: int) -> list:
    CycleUsingList = list()
    CycleUsingList.append(Cycle1[kth][0])
    for i in range(1, len(Cycle1[kth])):
        CycleUsingList.append(CycleUsingList[i - 1] + Cycle1[kth][i])
    for i in range(len(Cycle2[kth])):
        CycleUsingList.append(CycleUsingList[len(Cycle1[kth]) + i - 1] + Cycle2[kth][i])
    for i in range(len(Cycle2[kth])):
        CycleUsingList.append(CycleUsingList[len(Cycle1[kth]) + len(Cycle2[kth]) + i - 1] + Cycle2[kth][i])
    for i in range(len(Cycle2[kth])):
        CycleUsingList.append(CycleUsingList[len(Cycle1[kth]) + len(Cycle2[kth]) * 2 + i - 1] + Cycle2[kth][i])
    return CycleUsingList


def Create_Matrix(InitialMatrix: list, CycleList: list, a: int) -> list:
    Resultlist = [[0 for col in range(CycleList[len(CycleList) - 1] + len(InitialMatrix[0]))] for row in range(a)]
    TmpList = [0] * len(CycleList)
    for i in range(a):
        for j in range(len(InitialMatrix[0])):
            if InitialMatrix[i][j] == 1:
                Resultlist[i][j] = 1
                for k in range(1, len(CycleList)):
                    Resultlist[i][j + CycleList[k]] = 1 + k
    return Resultlist


# 预约表
ResTable_DataFrame = pd.read_csv(r'file.csv', header=None)
ResTable_list = ResTable_DataFrame.values.tolist()
ResTable = tuple(ResTable_list)
a = len(ResTable)
b = len(ResTable[0])
InitialConflictVector = Create_Initial_Conflict_Vector(a, b, ResTable)
s1 = "初始冲突向量为： %s" % (InitialConflictVector)
print(s1)
RealCVTable = set()
RealCVVector = list()
RealNowStartCycle = list()
Find_Real_Circle(InitialConflictVector, RealCVTable, RealCVVector, RealNowStartCycle, b - 1)
for i in range(len(StartCycle)):
    if b in StartCycle[i]:
        continue
    s2 = "进入循环的序列为： %s" % (StartCycle[i])
    print(s2)

for i in range(3):
    n = int(input("请选择查看第几个循环："))
    CycleUsingList = Create_Cycle_Using_List(StartCycle, RealStartCycle, n)
    CycleUsingMatrix = Create_Matrix(ResTable_list, CycleUsingList, a)
    print(CycleUsingList)
    print(CycleUsingMatrix)

