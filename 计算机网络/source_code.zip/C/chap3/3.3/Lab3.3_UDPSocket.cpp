﻿// 运行于VS2017，需要将项目->属性->常规中的字符集设置为“使用多字节字符集”
#define _WINSOCK_DEPRECATED_NO_WARNINGS 1
#define _CRT_SECURE_NO_WARNINGS
#define MAX_PKT 4//数据部分包含的字节数
#define MAX_SEQ 1//帧序号最大值
#define FILTERLOST 10//每10帧丢一帧
#define FILTERERROR 10//每10帧出错一帧
#define CRC_CCITT 0x11021//生成多项式
#include <stdio.h>
#include <Winsock2.h>
#include <string.h>
#include <windows.h>
#pragma comment(lib,"ws2_32.lib")
typedef unsigned int seq_nr;
typedef struct {
	unsigned long long data;
	DWORD len;
} packet;
typedef enum {
	data, ack, nak
} frame_kind;

typedef struct {
	frame_kind kind;
	seq_nr seq;
	seq_nr ack;
	packet info;
} frame;

int errorcounter = 6;//传输错误计数器，满10则模拟发生传输错误
int lostcounter = 1;//丢帧计数器，满10则模拟丢帧

unsigned long long crc_CCITT_Send(unsigned char * ptr, DWORD len)
{
	unsigned long long data_crc = 0, data = 0, ax = 0, bx = 0, cx = 0, crc = 0;
	for (int i = 0; i < len; i++) {
		data_crc <<= 8;
		data_crc += (*ptr);
		ptr++;
	}

	data = data_crc;
	data <<= 16;
	ax = data >> 31;
	data <<= 33;


	for (cx = 31; cx > 0; cx--)
	{
		if (((ax >> 16) & 0x1) == 0x1)
		{
			ax = ax ^ CRC_CCITT;
		}
		ax <<= 1;
		bx = data >> 63;
		ax = ax + bx;
		data <<= 1;
	}

	if (((ax >> 16) & 0x1) == 0x1)  //最后一位的异或操作
	{
		ax = ax ^ CRC_CCITT;
	}

	crc = ax;
	data_crc <<= 16;
	data_crc += crc;
	return data_crc;

}

unsigned char * toBuffer(unsigned long long data_crc, DWORD len) {
	unsigned char buffer[MAX_PKT] = { 0 };
	data_crc >>= 16;
	for (int i = len - 1; i >= 0; i--) {
		buffer[i] = (unsigned char)(data_crc % 10000000);
		data_crc >>= 8;
	}
	return buffer;
}

unsigned long long correction_check(unsigned long long data_crc)    //计算 加密信息%多项式==0则正确 
{
	unsigned long long data = 0, ax = 0, bx = 0, cx = 0;
	unsigned long long px = 0x11021;
	data = data_crc;

	ax = data >> 31;
	data <<= 33;
	for (cx = 31; cx > 0; cx--)
	{
		if (((ax >> 16) & 0x1) == 0x1)
		{
			ax = ax ^ px;
		}
		ax <<= 1;
		bx = data >> 63;
		ax = ax + bx;
		data <<= 1;
	}

	if (((ax >> 16) & 0x1) == 0x1)
	{
		ax = ax ^ px;
	}

	return ax;
}


void from_network_layer(packet *p, HANDLE hfile) {//从文件中读出字符串，存入packet，并求出校验和
	
	unsigned char buffer[MAX_PKT] = {0};
	DWORD dwReadSize = 0;
	ReadFile(hfile, buffer, MAX_PKT, &dwReadSize, NULL);
	p->len = dwReadSize;
	p->data = crc_CCITT_Send(buffer, dwReadSize);
	
}

int to_network_layer(packet *p, HANDLE hfile) {//检查校验和是否正确，若正确则写入文件
	FlushFileBuffers(hfile);

	if (correction_check(p->data)==0) {
		DWORD dwWriteSize = 0;
		unsigned char buffer[MAX_PKT] = { 0 };
		unsigned long long data_crc = p->data;
		data_crc >>= 16;
		for (int i = p->len - 1; i >= 0; i--) {
			buffer[i] = (unsigned char)(data_crc % 128);
			data_crc >>= 8;
		}
		if (WriteFile(hfile, buffer, p->len, &dwWriteSize, NULL) < 0) {
			printf("write failed!\n");
		}
		return 1;
	}
	else {
		return 0;
	}
}



void inc(seq_nr *k) {//递增
	if (*k < MAX_SEQ) {
		*k = *k + 1;
	}
	else
	{
		*k = 0;
	}
}

void server(char *filename) {//receiver3()
	HANDLE hfile = CreateFile(filename, GENERIC_READ | GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);//创建文件
	if (hfile == INVALID_HANDLE_VALUE) {
		printf("open file failed!\n");
		return;
	}

	SOCKET socketSrv = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);//创建服务端Socket
	SOCKADDR_IN addrServer;
	addrServer.sin_port = htons(8888);
	addrServer.sin_family = AF_INET;
	addrServer.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	bind(socketSrv, (SOCKADDR*)&addrServer, sizeof(addrServer));//绑定端口、ip地址

	DWORD dwTime = 5000;
	setsockopt(socketSrv, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwTime, sizeof(dwTime));//设置接收超时

	SOCKADDR_IN addClient;
	int lenClient = sizeof(addClient);

	seq_nr frame_expected;
	frame r, s;
	frame_expected = 0;

	int succ;

	while (TRUE) {
		succ = recvfrom(socketSrv, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addClient, &lenClient);//从客户端接收帧
		if (succ >= 0) {
			if (r.seq == frame_expected) {
				if (to_network_layer(&(r.info), hfile) == 1) {
					inc(&frame_expected);
					printf("-----------received------------\n");
					printf("frame_expected = %d\n", frame_expected);
					printf("seq = %d\ndata = %llx\n", r.seq, r.info.data);
					printf("-------------------------------\n\n");
					if (r.info.len < MAX_PKT) {
						printf("complete\n");
						break;
					}
				}
				else
				{
					printf("-----------received------------\n");
					printf("校验和出错！\n");
					printf("-------------------------------\n\n");
				}
			}
		}
		else
		{
			printf("************接收超时*************\n\n");
		}

		seq_nr sendack = 1 - frame_expected;
		memcpy(&(s.ack), &sendack, sizeof(sendack));
		sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//发送确认帧
		printf("----------send confirm---------\n");
		printf("ack = %d\n",s.ack);
		printf("-------------------------------\n\n");

		Sleep(2000);
	}

	closesocket(socketSrv);

	CloseHandle(hfile);

	return;
}

void client(char *filename) {//sender3()
	HANDLE hfile = CreateFile(filename, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);//打开要发送的文件
	if (hfile == INVALID_HANDLE_VALUE) {
		printf("open file failed!\n");
		return;
	}

	SOCKET socketClient = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);//创建客户端Socket

	SOCKADDR_IN addrServer;
	int lenServer = sizeof(addrServer);
	addrServer.sin_family = AF_INET;
	addrServer.sin_port = htons(8888);
	addrServer.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");//绑定服务端的端口、ip地址

	DWORD dwTime = 10000;
	setsockopt(socketClient, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwTime, sizeof(dwTime));//设置接收超时


	seq_nr next_frame_to_send;
	frame s;
	packet buffer, errorbuffer;
	next_frame_to_send = 0;
	from_network_layer(&buffer, hfile);

	int succ;
	

	while (TRUE) {
		

		if (lostcounter % FILTERLOST == 0) {
			memcpy(&(s.info), &buffer, sizeof(buffer));
			memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
			printf("************模拟丢帧************\n");
		}
		else
		{
			if (errorcounter%FILTERERROR == 0) {
				errorbuffer.len = buffer.len;
				memcpy(&(s.info), &errorbuffer, sizeof(errorbuffer));
				memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
				sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
				printf("************模拟出错************\n");
			}
			else
			{
				memcpy(&(s.info), &buffer, sizeof(buffer));
				memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
				sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
				printf("--------------正确发送-------------\n");
			}
		}
		printf("next_frame_to_send = %d\n", next_frame_to_send);
		printf("seq = %d\ndata = %llx\n", s.seq, s.info.data);
		printf("-------------------------------\n\n");
		if (s.info.len < MAX_PKT) {
			printf("finished\n");
			break;
		}

		lostcounter++;
		errorcounter++;

		succ = recvfrom(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, &lenServer);
		if (succ >= 0) {
			if (s.ack == next_frame_to_send) {
				from_network_layer(&buffer, hfile);
				inc(&next_frame_to_send);
				printf("----------接收到确认帧-----------\n");
				printf("ack = %d\n", s.ack);
				printf("-------------------------------\n\n");
			}
		}
		else
		{
			printf("***********接收超时***********\n\n");
		}

		Sleep(2000);
	}

	closesocket(socketClient);

	CloseHandle(hfile);

	return;
}

int main(int argc, char *argv[])
{
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	printf("receive/send?\n");
	char s[10];
	scanf("%s", s);
	if (strcmp(s, "receive") == 0) {
		printf("receive file path:\n");
		char path[100];
		scanf("%s", path);
		printf("start?[y/n]\n");
		char c[5];
		scanf("%s", c);
		if (strcmp(c,"y") == 0) {
			printf("receiver started.\n");
			server(path);
		}
	}
	else if (strcmp(s, "send") == 0) {
		printf("send file path:\n");
		char path[100];
		scanf("%s", path);
		printf("start?[y/n]\n");
		char c[5];
		scanf("%s", c);
		if (strcmp(c,"y")==0) {
			printf("sender started.\n");
			client(path);
		}
	}
	WSACleanup();
	return 0;
}
