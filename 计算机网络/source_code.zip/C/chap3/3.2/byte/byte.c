//��00��Ϊesc 7E��Ϊflag

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
	int i, j, tmp, len;
	char info[100];
	srand((unsigned)time(NULL));

	printf("flag is 7E, esc is 00\n");
	for(i=1;i<=16;i++)
	{
		tmp=rand()%16;
		if(tmp>=0&&tmp<=9)
		{
			info[i-1]=48+tmp;
		}
		if(tmp>=10&&tmp<=15)
		{
			info[i-1]=55+tmp;
		}
	}
	info[3]='0';				//��ȫ�����Ļ�������00��7E����̫��
	info[4]='0';
	info[5]='0';
	info[1]='7';
	info[2]='E';
	info[16]='\0';
	printf("the sending info is: ");
	printf("%s\n",info);

	len=16;
	for(i=0;i<len;i+=2)
	{
		if(info[i]=='0'&&info[i+1]=='0')
		{
			for(j=len+1;j>=i+2;j--)
			{
				info[j]=info[j-2];
			}
			len+=2;
			info[i]='0';
			info[i+1]='0';
			i+=3;
		}
		if(info[i]=='7'&&info[i+1]=='E')
		{
			for(j=len+1;j>=i+2;j--)
			{
				info[j]=info[j-2];
			}
			len+=2;
			info[i]='0';
			info[i+1]='0';
			i+=3;
		}
	}
	for(i=len+2;i>=2;i--)
	{
		info[i]=info[i-2];
	}
	info[0]='7';
	info[1]='E';
	len+=2;
	info[len]='7';
	info[len+1]='E';
	info[len+2]='\0';
	len+=2;
	printf("the info after byte stuffing is:");
	printf("%s\n",info);

	for(i=0;i<len;i+=2)
	{
		if(info[i]=='0'&&info[i+1]=='0')
		{
			for(j=i;j<=len-2;j++)
			{
				info[j]=info[j+2];
			}
			len-=2;
			i+=1;
		}
	}
	for(i=0;i<len-2;i++)
	{
		info[i]=info[i+2];
	}
	len-=4;
	info[len]='\0';
	printf("the info after byte deleting is: ");
	printf("%s\n",info);

	return 0;
}
