//
//  main.cpp
//  crc
//
//  Created by ziyantao on 2020/3/28.
//  Copyright © 2020 ziyantao. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[])
{
    int init[50], i, j, len;
    int temp[70];
    float tmp;
    init[0]=0, init[1]=1, init[2]=1, init[3]=0;
    for(i=10;i<=20;i++)
    {
        init[i]=1;
    }
    init[29]=1, init[30]=1, init[31]=0;
    printf("帧起始与结束标志为：01111110\n");
    
    srand((unsigned)time(NULL));
    for(i=4;i<=9;i++)
    {
        tmp=rand()/32767.0;
        if(tmp>0.5)
            init[i]=1;
        else
            init[i]=0;
    }
    for(i=21;i<=28;i++)
    {
        tmp=rand()/32767.0;
        if(tmp>0.5)
            init[i]=1;
        else
            init[i]=0;
    }
    printf("待发送数据为：");
    for(i=0;i<=31;i++)
    {
        printf("%d",init[i]);
         if(i!=0&&(i%4==0))
            printf(" ");
    }
    printf("\n");
    
    len=32;
    for(i=3;i<len;i++)
    {
        if(init[i]==1&&init[i+1]==1&&init[i+2]==1&&init[i+3]==1&&init[i+4]==1)
        {
            for(j=len;j>i+5;j--)
            {
                init[j]=init[j-1];
            }
            init[i+5]=0;
            len++;
            i=i+4;
        }
   
    }
    temp[0]=0,temp[1]=1,temp[2]=1,temp[3]=1,temp[4]=1,temp[5]=1,temp[6]=1,temp[7]=0;
      for(i=8;i<8+len;i++){
          temp[i]=init[i-8];
      }
    int a=8+len;
      temp[a]=0,temp[a+1]=1,temp[a+2]=1,temp[a+3]=1,temp[a+4]=1,temp[a+5]=1,temp[a+6]=1,temp[a+7]=0;
    printf("比特填充后信息为：");
    for(i=0;i<a+8;i++)
    {
        printf("%d",temp[i]);
        if(i!=0&&(i%4==0))
            printf(" ");
    }
    printf("\n");
    
    for(i=3;i<len;i++)
    {
        if(init[i]==1&&init[i+1]==1&&init[i+2]==1&&init[i+3]==1&&init[i+4]==1&&init[i+5]==0)
        {
            for(j=i+5;j<len;j++)
            {
                init[j]=init[j+1];
            }
            len--;
            i=i+4;
        }
    }
    printf("比特删除后接收帧为： ");
    for(i=0;i<len;i++)
    {
        printf("%d",init[i]);
        if(i!=0&&(i%4==0))
            printf(" ");
    }
    printf("\n");
    
    return 0;
}
