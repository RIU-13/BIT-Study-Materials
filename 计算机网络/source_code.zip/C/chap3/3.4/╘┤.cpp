// ������VS2017����Ҫ����Ŀ->����->�����е��ַ�������Ϊ��ʹ�ö��ֽ��ַ�����
#define _WINSOCK_DEPRECATED_NO_WARNINGS 1
#define _CRT_SECURE_NO_WARNINGS
#define MAX_PKT 4//���ݲ��ְ������ֽ���
#define MAX_SEQ 1//֡������ֵ
#define FILTERLOST 10//ÿ10֡��һ֡
#define FILTERERROR 10//ÿ10֡����һ֡
#define CRC_CCITT 0x11021//���ɶ���ʽ
#include <stdio.h>
#include <Winsock2.h>
#include <string.h>
#include <windows.h>
//#include<time.h>
#pragma comment(lib,"ws2_32.lib")
#define ACK_TIMER 300     //ACK��ʱ��
#define MAX_SEQ 7         //�������� 
//#define DATA_TIMER 2800   //�ط���ʱ��
typedef unsigned int seq_nr;
typedef struct {
	unsigned long long data;
	DWORD len;
} packet;
typedef enum {
	data=1, ack, nak
} frame_kind;
int time[100];
typedef struct {
	frame_kind kind;
	seq_nr seq;
	seq_nr ack;
	packet info;
} frame;					
static int no_nak = 1;
seq_nr ack_expected = 0;          //���ʹ����½�
seq_nr next_frame_to_send = 0;    //���ʹ����Ͻ� + 1
seq_nr frame_expected = 0;        //���մ���
frame out_buf[MAX_SEQ + 1]; 
frame temp_buf[MAX_SEQ + 1];//���ͻ���ͽ��ջ���
int errorcounter = 1;//����������������10��ģ�ⷢ���������
int lostcounter = 6;//��֡����������10��ģ�ⶪ֡



unsigned long long crc_CCITT_Send(unsigned char * ptr, DWORD len)
{
	unsigned long long data_crc = 0, data = 0, ax = 0, bx = 0, cx = 0, crc = 0;
	for (int i = 0; i < len; i++) {
		data_crc <<= 8;
		data_crc += (*ptr);
		ptr++;
	}

	data = data_crc;
	data <<= 16;
	ax = data >> 31;
	data <<= 33;


	for (cx = 31; cx > 0; cx--)
	{
		if (((ax >> 16) & 0x1) == 0x1)
		{
			ax = ax ^ CRC_CCITT;
		}
		ax <<= 1;
		bx = data >> 63;
		ax = ax + bx;
		data <<= 1;
	}

	if (((ax >> 16) & 0x1) == 0x1)  //���һλ��������
	{
		ax = ax ^ CRC_CCITT;
	}

	crc = ax;
	data_crc <<= 16;
	data_crc += crc;
	return data_crc;

}

unsigned char * toBuffer(unsigned long long data_crc, DWORD len) {
	unsigned char buffer[MAX_PKT] = { 0 };
	data_crc >>= 16;
	for (int i = len - 1; i >= 0; i--) {
		buffer[i] = (unsigned char)(data_crc % 10000000);
		data_crc >>= 8;
	}
	return buffer;
}

unsigned long long correction_check(unsigned long long data_crc)    //���� ������Ϣ%����ʽ==0����ȷ 
{
	unsigned long long data = 0, ax = 0, bx = 0, cx = 0;
	unsigned long long px = 0x11021;
	data = data_crc;

	ax = data >> 31;
	data <<= 33;
	for (cx = 31; cx > 0; cx--)
	{
		if (((ax >> 16) & 0x1) == 0x1)
		{
			ax = ax ^ px;
		}
		ax <<= 1;
		bx = data >> 63;
		ax = ax + bx;
		data <<= 1;
	}

	if (((ax >> 16) & 0x1) == 0x1)
	{
		ax = ax ^ px;
	}

	return ax;
}


void from_network_layer(packet *p, HANDLE hfile) {//���ļ��ж����ַ���������packet�������У���

	unsigned char buffer[MAX_PKT] = { 0 };
	DWORD dwReadSize = 0;
	ReadFile(hfile, buffer, MAX_PKT, &dwReadSize, NULL);
	p->len = dwReadSize;
	p->data = crc_CCITT_Send(buffer, dwReadSize);

}

int to_network_layer(packet *p, HANDLE hfile) {//���У����Ƿ���ȷ������ȷ��д���ļ�
	FlushFileBuffers(hfile);

	if (correction_check(p->data) == 0) {
		DWORD dwWriteSize = 0;
		unsigned char buffer[MAX_PKT] = { 0 };
		unsigned long long data_crc = p->data;
		data_crc >>= 16;
		for (int i = p->len - 1; i >= 0; i--) {
			buffer[i] = (unsigned char)(data_crc % 128);
			data_crc >>= 8;
		}
		if (WriteFile(hfile, buffer, p->len, &dwWriteSize, NULL) < 0) {
			printf("write failed!\n");
		}
		return 1;
	}
	else {
		return 0;
	}
}



void inc(seq_nr *k) {//����
	if (*k < MAX_SEQ) {
		*k = *k + 1;
	}
	else
	{
		*k = 0;
	}
}

void client(char *filename,char*filename1,int flag) {//path rev,path1,send,1rev,2send
	HANDLE hfile = CreateFile(filename, GENERIC_READ | GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);//create�ļ�
	if (hfile == INVALID_HANDLE_VALUE) {
		printf("create receive file failed!\n");
		return;
	}
	printf("create receive file success!\n");

	HANDLE hfile1 = CreateFile(filename1, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);//��Ҫ���͵��ļ�
	if (hfile1 == INVALID_HANDLE_VALUE) {
		printf("open send file failed!\n");
		return;
	}
	int nbuffered = 0;
	printf("open send file success!\n");

	if (flag == 1) {
		SOCKET socketSrv = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);//���������Socket
		SOCKADDR_IN addrServer;
		addrServer.sin_port = htons(8888);
		addrServer.sin_family = AF_INET;
		addrServer.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
		bind(socketSrv, (SOCKADDR*)&addrServer, sizeof(addrServer));//�󶨶˿ڡ�ip��ַ

		DWORD dwTime = 2000;
		setsockopt(socketSrv, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwTime, sizeof(dwTime));//���ý��ճ�ʱ

		SOCKADDR_IN addClient;
		int lenClient = sizeof(addClient);
		//seq_nr frame_expected;
		frame r, s;
		//frame_expected = 0;

		int succ;
		int ack_0=0;
		int sendack;
		int cend = 0;
		int svend = 0;
		packet buffer, errorbuffer;
		//next_frame_to_send = 0;
		from_network_layer(&buffer, hfile1);
		while (TRUE) {

			succ = recvfrom(socketSrv, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addClient, &lenClient);//�ӿͻ��˽���֡
			int sum = 0;
			if (succ >= 0) {
				if (r.seq == frame_expected) {
					if (ack_0 == 0) {//first rev frame
						if (to_network_layer(&(r.info), hfile) == 1) {
							ack_0 = 1;
							frame_expected++;
							printf("-----------received------------\n");
							printf("frame_expected = %d\n", frame_expected);
							printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
							printf("-------------------------------\n\n");
							//send ack;

							sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
							//host2 sev frame
							memcpy(&(s.info), &buffer, sizeof(buffer));
							memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));

							//printf("--------------��ȷ����-------------\n");
							//time[ack_expected]++;//cal time
							out_buf[nbuffered] = s;//storage
							nbuffered++;
							next_frame_to_send++;
							from_network_layer(&buffer, hfile1);

							sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//����ȷ��֡

						}
						else {
							sum = 1;
							printf("-----------received------------\n");
							printf("У��ͳ�����\n");
							printf("-------------------------------\n\n");
						}
						
					}
					else {
						// last rev

						if (to_network_layer(&(r.info), hfile) == 1) {
							//rev right
							frame_expected++;
							sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
						
							printf("-----------received------------\n");
							printf("frame_expected = %d\n", frame_expected);
							printf("seq = %d\nack = %d\nack_expected=%d\n", r.seq, r.ack, ack_expected);
							printf("-------------------------------\n\n");

							if (r.info.len < MAX_PKT) {
								printf("complete\n");
								//sendack = 1011;
								cend = 1;
							}
							//client send over

							if (cend == 1) {
								while ((ack_expected <= r.ack) && (r.ack < next_frame_to_send))
								{
									ack_expected++;
									memcpy(&(s.info), &buffer, sizeof(buffer));
									memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));

									//printf("--------------��ȷ����-------------\n");
									//time[ack_expected]++;//cal time

									out_buf[nbuffered] = s;//storage
									nbuffered++;
									next_frame_to_send++;

									from_network_layer(&buffer, hfile1);

									sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//����ȷ��֡
									printf("send seq=%d\n", s.seq);
									while (succ = recvfrom(socketSrv, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addClient, &lenClient)) {
										printf("ack=%d\n", r.ack);
									}
									if (s.info.len < MAX_PKT) {
										printf("Finish.\n");
										return;
									}
									
									
								}
							
							}
							//check receive over or not
							if ((ack_expected <= r.ack) && (r.ack < next_frame_to_send)) {//send right
								//printf("ack_expected=%d,r.ack=%d\n1111111111\n", ack_expected, r.ack);
								ack_expected++;
								if (errorcounter%FILTERERROR == 0) {
									errorbuffer.len = buffer.len;
									memcpy(&(s.info), &errorbuffer, sizeof(errorbuffer));
									memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
									sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//����ȷ��֡
									printf("************ģ�����************\n");
									memcpy(&(s.info), &buffer, sizeof(buffer));
									memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
									out_buf[nbuffered] = s;//storage
									nbuffered++;
									//time[ack_expected]++;//cal time
									next_frame_to_send++;
									from_network_layer(&buffer, hfile1);
								}
								else {
									memcpy(&(s.info), &buffer, sizeof(buffer));
									memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));

									//printf("--------------��ȷ����-------------\n");
									//time[ack_expected]++;//cal time

									out_buf[nbuffered] = s;//storage
									nbuffered++;
									next_frame_to_send++;
									from_network_layer(&buffer, hfile1);

									sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//����ȷ��֡

								}
					

							}
							else {
								//send last frame
								s = out_buf[ack_expected];
								memcpy(&(s.ack), &sendack, sizeof(sendack));
								sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);
								//printf("adhuihwqiodnipsnmpfmapsajpidj\n\n\n");
							}
						
						}
						else
						{	
							sum = 1;
							printf("-----------received------------\n");
							printf("У��ͳ�����\n");
							printf("-------------------------------\n\n");

						}
					}
					lostcounter++;
					errorcounter++;

					if (s.info.len < MAX_PKT) {
						svend = 1;
						printf("send frame over!just receive.\n");
						while (TRUE) {
							sum = 0;
							succ = recvfrom(socketSrv, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addClient, &lenClient);//�ӿͻ��˽���֡
							if (succ >= 0) {
								if (r.seq == frame_expected) {
									if (to_network_layer(&(r.info), hfile) == 1) {
										frame_expected++;
										printf("-----------received------------\n");
										printf("frame_expected = %d\n", frame_expected);
										printf("seq = %d\nack = %d\nack_expected=%d\n", r.seq, r.ack, ack_expected);
										printf("-------------------------------\n\n");


										int sendack = frame_expected - 1;


										memcpy(&(s.ack), &sendack, sizeof(sendack));
										sendto(socketSrv, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addClient, lenClient);//����ȷ��֡
										printf("----------send confirm---------\n");
										printf("ack = %d\n", s.ack);
										printf("-------------------------------\n\n");
										if (r.info.len < MAX_PKT) {
											printf("receive complete\n");
											sendack = 1011;
											return;
										}
									}
									else
									{
										sum = 1;
										printf("-----------received------------\n");
										printf("У��ͳ�����\n");
										printf("-------------------------------\n\n");

									}
								}

							}
							else
							{
								Sleep(200);
								printf("************���ճ�ʱ*************\n\n");
							}


							//Sleep(2000);
						}
						return;

					}

					if (sum == 0) {
						printf("----------send confirm and frame---------\n");
						printf("next_frame_to_send = %d,ack_expected= %d,frame_expected=%d\n", next_frame_to_send, ack_expected, frame_expected);
						printf("seq = %d\ndata = %llx\nack = %d\n", s.seq, s.info.data, s.ack);
						//printf("time[ack_expected]=%d", time[ack_expected]);
						printf("-------------------------------\n\n");

					}
		
					
	
				}

			}
			else
			{
				Sleep(100);
				printf("************���ճ�ʱ*************\n\n");
			}


			//Sleep(2000);
		}

		closesocket(socketSrv);

		CloseHandle(hfile);

		return;
	}

	memset(time, 0, sizeof(time));
	SOCKET socketClient = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);//�����ͻ���Socket

	SOCKADDR_IN addrServer;
	int lenServer = sizeof(addrServer);
	addrServer.sin_family = AF_INET;
	addrServer.sin_port = htons(8888);
	addrServer.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");//�󶨷���˵Ķ˿ڡ�ip��ַ

	DWORD dwTime = 5000;
	setsockopt(socketClient, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwTime, sizeof(dwTime));//���ý��ճ�ʱ

	frame s,r;
	packet buffer, errorbuffer;
	//next_frame_to_send = 0;
	from_network_layer(&buffer, hfile1);

	int succ;
	int load = 0;

	while (TRUE) {


		if (lostcounter % FILTERLOST == 0) {
			memcpy(&(s.info), &buffer, sizeof(buffer));
			memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
			printf("************ģ�ⶪ֡************\n");
			out_buf[nbuffered] = s;//storage
			out_buf[nbuffered].ack = frame_expected;
			nbuffered ++;
			time[ack_expected]++;//cal time
			next_frame_to_send++;
			from_network_layer(&buffer, hfile1);
		}
		else
		{
			if (errorcounter%FILTERERROR == 0) {
				errorbuffer.len = buffer.len;
				memcpy(&(s.info), &errorbuffer, sizeof(errorbuffer));
				memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
				sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
				printf("************ģ�����************\n");
				int sendack = frame_expected - 1;
				memcpy(&(s.ack), &sendack, sizeof(sendack));
				memcpy(&(s.info), &buffer, sizeof(buffer));
				memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
				out_buf[nbuffered] = s;//storage
				out_buf[nbuffered].ack = frame_expected;
				nbuffered ++;
				time[ack_expected]++;//cal time
				next_frame_to_send++;
				from_network_layer(&buffer, hfile1);
			}
			else
			{
				memcpy(&(s.info), &buffer, sizeof(buffer));
				memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
				int sendack = frame_expected - 1;
				memcpy(&(s.ack), &sendack, sizeof(sendack));
				sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
				printf("--------------��ȷ����-------------\n");
				time[ack_expected]++;//cal time
				out_buf[nbuffered] = s;//storage
				out_buf[nbuffered].ack = frame_expected;
				nbuffered ++;
				next_frame_to_send++;
				from_network_layer(&buffer, hfile1);
			}
		}
		printf("next_frame_to_send = %d,ack_expected= %d,frame_expected=%d\n", next_frame_to_send,ack_expected,frame_expected);
		printf("seq = %d\ndata = %llx\nack = %d\n", s.seq, s.info.data,s.ack);
		printf("time[ack_expected]=%d", time[ack_expected]);
		printf("-------------------------------\n\n");
		lostcounter++;
		errorcounter++;
		DWORD count = s.info.len;
		int recflag = 0;
		succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);
		if ((succ>=0)&&r.info.len < MAX_PKT) {
			//no receive frame
			int x = 0;
			while ((ack_expected <= r.ack) && (r.ack <= next_frame_to_send)) {
				//from_network_layer(&buffer, hfile);
				ack_expected++;
				load++;
				time[ack_expected] = next_frame_to_send - ack_expected;
				printf("----------���յ�ȷ��֡-----------\n");
				printf("ack = %d\n ", r.ack);
				printf("-------------------------------\n\n");
				if (r.seq == frame_expected) {
					if (to_network_layer(&(r.info), hfile) == 1) {
						//ack_0 = 1;
						frame_expected++;
						printf("-----------received over------------\n");
						printf("frame_expected = %d\n", frame_expected);
						printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
						printf("-------------------------------\n\n");
						//send ack;

						int sendack = frame_expected - 1;
						memcpy(&(s.ack), &sendack, sizeof(sendack));
					}
					else {
						x = 1;
						printf("-----------received------------\n");
						printf("У��ͳ�����\n");
						printf("-------------------------------\n\n");
						int sendack = frame_expected - 1;
						memcpy(&(s.ack), &sendack, sizeof(sendack));
					}
				}
				
				if (x == 0) {
					while(1) {
							memcpy(&(s.info), &buffer, sizeof(buffer));
							memcpy(&(s.seq), &next_frame_to_send, sizeof(next_frame_to_send));
							int sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
							sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
							printf("--------------��ȷ����-------------\n");
							printf("next_frame_to_send = %d,ack_expected= %d,frame_expected=%d\n", next_frame_to_send, ack_expected, frame_expected);
							printf("seq = %d\ndata = %llx\nack = %d\n", s.seq, s.info.data, s.ack);
							printf("time[ack_expected]=%d", time[ack_expected]);
							printf("-------------------------------\n\n");
							time[ack_expected]++;//cal time
							out_buf[nbuffered] = s;//storage
							nbuffered++;
							next_frame_to_send++;
							if (s.info.len < MAX_PKT) {
								printf("send over\n");
								return;
							}
							from_network_layer(&buffer, hfile1);
						
							succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);
							if (succ >= 0) {
								if ((ack_expected <= r.ack) && (r.ack <= next_frame_to_send)) {
									ack_expected++;
									printf("----------���յ�ȷ��֡-----------\n");
									printf("ack = %d\n seq= %d\n", r.ack, r.seq);
									printf("-------------------------------\n\n");
								}
								
							}
							
						
					}
					
					
				}
				
			}
				

			
			
		}
		else if (count < MAX_PKT) {
			//no send just receive
			if (succ >= 0) {
				
					//from_network_layer(&buffer, hfile);
					ack_expected++;
					load++;
					time[ack_expected] = next_frame_to_send - ack_expected;
					printf("----------���յ�ȷ��֡-----------\n");
					printf("ack = %d\n seq= %d\n", r.ack, r.seq);
					printf("-------------------------------\n\n");
					while (r.seq == frame_expected) {
						if (to_network_layer(&(r.info), hfile) == 1) {
							//ack_0 = 1;
							frame_expected++;
							printf("-----------received------------\n");
							printf("frame_expected = %d\n", frame_expected);
							printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
							printf("-------------------------------\n\n");
							//send ack;

							int sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
							sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
							succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);
							if (r.info.len < MAX_PKT) {
								printf("sever send over!\n");
								return;
							}

						}
						else {
							//sum = 1;
							printf("-----------received------------\n");
							printf("У��ͳ�����\n");
							printf("-------------------------------\n\n");
							int sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
							sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
							succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);

						}

					}
					
				
			}
			else {
				printf("***********���ճ�ʱ***********\n\n");
				int tem = load;
				int sum = nbuffered;
				while (tem < nbuffered) {
					out_buf[tem].ack = frame_expected-1;
					sendto(socketClient, (char*)&out_buf[tem], sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
					printf("--------------���·���-------------\n");
					printf("seq=%d,ack=%d\n", out_buf[tem].seq, out_buf[tem].ack);
					succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);
					if (succ >= 0) {
						while ((ack_expected <= r.ack) && (r.ack <= next_frame_to_send)) {
							//from_network_layer(&buffer, hfile);
							ack_expected++;
							load++;
							time[ack_expected] = next_frame_to_send - ack_expected;
							printf("----------���յ�ȷ��֡-----------\n");
							printf("ack = %d\n seq= %d\n", r.ack, r.seq);
							printf("-------------------------------\n\n");
							if (r.seq == frame_expected) {
								if (to_network_layer(&(r.info), hfile) == 1) {
									//ack_0 = 1;
									frame_expected++;
									printf("-----------received------------\n");
									printf("frame_expected = %d\n", frame_expected);
									printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
									printf("-------------------------------\n\n");
									//send ack;

									//int sendack = frame_expected - 1;
									//memcpy(&(out_buf[tem + 1].ack), &sendack, sizeof(sendack));
								}
								else {
									//sum = 1;
									printf("-----------received------------\n");
									printf("У��ͳ�����\n");
									printf("-------------------------------\n\n");
									//int sendack = frame_expected - 1;
									//memcpy(&(out_buf[tem + 1].ack), &sendack, sizeof(sendack));
								}
							}
							
							
						}
						tem++;

					}

				}
				load = 0;
				nbuffered = 0;


			}
			while (1) {
				//succ = recvfrom(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, &lenServer);
				if (r.info.len < MAX_PKT) {
					printf("receive over");
					return;
				}
				else  {
					//printf("-------------------------------\n\n");
					if (r.seq == frame_expected) {
						if (to_network_layer(&(r.info), hfile) == 1) {
							//ack_0 = 1;
							frame_expected++;
							printf("-----------received------------\n");
							printf("frame_expected = %d\n", frame_expected);
							printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
							printf("-------------------------------\n\n");
							//send ack;

							int sendack = frame_expected - 1;
							memcpy(&(s.ack), &sendack, sizeof(sendack));
						}
						else {
							//sum = 1;
							printf("-----------received------------\n");
							printf("У��ͳ�����\n");
							printf("-------------------------------\n\n");
							//int sendack = frame_expected - 1;
							//memcpy(&(s.ack), &sendack, sizeof(sendack));
						}
						int sendack = frame_expected - 1;
						memcpy(&(s.ack), &sendack, sizeof(sendack));
						sendto(socketClient, (char*)&s, sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
						printf("ack=%d\n", s.ack);
						succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);

					}
					
				}

			}
			
			break;
		}
		else if (succ >= 0) {
			while((ack_expected <= r.ack) && (r.ack <= next_frame_to_send)) {
				//from_network_layer(&buffer, hfile);
				ack_expected++;
				load++;
				time[ack_expected] = next_frame_to_send - ack_expected;
				printf("----------���յ�ȷ��֡-----------\n");
				printf("ack = %d\n seq= %d\n", r.ack,r.seq);
				printf("-------------------------------\n\n");
				if (r.seq == frame_expected) {
					if (to_network_layer(&(r.info), hfile) == 1) {
						//ack_0 = 1;
						frame_expected++;
						printf("-----------received------------\n");
						printf("frame_expected = %d\n", frame_expected);
						printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
						printf("-------------------------------\n\n");
						//send ack;

						int sendack = frame_expected - 1;
						memcpy(&(s.ack), &sendack, sizeof(sendack));
						}
					else {
						//sum = 1;
						printf("-----------received------------\n");
						printf("У��ͳ�����\n");
						printf("-------------------------------\n\n");
						int sendack = frame_expected - 1;
						memcpy(&(s.ack), &sendack, sizeof(sendack));
						//int sendack = frame_expected - 1;
						//memcpy(&(s.ack), &sendack, sizeof(sendack));
						//printf("sendack=%d,s.ack=%d,frame_expected=%d\n11111111\n", sendack, s.ack, frame_expected);

					}
				}
				
			}
		}
		else
		{
			
			if (time[ack_expected] > 5) //overstack
			{
				printf("***********���ճ�ʱ***********\n\n");
				int tem = load;
				int sum = nbuffered;
				while (tem<nbuffered) {
					out_buf[tem].ack = frame_expected-1;
					sendto(socketClient, (char*)&out_buf[tem], sizeof(s), 0, (SOCKADDR*)&addrServer, lenServer);
					printf("--------------���·���-------------\n");
					printf("seq=%d\n,ack=%d\n", out_buf[tem].seq, out_buf[tem].ack);
					succ = recvfrom(socketClient, (char*)&r, sizeof(r), 0, (SOCKADDR*)&addrServer, &lenServer);
					if (succ >= 0) {
						while ((ack_expected <= r.ack) && (r.ack <= next_frame_to_send)) {
							//from_network_layer(&buffer, hfile);
							ack_expected++;
							load++;
							time[ack_expected] = next_frame_to_send - ack_expected;
							printf("----------���յ�ȷ��֡-----------\n");
							printf("ack = %d\n seq= %d\n", r.ack, r.seq);
							printf("-------------------------------\n\n");
							if (r.seq == frame_expected) {
								if (to_network_layer(&(r.info), hfile) == 1) {
									//ack_0 = 1;
									frame_expected++;
									printf("-----------received------------\n");
									printf("frame_expected = %d\n", frame_expected);
									printf("seq = %d\ndata = %d\n", r.seq, r.info.data);
									printf("-------------------------------\n\n");
									//send ack;
								
									//int sendack = frame_expected - 1;
									//memcpy(&(out_buf[tem+1].ack), &sendack, sizeof(sendack));

								}
								else {
									//sum = 1;
									printf("-----------received------------\n");
									printf("У��ͳ�����\n");
									printf("-------------------------------\n\n");
									//int sendack = frame_expected - 1;
									//memcpy(&(out_buf[tem+1].ack), &sendack, sizeof(sendack));
								}
								if (r.info.len < MAX_PKT) {
									printf("receive send over\n");
								}
							}
							
							
						}
						tem++;

					}
				
				}
				
				load = 0;
				nbuffered = 0;

			}
		}

		//Sleep(2000);
	}

	closesocket(socketClient);

	CloseHandle(hfile);

	return;
}

int main(int argc, char *argv[])
{
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	printf("receive/send?\n");
	char s[10];
	scanf("%s", s);
	if (strcmp(s, "receive") == 0) {
		printf("receive file path:\n");
		char path[100];
		scanf("%s", path);
		printf("send file path:\n");
		char path1[100];
		scanf("%s", path1);
		printf("start?[y/n]\n");
		char c[5];
		scanf("%s", c);
		if (strcmp(c, "y") == 0) {
			printf("receiver started.\n");
			client(path,path1,1);//rev
		}
	}
	else if (strcmp(s, "send") == 0) {
		printf("send file path:\n");
		char path1[100];
		scanf("%s", path1);
		printf("receive file path:\n");
		char path[100];
		scanf("%s", path);
		printf("start?[y/n]\n");
		char c[5];
		scanf("%s", c);
		if (strcmp(c, "y") == 0) {
			printf("sender started.\n");
			client(path,path1,2);//send
		}
	}
	WSACleanup();
	system("pause");
	return 0;
}
