#include<iostream>
#include<vector>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<sstream>
#include<time.h> 

using namespace std;


void *string2char(string theString,char re[])
{
    strcpy(re,theString.c_str());
}

int execmd(char* cmd,char* result) 
{
    char buffer[128];                     
    FILE* pipe = _popen(cmd, "r");
    if (!pipe)
        return 0;
        
    while(!feof(pipe))
	{
    	if(fgets(buffer, 128, pipe))
		{
            strcat(result,buffer);
    	}
    }
    _pclose(pipe);
    return 1;
}

int main(int argc, char *argv[]) 
{
	int i,tmp;
	printf("the password is: ");
    cout<<argv[1]<<endl;
	
	//string randomNumber;
	char randomNumber[33];
	srand((unsigned)time(NULL));
	for(i=1;i<=32;i++)
	{
		tmp=rand()%16;
		if(tmp>=0&&tmp<=9)
		{
			randomNumber[i-1]=48+tmp;
		}
		if(tmp>=10&&tmp<=15)
		{
			randomNumber[i-1]=55+tmp;
		}
	}
	randomNumber[32]='\0';
	printf("the random number is: ");
	cout<<randomNumber<<endl;
    
    string passWord = argv[1];
    string theString = randomNumber+passWord;
    printf("the orgin string: ");
    cout<<theString<<endl;
    
    FILE *f=fopen("origin.txt","w");
    char res[100];
	string2char(theString,res);
    fprintf(f,"%s",res);
    fclose(f);
    
    execmd("certutil -hashfile origin.txt MD5",res);
    
    printf("the MD5 value is: \n");
	cout<<res;
	
	return 0;
} 


