//
//  main.c
//  udp-checksum
//
//  Created by ziyantao on 2020/5/21.
//  Copyright © 2020 ziyantao. All rights reserved.
//

#include<stdio.h>
unsigned short checksum(unsigned short *buf,int nword)
{
unsigned long sum;
for(sum=0;nword>0;nword--)
{
sum += *buf++;
sum = (sum>>16) + (sum&0xffff);
}
return ~sum;
}
void main()
{
    unsigned short buffer[20]={0xc0a8,0x0168,0xca6a,0xc344,0x0011,0x001c,0xd123,0x2742,0x001c,0x0000,0x14A7,0xF482,0xF6C2,0x1662,0x3DEA,0x6A96,0x5010,0x7540,0x355F,0x0000};
    int n=20;//data length
    unsigned short re_checksum;
    printf("psuedo head:\n");
    printf("source IP:");
    printf("192.168.1.104\n");
    printf("des IP:");
    printf("202.106.195.68\n");
    printf("mbz:0\n");
    printf("protocol:17\n");
    printf("UDP length:28\n");
    printf("UDP head:\n");
    printf("source port:53539\n");
    printf("des port:10050\n");
    printf("UDP length:28\n");
    printf("checksum(set 0):0x0000\n");
    re_checksum=checksum(buffer,n);
    printf("after cal checksum:0x%x\n",re_checksum);

}

