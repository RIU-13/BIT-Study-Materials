#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define HAVE_REMOTE  
#define WIN32

#include <pcap.h>  
#pragma comment(lib, "wpcap.lib")  
#include <stdio.h>  

#pragma comment(lib, "Ws2_32.lib")  


#define ETHER_ADDR_LEN 6  
//from linux's ethernet.h  
#define ETHERTYPE_PUP           0x0200          /* Xerox PUP */  
#define ETHERTYPE_SPRITE        0x0500          /* Sprite */  
#define ETHERTYPE_IP            0x0800          /* IP */  
#define ETHERTYPE_ARP           0x0806          /* Address resolution */  
#define ETHERTYPE_REVARP        0x8035          /* Reverse ARP */  
#define ETHERTYPE_AT            0x809B          /* AppleTalk protocol */  
#define ETHERTYPE_AARP          0x80F3          /* AppleTalk ARP */  
#define ETHERTYPE_VLAN          0x8100          /* IEEE 802.1Q VLAN tagging */  
#define ETHERTYPE_IPX           0x8137          /* IPX */  
#define ETHERTYPE_IPV6          0x86dd          /* IP protocol version 6 */  
#define ETHERTYPE_LOOPBACK      0x9000          /* used to test interfaces */  



struct   ether_header {
    u_char   ether_dhost[ETHER_ADDR_LEN];
    u_char   ether_shost[ETHER_ADDR_LEN];
    u_short   ether_type;  //�����һ��ΪIPЭ�顣��ether_type��ֵ����0x0800  
};


struct ip_header  //ipͷ 
{
    unsigned   char     ihl : 4;              //ip   header   length      
    unsigned   char     version : 4;          //version     
    u_char              tos;                //type   of   service     
    u_short             tot_len;            //total   length     
    u_short             id;                 //identification     
    u_short             frag_off;           //fragment   offset     
    u_char              ttl;                //time   to   live     
    u_char              protocol;           //protocol   type     
    u_short             check;              //check   sum     
    u_int               saddr;              //source   address     
    u_int               daddr;              //destination   address     
};


struct tcphdr //tcpͷ
{
    unsigned short sport;//16λԴ�˿�
    unsigned short dport;//16λĿ�Ķ˿�
    unsigned int seq;//32λ���к�
    unsigned int ack;//32λȷ�Ϻ�
    unsigned char lenres;//4λ�ײ�����/6λ������
    unsigned char flag;//6λ��־λ
    unsigned short win;//16λ���ڴ�С
    unsigned short sum;//16λ�����
    unsigned short urp;//16λ��������ƫ����
};


struct Psd_Header {
    ULONG sourceip; //ԴIP��ַ  
    ULONG destip; //Ŀ��IP��ַ  
    BYTE mbz; //�ÿ�(0)  
    BYTE ptcl; //Э������  
    USHORT plen; //TCP/UDP���ݰ��ĳ���(����TCP/UDP��ͷ�������ݰ������ĳ��� ��λ:�ֽ�)  
};


struct udphdr
{
    u_int16_t source;         /* source port */
    u_int16_t dest;           /* destination port */
    u_int16_t len;            /* udp length */
    u_int16_t checkl;         /* udp checksum */
};

u_int16_t in_cksum(u_int16_t* addr, int len)
{
    int     nleft = len;
    u_int32_t sum = 0;
    u_int16_t* w = addr;
    u_int16_t answer = 0;

    while (nleft > 1) {
        sum += *w++;
        nleft -= 2;
    }
    /* mop up an odd byte, if necessary */
    if (nleft == 1) {
        *(unsigned char*)(&answer) = *(unsigned char*)w;
        sum += answer;
    }

    /* add back carry outs from top 16 bits to low 16 bits */
    sum = (sum >> 16) + (sum & 0xffff); /* add hi 16 to low 16 */
    sum += (sum >> 16);     /* add carry */
    answer = ~sum;     /* truncate to 16 bits */
    return (answer);
}


char TcpFlag[8][5] = { "FIN", "SYN", "RST", "PSH", "ACK", "URG", "ECE", "CWR" };//����TCP��־λ


void recvReq() {
    pcap_t* fp;
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_if_t* alldevs;
    pcap_if_t* d;
    int inum;
    int j = 0;

    /* ����豸�б� */
    if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
    {
        fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
        exit(1);
    }

    /* ��ӡ�б� */
    for (d = alldevs; d; d = d->next)
    {
        printf("%d. %s", ++j, d->name);
        if (d->description)
            printf(" (%s)\n", d->description);
        else
            printf(" (No description available)\n");
    }

    if (j == 0)
    {
        printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
        return;
    }

    printf("Enter the interface number (1-%d):", j);
    scanf("%d", &inum);

    if (inum < 1 || inum > j)
    {
        printf("\nInterface number out of range.\n");
        /* �ͷ��豸�б� */
        pcap_freealldevs(alldevs);
        return;
    }

    /* ��ת����ѡ�豸 */
    for (d = alldevs, j = 0; j < inum - 1; d = d->next, j++);

    char* str = (char*)malloc(50);
    for (auto begin = d->addresses; begin != nullptr; begin = begin->next)
    {
        if (begin->next == nullptr)
        {
            str = inet_ntoa(((struct sockaddr_in*)(begin->addr))->sin_addr);
            break;
        }
    }

    printf("ip: %s\n", str);

    /* ������豸 */
    if ((fp = pcap_open(d->name,            // �豸��
        100,                // Ҫ����Ĳ��� (ֻ����ǰ100���ֽ�)
        PCAP_OPENFLAG_PROMISCUOUS,  // ����ģʽ
        1000,               // ����ʱʱ��
        NULL,               // Զ�̻�����֤
        errbuf              // ���󻺳�
    )) == NULL)
    {
        fprintf(stderr, "\nUnable to open the adapter. %s is not supported by WinPcap\n", d->name);
        return;
    }

    pcap_freealldevs(alldevs);

    pcap_pkthdr* header;
    const u_char* pkt_data;
    while (1) {
        if (pcap_next_ex(fp, &header, &pkt_data) > 0) {
            
            ip_header* ip = (ip_header*)(pkt_data + 14);
            //printf("proto : %u\n", ip->protocol);

            if (ip->protocol == IPPROTO_TCP) {
                tcphdr* tcp_protocol = (tcphdr*)(pkt_data + 14 + 20);
                u_short tcp_destport = ntohs(tcp_protocol->dport);
                if (tcp_destport != 7777) {
                    continue;
                }
                printf("----------- receive -----------\n");
                SOCKADDR_IN sip;
                sip.sin_addr.S_un.S_addr = ip->saddr;
                printf("souce ip: \n");
                printf("%s\n", inet_ntoa(sip.sin_addr));
                printf("source port��");
                printf("%d\n", ntohs(tcp_protocol->sport));
                unsigned char FlagMask = 1;
                int k;

                //��ӡ��־λ
                for (k = 0; k < 6; k++)
                {
                    if ((tcp_protocol->flag) & FlagMask)
                        printf("%s = 1\n", TcpFlag[k]);
                    FlagMask = FlagMask << 1;
                }
                if (tcp_protocol->flag != (1 << 1)) {
                    continue;
                }
                else
                {
                    printf("connection request\n");
                }

                u_char buffer[60] = { 0 };

                ether_header* pether_header = (ether_header*)buffer;
                ip_header* pip_header = (ip_header*)(buffer + sizeof(ether_header));
                tcphdr* ptcp_header = (tcphdr*)(buffer + sizeof(ether_header) + sizeof(ip_header));
                udphdr* pudp_header = (udphdr*)(buffer + sizeof(ether_header) + sizeof(ip_header));

                //printf("forming ether head\n");

                /*pether_header->ether_dhost[0] = 0xD * 16 + 0x0;
                pether_header->ether_dhost[1] = 0x5 * 16 + 0x0;
                pether_header->ether_dhost[2] = 0x9 * 16 + 0x9;
                pether_header->ether_dhost[3] = 0x5 * 16 + 0x6;
                pether_header->ether_dhost[4] = 0x5 * 16 + 0x1;
                pether_header->ether_dhost[5] = 0x8 * 16 + 0xB;

                pether_header->ether_shost[0] = 0xB * 16 + 0x4;
                pether_header->ether_shost[1] = 0x2 * 16 + 0xE;
                pether_header->ether_shost[2] = 0x9 * 16 + 0x9;
                pether_header->ether_shost[3] = 0x9 * 16 + 0xF;
                pether_header->ether_shost[4] = 0xC * 16 + 0x9;
                pether_header->ether_shost[5] = 0xA * 16 + 0x1;*/


                pether_header->ether_type = htons(ETHERTYPE_IP);

                //����IP����ͷ
                //printf("forming ip head\n");
                if ((sizeof(ip_header) % 4) != 0)
                {
                    printf("[IP Header error]/n");
                    return;
                }

                pip_header->ihl = sizeof(ip_header) / 4;
                pip_header->version = 4;
                pip_header->tos = 0;
                pip_header->tot_len = htons(sizeof(buffer) - sizeof(ether_header));
                pip_header->id = htons(0x1000);
                pip_header->frag_off = htons(0);
                pip_header->ttl = 0x80;
                pip_header->protocol = IPPROTO_TCP;
                pip_header->saddr = ip->daddr;
                pip_header->daddr = ip->saddr;

                //����TCP����ͷ;
                //printf("forming tcp head\n");
                ptcp_header->dport = tcp_protocol->sport;
                ptcp_header->sport = tcp_protocol->dport;
                ptcp_header->flag = (1 << 4)+(1 << 1);
                ptcp_header->ack = 1;
                ptcp_header->lenres = 5 << 4;
                ptcp_header->win = 65535;

                //����TCPα�ײ�
                char buffer2[64] = { 0 };
                Psd_Header* psd = (Psd_Header*)buffer2;
                psd->sourceip = ip->daddr;
                psd->destip = ip->saddr;
                psd->ptcl = IPPROTO_TCP;
                psd->plen = htons(sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header));
                psd->mbz = 0;

                memcpy(buffer2 + sizeof(Psd_Header), (void*)pudp_header, sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header));
                ptcp_header->sum = in_cksum((u_int16_t*)buffer2,
                    sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header) + sizeof(Psd_Header));

                /* �������ݰ� */
                if (pcap_sendpacket(fp, buffer, sizeof(buffer) /* size */) != 0)
                {
                    fprintf(stderr, "\nError sending the packet: \n", pcap_geterr(fp));
                    return;
                }
            }
        }
    }
    
}

void main()
{
    printf("receive?[y/n]\n");
    int c = getchar();
    if (c == 'y') {
        recvReq();
        return;
    }
    pcap_t* fp;
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_if_t* alldevs;
    pcap_if_t* d;
    int inum;
    int j = 0;

    


    /* ����豸�б� */
    if (pcap_findalldevs(&alldevs, errbuf) == -1)
    {
        fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
        exit(1);
    }

    /* ��ӡ�б� */
    for (d = alldevs; d; d = d->next)
    {
        printf("%d. %s", ++j, d->name);
        if (d->description)
            printf(" (%s)\n", d->description);
        else
            printf(" (No description available)\n");
    }

    if (j == 0)
    {
        printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
        return;
    }

    printf("Enter the interface number (1-%d):", j);
    scanf("%d", &inum);

    if (inum < 1 || inum > j)
    {
        printf("\nInterface number out of range.\n");
        /* �ͷ��豸�б� */
        pcap_freealldevs(alldevs);
        return;
    }

    /* ��ת����ѡ�豸 */
    for (d = alldevs, j = 0; j < inum - 1; d = d->next, j++);

    char* str = (char*)malloc(50);
    for (auto begin = d->addresses; begin != nullptr; begin = begin->next)
    {
        if (begin->next == nullptr)
        {
            str = inet_ntoa(((struct sockaddr_in*)(begin->addr))->sin_addr);
            break;
        }
    }

    printf("net_ip : %s\n", str);

    /* ������豸 */
    if ((fp = pcap_open(d->name,            // �豸��
        100,                // Ҫ����Ĳ��� (ֻ����ǰ100���ֽ�)
        PCAP_OPENFLAG_PROMISCUOUS,  // ����ģʽ
        1000,               // ����ʱʱ��
        NULL,               // Զ�̻�����֤
        errbuf              // ���󻺳�
    )) == NULL)
    {
        fprintf(stderr, "\nUnable to open the adapter. %s is not supported by WinPcap\n", d->name);
        return;
    }

    pcap_freealldevs(alldevs);

    char desIp[50];
    printf("enter des ip:\n");
    scanf("%s", desIp);

    unsigned int desPort;
    printf("enter des port:\n");
    scanf("%u", &desPort);

    u_char buffer[60] = { 0 };

    ether_header* pether_header = (ether_header*)buffer;
    ip_header* pip_header = (ip_header*)(buffer + sizeof(ether_header));
    tcphdr* ptcp_header = (tcphdr*)(buffer + sizeof(ether_header) + sizeof(ip_header));
    udphdr* pudp_header = (udphdr*)(buffer + sizeof(ether_header) + sizeof(ip_header));

    //printf("forming ether head\n");

    /*pether_header->ether_dhost[0] = 0x0 * 16 + 0x0;
    pether_header->ether_dhost[1] = 0xB * 16 + 0xF;
    pether_header->ether_dhost[2] = 0x9 * 16 + 0xE;
    pether_header->ether_dhost[3] = 0x6 * 16 + 0x3;
    pether_header->ether_dhost[4] = 0xA * 16 + 0x1;
    pether_header->ether_dhost[5] = 0xB * 16 + 0x0;

    pether_header->ether_shost[0] = 0xB * 16 + 0x4;
    pether_header->ether_shost[1] = 0x2 * 16 + 0xE;	
    pether_header->ether_shost[2] = 0x9 * 16 + 0x9;	
    pether_header->ether_shost[3] = 0x9 * 16 + 0xF;
    pether_header->ether_shost[4] = 0xC * 16 + 0x9;	
    pether_header->ether_shost[5] = 0xA * 16 + 0x1;*/


    pether_header->ether_type = htons(ETHERTYPE_IP);

    //����IP����ͷ
    //printf("forming ip head\n");
    if ((sizeof(ip_header) % 4) != 0)
    {
        printf("[IP Header error]/n");
        return;
    }

    pip_header->ihl = sizeof(ip_header) / 4;
    pip_header->version = 4;
    pip_header->tos = 0;
    pip_header->tot_len = htons(sizeof(buffer) - sizeof(ether_header));
    pip_header->id = htons(0x1000);
    pip_header->frag_off = htons(0);
    pip_header->ttl = 0x80;
    pip_header->protocol = IPPROTO_TCP;
    pip_header->saddr = inet_addr(str);
    pip_header->daddr = inet_addr(desIp);

    //����TCP����ͷ;
    //printf("forming tcp head\n");
    ptcp_header->dport = htons(desPort);
    ptcp_header->sport = htons(8888);
    ptcp_header->flag = (1 << 1);
    ptcp_header->lenres = 5<<4;
    ptcp_header->win = 65535;

    //����TCPα�ײ�
    char buffer2[64] = { 0 };
    Psd_Header* psd = (Psd_Header*)buffer2;
    psd->sourceip = inet_addr(str);
    psd->destip = inet_addr(desIp);
    psd->ptcl = IPPROTO_TCP;
    psd->plen = htons(sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header));
    psd->mbz = 0;

    memcpy(buffer2 + sizeof(Psd_Header), (void*)pudp_header, sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header));
    ptcp_header->sum = in_cksum((u_int16_t*)buffer2,
        sizeof(buffer) - sizeof(ether_header) - sizeof(ip_header) + sizeof(Psd_Header));

    /* �������ݰ� */
    if (pcap_sendpacket(fp, buffer, sizeof(buffer) /* size */) != 0)
    {
        fprintf(stderr, "\nError sending the packet: \n", pcap_geterr(fp));
        return;
    }

    pcap_pkthdr *header;
    const u_char *pkt_data;
    while(1){
        if (pcap_next_ex(fp, &header, &pkt_data) > 0) {
            ip_header* ip = (ip_header*)(pkt_data + 14);
            //printf("proto : %u\n", ip->protocol);

            if (ip->protocol == IPPROTO_TCP) {
                tcphdr* tcp_protocol = (tcphdr*)(pkt_data + 14 + 20);
                u_short tcp_destport = ntohs(tcp_protocol->dport);
                if (tcp_destport == 8888) {
                    printf("----------- receive -----------\n");
                    SOCKADDR_IN sip;
                    sip.sin_addr.S_un.S_addr = ip->saddr;
                    printf("souce ip: \n");
                    printf("%s\n", inet_ntoa(sip.sin_addr));
                    printf("source port��");
                    printf("%d\n", ntohs(tcp_protocol->sport));
                    unsigned char FlagMask = 1;
                    int k;

                    //��ӡ��־λ
                    for (k = 0; k < 6; k++)
                    {
                        if ((tcp_protocol->flag) & FlagMask)
                            printf("%s = 1\n", TcpFlag[k]);
                        FlagMask = FlagMask << 1;
                    }

                    printf("connection established\n");
                }
            }
        }
    }
    
    return;
}