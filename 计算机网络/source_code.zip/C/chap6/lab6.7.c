#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#define max_time 20

float RTT_table[max_time]=
{
	26,32,24,26,28,
	29,25,34,32,30,
	26,28,33,31,35,
	30,27,28,29,32
};
float alpha=0.125;
float beta=0.25;

int main(int argc, char *argv[]) 
{
	int i=0,flag=0;
	float RTT=30,DevRTT=15,formerRTT,RTO;
	printf("the initial RTT=%f\n\n",RTT);
	for(i=0;i<max_time;i++)
	{
		formerRTT=RTT;
		printf("RTT of this time: %f\n",RTT_table[i]);
		RTT=(1-alpha)*RTT+alpha*RTT_table[i];
		
		DevRTT=(1-beta)*DevRTT+beta*fabs(RTT-RTT_table[i]);
		RTO=RTT+4*DevRTT;
		
		if(fabs(RTT-formerRTT)<=0.2)
		{
			if(flag==0)
			{
				printf("RTT has been smooth, which has the value of %f\n",RTT);
				flag=1;
			}
		}
		
		printf("current RTO is %f\n",RTO);
	}
	return 0;
}
