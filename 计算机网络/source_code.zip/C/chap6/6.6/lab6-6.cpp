#define _WINSOCK_DEPRECATED_NO_WARNINGS 1
#define _CRT_SECURE_NO_WARNINGS 1

#define MSS 1024
#define TRI_ACK 16
#define TIME_OUT 22
#define END 26

#include <stdio.h>
#include <WinSock2.h>
#include <string.h>
#include <Windows.h>

#pragma comment(lib, "ws2_32.lib")

void server() {

	SOCKET socketListen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN addrListen;
	addrListen.sin_family = AF_INET;
	addrListen.sin_port = htons(8888);
	addrListen.sin_addr.S_un.S_addr = INADDR_ANY;

	bind(socketListen, (SOCKADDR*)&addrListen, sizeof(addrListen));

	listen(socketListen, 3);
	printf("waiting for connection...\n");

	SOCKET socketRecv;
	SOCKADDR_IN addrClient;
	int lenClient = sizeof(addrClient);

	socketRecv = accept(socketListen, (SOCKADDR*)&addrClient, &lenClient);
	if (socketRecv == INVALID_SOCKET) {
		printf("connection falied.\n");
		return;
	}
	else
	{
		printf("connection succeeded.\n");
	}


	char recvBuffer[1024];
	while (1) {
		int res = recv(socketRecv, recvBuffer, sizeof(recvBuffer), 0);
		if (res > 0) {
			printf("-----------recv------------\n");
			printf("%s\n", recvBuffer);
		}
	}

	closesocket(socketRecv);
	closesocket(socketListen);
	return;
}

void client() {
	int round = 1;
	int cwnd = 1;
	int threshold = 32768;
	BOOLEAN slowstart = true;

	SOCKET socketClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN addrServer;
	addrServer.sin_family = AF_INET;
	addrServer.sin_port = htons(8888);
	addrServer.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");

	if (connect(socketClient, (SOCKADDR*)&addrServer, sizeof(addrServer)) == SOCKET_ERROR) {
		printf("connection falied.\n");
		return;
	}

	char sendBuffer[1024] = "this is a message with a length of 1024 bytes.";

	while (round <= END) {
		printf("round: %d\n", round);

		if (round == TRI_ACK) {
			printf("*********TRI_ACK occurred**********\n");
			threshold = cwnd * 1024 / 2;
			cwnd = threshold / 1024;
			printf("cwnd: %d\n", cwnd);
			for (int i = 0; i < cwnd; i++) {
				send(socketClient, sendBuffer, sizeof(sendBuffer), 0);
				printf("--------send---------\n");
				printf("%s\n", sendBuffer);
			}
			cwnd++;
		}
		else if (round == TIME_OUT) {
			printf("***********TIME_OUT occurred************\n");
			threshold = cwnd * 1024 / 2;
			cwnd = 1;
			slowstart = true;
			printf("cwnd: %d\n", cwnd);
			for (int i = 0; i < cwnd; i++) {
				send(socketClient, sendBuffer, sizeof(sendBuffer), 0);
				printf("--------send---------\n");
				printf("%s\n", sendBuffer);
			}
			cwnd *= 2;
		}
		else
		{
			if (slowstart && cwnd * 1024 >= threshold) {
				slowstart = false;
				cwnd = threshold / 1024;
			}
			printf("cwnd: %d\n", cwnd);
			for (int i = 0; i < cwnd; i++) {
				send(socketClient, sendBuffer, sizeof(sendBuffer), 0);
				printf("--------send---------\n");
				printf("%s\n", sendBuffer);
			}
			if (slowstart) {
				cwnd *= 2;
			}
			else
			{
				cwnd++;
			}
			
		}
		round++;
	}

	closesocket(socketClient);
	return;
}

int main() {
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	printf("server or client?[s/c]\n");
	char c = getchar();
	if (c == 's') {
		server();
	}
	else if (c == 'c') {
		client();
	}
	WSACleanup();
}