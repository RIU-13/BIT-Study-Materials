//
//  main.c
//  udpchecksum
//
//  Created by ziyantao on 2020/5/20.
//  Copyright © 2020 ziyantao. All rights reserved.
//

#include <stdio.h>
typedef unsigned char  INT8U;                   /* 无符号8位整型变量                        */
typedef unsigned short INT16U;                  /* 无符号16位整型变量                       */
typedef unsigned int   INT32U;                  /* 无符号32位整型变量                       */
INT8U sum[2]={0};           //两个保存校验和的全局变量
INT8U Info[30]={0};         //保存实际数据的全局变量
/*
*计算校验和的函数,传递过来的参数分别是:指向纯TCP报文的的指针data,指向本地IP的指针mIP,指向对方IP的指针yIP,实际要传送的数据长度 length
*该函数计算TCP校验和字段的实际填充信息,通过全局变量数组sum[2]返回.
*/
void checksum(INT8U *data,INT8U *mIP,INT8U *yIP,INT16U length)
{
    INT16U csum;
    INT16U i;
    INT32U dat[30]={0};             //保存TCP的的数组
    INT32U shu[30]={0};             //保存信息的数组
    INT16U temp;
    INT32U result,temp1,temp2,temp3,temp4=0,temp5=0;
  
    //将IP字段从数组中取出组合成新的数据
    temp1=((INT16U)mIP[0]<<8)+(INT16U)mIP[1]+((INT16U)mIP[2]<<8)+(INT16U)mIP[3];
    temp2=((INT16U)yIP[0]<<8)+(INT16U)yIP[1]+((INT16U)yIP[2]<<8)+(INT16U)yIP[3];
    //数据长度+协议类型
    temp3=(INT16U)(length)+0x06;
    for(i=0 ; i<length ; i++)
    {
        if(i%2==0)              //将偶数位左移放到高位
        {
            dat[i]=(INT16U)data[i]<<8;
            shu[i]=(INT16U)Info[i]<<8;
        }
        else                    //奇数位不变
        {
            dat[i]=(INT16U)data[i];
            shu[i]=(INT16U)Info[i];
        }
    }
    dat[16]=0x00;               //校验和字段初始置0
    dat[17]=0x00;
    for(i=0 ; i<length ; i++)
    {
        temp4=dat[i]+temp4;
        temp5=shu[i]+temp5;
    }
    result=temp1+temp2+temp3+temp4+temp5;
    if(result>0xffff)
    {
        temp=result/0xffff;//得到高位
        csum=(INT16U)result;//得到低位
        csum=0xffff-(csum+temp);
    }
    //将计算出来的数据和高位和低位分别放到数组对应字段中
    sum[0]=csum>>8;
    sum[1]=(INT8U)csum;
}
  
int main()
{
    INT8U length=20;
    INT8U i,j=0;
    INT8U info[30]={'a','b','c','d'};
    INT8U mIP[]={0x99,0x25,0xeb,0x2f};
    INT8U yIP[]={0xc0,0xa8,0x01,0x68};
    INT8U PSH_ACK[30]={0x14,0xA7,0xF4,0x82,0xF6,0xC2,0x16,0x62,0x3D,0xEA,//一个TCP数组
        0x6A,0x96,0x50,0x10,0x75,0x40,0x35,0x5F,0x00,0x00};
    for(i=0;i<30;i++)                                                //数据放到全局变量
        Info[i]=info[i];
    while(Info[j]!=0)
        j++; //获得实际信息的长度
    length=length+j;
    checksum(PSH_ACK,mIP,yIP,length);
    printf("psuedo head:\n");
    printf("source IP:");
    for(int i=0;i<4;i++){
        printf("0x%x ",mIP[i]);
    }
    printf("\n");
    printf("des IP:");
    for(int i=0;i<4;i++){
         printf("0x%x ",yIP[i]);
     }
     printf("\n");
    printf("mbz: 0\n");
    printf("protocol: 0x06\n");
    printf("length:0x%x\n",length);
    printf("TCP head:\n");
    for(int i=0;i<20;i++){
        printf("0x%x ",PSH_ACK[i]);
    }
    printf("\n");
    printf("checksum:0x%x%x\n",sum[0],sum[1]);
    return 0;
}
