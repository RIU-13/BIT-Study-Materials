#define _WINSOCK_DEPRECATED_NO_WARNINGS 1
#define _CRT_SECURE_NO_WARNINGS 1

#include <stdio.h>
#include <WinSock2.h>
#include <string.h>
#include <Windows.h>

#pragma comment(lib,"ws2_32.lib")

void server() {
	SOCKET socketSrv = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (socketSrv == SOCKET_ERROR) {
		printf("socket error\n");
		exit(0);
	}
	SOCKADDR_IN addrServer;
	addrServer.sin_port = htons(8888);
	addrServer.sin_family = AF_INET;
	addrServer.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	bind(socketSrv, (SOCKADDR*)&addrServer, sizeof(addrServer));

	SOCKADDR_IN addrClient;
	int lenClient = sizeof(addrClient);

	char recvBuff[100];

	int succ;
	succ = recvfrom(socketSrv, recvBuff, sizeof(recvBuff), 0, (SOCKADDR*)&addrClient, &lenClient);
	if (succ>=0) {
		printf("received: %s\n", recvBuff);
		for (int i = 0; i < strlen(recvBuff); i++) {
			if (recvBuff[i] <= 'z' && recvBuff[i] >= 'a') {
				recvBuff[i] -= 32;
			}
		}	
	}
	else
	{
		printf("receive failed\n");
	}

	sendto(socketSrv, recvBuff, sizeof(recvBuff), 0, (SOCKADDR*)&addrClient, lenClient);
	printf("send: %s\n", recvBuff);

	closesocket(socketSrv);

	return;
}

void client() {
	SOCKET socketClient = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	SOCKADDR_IN addrServer;
	addrServer.sin_family = AF_INET;
	addrServer.sin_port = htons(8888);
	addrServer.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	int lenServer = sizeof(addrServer);

	char sendBuffer[100];
	printf("input buffer to send: \n");
	scanf("%s", sendBuffer);

	sendto(socketClient, sendBuffer, sizeof(sendBuffer), 0, (SOCKADDR*)&addrServer, lenServer);
	printf("send: %s\n", sendBuffer);

	char recvBuffer[100];
	int succ = recvfrom(socketClient, recvBuffer, sizeof(recvBuffer), 0, (SOCKADDR*)&addrServer, &lenServer);
	if (succ >= 0) {
		printf("recv: %s\n", recvBuffer);
	}

	closesocket(socketClient);
	return;
}

int main() {
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	printf("server or client?[s/c]\n");
	int c = getchar();
	if (c == 's') {
		server();
	}
	else if (c == 'c') {
		client();
	}
	WSACleanup();
}