#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <process.h>
#include <string.h>
#include <conio.h>
#include "tchar.h"

void receivethread(HANDLE hCom);

int main(){
  HANDLE hCom;
  hCom = CreateFile(_T("COM2"),
                    GENERIC_READ | GENERIC_WRITE,
                    0,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
                    NULL);
  if(hCom == (HANDLE)-1){
    printf("open COM failed!\n");
    return FALSE;
  }
  else{
    printf("open succeeded!\n");
  }
  SetupComm(hCom, 1024, 1024);

  COMMTIMEOUTS TimeOuts;
  TimeOuts.ReadIntervalTimeout = 2;
  TimeOuts.ReadTotalTimeoutMultiplier = 0;
  TimeOuts.ReadTotalTimeoutConstant =0;
  TimeOuts.WriteTotalTimeoutMultiplier =500;
  TimeOuts.WriteTotalTimeoutConstant = 2000;
  SetCommTimeouts(hCom, &TimeOuts);

  DCB dcb1;
  GetCommState(hCom,&dcb1);
  dcb1.BaudRate = 115200;
  dcb1.ByteSize = 8;
  dcb1.Parity = NOPARITY;
  dcb1.StopBits = TWOSTOPBITS;
  dcb1.fParity = FALSE;
  dcb1.fNull = FALSE;
  SetCommState(hCom, &dcb1);
  PurgeComm(hCom, PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR|PURGE_TXABORT);

  HANDLE hthr;
  hthr = CreateThread(NULL,
                                0,
                                (LPTHREAD_START_ROUTINE)receivethread,
                                hCom,
                                CREATE_SUSPENDED,
                                NULL);
  if(hthr == 0){
    printf("create thread failed\n");
  }
  ResumeThread(hthr);

  DWORD wLen;
  DWORD wLenA;
  BOOL Status = FALSE;
  OVERLAPPED ovWrite;
  memset(&ovWrite,0,sizeof(ovWrite));
  ovWrite.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
  while(1){
    PurgeComm(hCom, PURGE_TXCLEAR|PURGE_TXABORT);
    char str[1024];
    memset(str, 0, 1024);
    printf("enter the text to send:\n");
    scanf("%s",str);
    wLen = strlen(str);
    Status = WriteFile(hCom,str,wLen,&wLenA,&ovWrite);
    if(Status == FALSE&&GetLastError()==ERROR_IO_PENDING){
      GetOverlappedResult(hCom,&ovWrite,&wLenA,TRUE);
    }
    printf("write COM succeeded!\n");
    printf("continue?[y/n]\n");
    char c;
    if((c = getch())=='n'){
      break;
    }else{
      continue;
    }
  }
  TerminateThread(hthr,0);
  CloseHandle(hthr);
  CloseHandle(hCom);
  return 0;
}

void receivethread(HANDLE hCom){
  OVERLAPPED ovRead;
  memset(&ovRead,0,sizeof(ovRead));
  ovRead.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

  DWORD rLenA = 0;
  BOOL Status = FALSE;
  char str[1024];
  DWORD Error;
  COMSTAT cs = {0};

  while(1){
    ClearCommError(hCom,&Error,&cs);
    memset(str,0,sizeof(str));
    Status = ReadFile(hCom,str,1024,&rLenA,&ovRead);
    if(Status == FALSE && GetLastError() == ERROR_IO_PENDING){
      Status = GetOverlappedResult(hCom,&ovRead,&rLenA,TRUE);
    }
    if(Status!=FALSE&&rLenA>0){
      printf("data received:\n");
      for(int i=0;i< rLenA;i++){
        printf("%c", str[i]);
      }
      printf("\n");
    }
    PurgeComm(hCom, PURGE_RXCLEAR|PURGE_RXABORT);
  }
  
  return;
}