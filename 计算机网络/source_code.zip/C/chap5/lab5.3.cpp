#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct ip
{
	int length;
	int id;
	int MF;
	int offset;
}ip;

int main(int argc, char** argv) 
{
	ip origin;
	ip frag[10];                //假定最多分十片
	int mtu,mtu_valid;
	int origin_len_valid;
	int frag_num; 
	
	printf("输入原始IP数据包信息\n");
	printf("长度:");
	scanf("%d",&origin.length);
	printf("ID:");
	scanf("%d",&origin.id);
	origin.MF=0;
	origin.offset=0;
	printf("输入MTU:");
	scanf("%d",&mtu);
	mtu_valid=(mtu-20)/8*8;   //必须以8字节为单位，最后可能有不满8字节的无法使用   ip头一律长20 
	if((origin.length-20)%mtu_valid==0)
	{
		frag_num=(origin.length-20)/mtu_valid;
	}
	else
	{
		frag_num=(origin.length-20)/mtu_valid+1;
	}
	origin_len_valid=origin.length-20;
	
	//分片 
	for(int i=0;i<frag_num;i++)
	{
		if(origin_len_valid>=mtu_valid)
		{
			frag[i].length=mtu_valid+20;
			frag[i].offset=i*mtu_valid/8;
			origin_len_valid-=mtu_valid;
		}
		else
		{
			frag[i].length=origin_len_valid+20;
			frag[i].offset=i*mtu_valid/8;
			origin_len_valid=0;
		}
		frag[i].id=origin.id;
		if(i!=frag_num-1)
		{
			frag[i].MF=1;
		}
		else
		{
			frag[i].MF=0;
		}	
	}
	
	printf("分片后\n");													//输出 
	printf("Fragnum=%d\n",frag_num); 
	printf("TotalLen=");
	for(int i=0;i<frag_num;i++)
	{
		printf("%d",frag[i].length);
		if(i!=frag_num-1)
			printf(",");
		else
			printf("\n");
	}
	printf("ID=");
	for(int i=0;i<frag_num;i++)
	{
		printf("%d",frag[i].id);
		if(i!=frag_num-1)
			printf(",");
		else
			printf("\n");
	}
	printf("MF=");
	for(int i=0;i<frag_num;i++)
	{
		printf("%d",frag[i].MF);
		if(i!=frag_num-1)
			printf(",");
		else
			printf("\n");
	}
	printf("offest=");
	for(int i=0;i<frag_num;i++)
	{
		printf("%d",frag[i].offset);
		if(i!=frag_num-1)
			printf(",");
		else
			printf("\n");
	}
	printf("\n");
	 
	//重装，此部分只能使用数组frag的信息 
	int totalLen=0,ID;
	for(int i=0;;i++)
	{
		totalLen+=frag[i].length-20;
		ID=frag[i].id;
		if(frag[i].MF==0)
			break;
	}
	totalLen+=20; 
	printf("重装后\n");
	printf("BigIPTotalLen=%d\n",totalLen);
	printf("ID=%d\n",ID);
	printf("MF=1\n");
	printf("offset=0\n");
	 
	return 0;
}
