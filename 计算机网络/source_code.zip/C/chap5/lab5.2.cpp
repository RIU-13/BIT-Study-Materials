#include <iostream>
#include <cstdio>
#include <cstdlib>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


#define MAX 99 
int pc[5][5] = {0, 2, 1, MAX, MAX,
                2, 0, 2, 3, MAX,
                1, 2, 0, 3, 1,
                MAX, 3, 3, 0, 1,
                MAX, MAX, 1, 1, 0};

void initial()
{
    /*int i,j;
    for(i=0;i<5;i++)
    {
    	for(j=0;j<5;j++)
    	{
    		scanf("%d",&a[i][j]);
		}
	}*/
}


void routerLS(int s)
{ //sΪ��ʼ�� 
    int flag[5];    //N'
    int d[5];       //���� 
    int next[5];    //��һ�� 
    for(int i = 0; i < 5; i++)
	{ 
	   	d[i] = pc[s][i];	   	
    	flag[i] = 0;
    	next[i] = i;
	} 
	flag[s] = 1;
	int k = s, min;  
	for(int i = 0; i < 5; i++)
	{
		min = MAX;
		for(int j = 0; j < 5; j++)   //�ҳ���Сֵd[k]
		{ 
			if(d[j] < min && flag[j] == 0)
			{
				min = d[j];
				k = j;
			}
		}
		if(k == s)  //k����˵��û���ھ� 	        
		   break ;
		flag[k] = 1;
		for(int j = 0; j < 5; j++)  	//�����ڱ�
		{ 
			if(d[j] > d[k] + pc[k][j] && flag[j] == 0)
			{
				d[j] = d[k] + pc[k][j];
				next[j] = next[k];
			}
		}
		printf("the shortest path from %dth router to others is:\n",s);
		for(int n=0;n<5;n++)
		{
			if(flag[n]==1)
				printf("%d ",d[n]);
			if(flag[n]==0)
				printf("99 ");
		}
		printf("\n");
	}
	printf("the final routing table of %dth router:\n",s);
	printf("Destination    Cost    Next hoop\n");
	for(int i=0;i<5;i++)
	{
		printf("%d   		 %d 	   %d",i,d[i],next[i]);
		printf("\n");
	}
}


int main(int argc, char** argv) 
{
	initial();
	int i,j;
	for(i=0;i<5;i++)
	{
		printf("the initial link state of %dth router:",i);
		for(j=0;j<5;j++)
		{
			printf("%d ",pc[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<5;i++)
	{
			routerLS(i);
	}
	return 0;
}
