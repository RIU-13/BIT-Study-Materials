#include "pch.h"
#include <signal.h>
#include "pcap.h"

//��̫��Э��ͷ
struct ether_header
{
	u_int8_t ether_dhost[6]; //Ŀ��MAC��ַ
	u_int8_t ether_shost[6]; //ԴMAC��ַ
	u_int16_t ether_type;    //Э������
};

//IPv4Э��ͷ
struct ip_header
{
#if defined(WORDS_BIENDIAN)
	u_int8_t    ip_version : 4, ip_header_length : 4;
#else
	u_int8_t    ip_header_length : 4, ip_version : 4;
#endif
	u_int8_t    ip_tos;
	u_int16_t   ip_length;
	u_int16_t   ip_id;
	u_int16_t   ip_off;
	u_int8_t    ip_ttl;
	u_int8_t    ip_protocol;
	u_int16_t   ip_checksum;
	struct in_addr ip_souce_address;
	struct in_addr ip_destination_address;
};

//TCPЭ��ͷ
#define __LITTLE_ENDIAN_BITFIELD
struct tcphdr
{
	u_int16_t   source_port;         /*Դ��ַ�˿�*/
	u_int16_t   dest_port;           /*Ŀ�ĵ�ַ�˿�*/
	u_int32_t   seq;            /*���к�*/
	u_int32_t   ack_seq;        /*ȷ�����к�*/

#if defined(__LITTLE_ENDIAN_BITFIELD)
	u_int16_t res1 : 4,   /*����*/
		doff : 4,				/*ƫ��*/
		fin : 1,              /*�ر����ӱ�־*/
		syn : 1,              /*�������ӱ�־*/
		rst : 1,              /*�������ӱ�־*/
		psh : 1,              /*���շ����콫���ݷŵ�Ӧ�ò��־*/
		ack : 1,              /*ȷ����ű�־*/
		urg : 1,              /*����ָ���־*/
		ece : 1,              /*ӵ����־λ*/
		cwr : 1;              /*ӵ����־λ*/

#elif defined(__BIG_ENDIAN_BITFIELD)
	u_int16_t doff : 4,   /*ƫ��*/
		res1 : 4,             /*����*/
		cwr : 1,              /*ӵ����־λ*/
		ece : 1,              /*ӵ����־λ*/
		urg : 1,              /*����ָ���־*/
		ack : 1,              /*ȷ����ű�־*/
		psh : 1,              /*���շ����콫���ݷŵ�Ӧ�ò��־*/
		rst : 1,              /*�������ӱ�־*/
		syn : 1,              /*�������ӱ�־*/
		fin : 1;              /*�ر����ӱ�־*/
#else
	u_int16_t	flag;
#endif 
	u_int16_t   window;         /*�������ڴ�С*/
	u_int16_t   check;          /*У���*/
	u_int16_t   urg_ptr;        /*�����ֶ�ָ��*/
};

/* Storage data structure used to pass parameters to the threads */
typedef struct _in_out_adapters
{
	unsigned int state;		/* Some simple state information */
	pcap_t *input_adapter;
	pcap_t *output_adapter;
}in_out_adapters;

/* Prototypes */
DWORD WINAPI CaptureAndForwardThread(LPVOID lpParameter);
void ctrlc_handler(int sig);

/* �ٽ��� */
CRITICAL_SECTION print_cs;

/* Thread handlers. Global because we wait on the threads from the CTRL+C handler */
HANDLE threads[2];

/* This global variable tells the forwarder threads they must terminate */
volatile int kill_forwaders = 0;

//ȫ�ֱ���
pcap_if_t *alldevs;
int inum1, inum2;
pcap_t *adhandle1, *adhandle2;
struct nat_table_item
{
	struct in_addr inside_ip;
	struct in_addr outside_ip;
	u_int16_t inside_port;
	u_int16_t outside_port;
};
struct nat_table_item nat_table[10];
int table_size = 0;

/*У��ͼ���*/
USHORT checksumCalulator(USHORT* buffer, int size)
{
	unsigned long cksum = 0;
	while (size > 1)
	{
		cksum += *buffer++;
		size -= sizeof(USHORT);
	}
	if (size)
	{
		cksum += *(UCHAR*)buffer;
	}
	cksum = (cksum >> 16) + (cksum & 0xffff);
	cksum += (cksum >> 16);
	return (USHORT)(~cksum);
}


/*******************************************************************/

int main()
{
	pcap_if_t *d;
	int i = 0;
	char errbuf[PCAP_ERRBUF_SIZE];
	u_int netmask1, netmask2;
	char packet_filter[256];
	struct bpf_program fcode;
	in_out_adapters couple0, couple1;

	/*
	 * Retrieve the device list
	 */

	if (pcap_findalldevs_ex((char*)PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
	{
		fprintf(stderr, "Error in pcap_findalldevs: %s\n", errbuf);
		exit(1);
	}

	/* Print the list */
	for (d = alldevs; d; d = d->next)
	{
		printf("%d. ", ++i);
		if (d->description)
			printf("%s\n", d->description);
		else
			printf("<unknown adapter>\n");
	}

	if (i == 0)
	{
		printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
		return -1;
	}


	/*
	 * Get input from the user
	 */

	 /* Get the filter*/
	printf("\nSpecify filter (hit return for no filter):");

	fgets(packet_filter, sizeof(packet_filter), stdin);

	/* Get the first interface number*/
	printf("\nEnter the number of the first interface to use (1-%d):", i);
	scanf_s("%d", &inum1);

	if (inum1 < 1 || inum1 > i)
	{
		printf("\nInterface number out of range.\n");
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/* Get the second interface number*/
	printf("Enter the number of the second interface to use (1-%d):", i);
	scanf_s("%d", &inum2);

	if (inum2 < 1 || inum2 > i)
	{
		printf("\nInterface number out of range.\n");
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	if (inum1 == inum2)
	{
		printf("\nCannot bridge packets on the same interface.\n");
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}


	/*
	 * Open the specified couple of adapters
	 */

	 /* Jump to the first selected adapter */
	for (d = alldevs, i = 0; i < inum1 - 1;d = d->next, i++);

	/*
	 * Open the first adapter.
	 * *NOTICE* the flags we are using, they are important for the behavior of the prgram:
	 *	- PCAP_OPENFLAG_PROMISCUOUS: tells the adapter to go in promiscuous mode.
	 *    This means that we are capturing all the traffic, not only the one to or from
	 *    this machine.
	 *	- PCAP_OPENFLAG_NOCAPTURE_LOCAL: prevents the adapter from capturing again the packets
	 *	  transmitted by itself. This avoids annoying loops.
	 *	- PCAP_OPENFLAG_MAX_RESPONSIVENESS: configures the adapter to provide minimum latency,
	 *	  at the cost of higher CPU usage.
	 */
	if ((adhandle1 = pcap_open(d->name,						// name of the device
		65536,							// portion of the packet to capture. 
									   // 65536 grants that the whole packet will be captured on every link layer.
		PCAP_OPENFLAG_PROMISCUOUS |	// flags. We specify that we don't want to capture loopback packets, and that the driver should deliver us the packets as fast as possible
		PCAP_OPENFLAG_NOCAPTURE_LOCAL |
		PCAP_OPENFLAG_MAX_RESPONSIVENESS,
		500,							// read timeout
		NULL,							// remote authentication
		errbuf							// error buffer
	)) == NULL)
	{
		fprintf(stderr, "\nUnable to open the adapter. %s is not supported by WinPcap\n", d->description);
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	if (d->addresses != NULL)
	{
		/* Retrieve the mask of the first address of the interface */
		netmask1 = ((struct sockaddr_in *)(d->addresses->netmask))->sin_addr.S_un.S_addr;
	}
	else
	{
		/* If the interface is without addresses we suppose to be in a C class network */
		netmask1 = 0xffffff;
	}

	/* Jump to the second selected adapter */
	for (d = alldevs, i = 0; i < inum2 - 1;d = d->next, i++);

	/* Open the second adapter */
	if ((adhandle2 = pcap_open(d->name,						// name of the device
		65536,							// portion of the packet to capture. 
									   // 65536 grants that the whole packet will be captured on every link layer.
		PCAP_OPENFLAG_PROMISCUOUS |	// flags. We specify that we don't want to capture loopback packets, and that the driver should deliver us the packets as fast as possible
		PCAP_OPENFLAG_NOCAPTURE_LOCAL |
		PCAP_OPENFLAG_MAX_RESPONSIVENESS,
		500,							// read timeout
		NULL,							// remote authentication
		errbuf							// error buffer
	)) == NULL)
	{
		fprintf(stderr, "\nUnable to open the adapter. %s is not supported by WinPcap\n", d->description);
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	if (d->addresses != NULL)
	{
		/* Retrieve the mask of the first address of the interface */
		netmask2 = ((struct sockaddr_in *)(d->addresses->netmask))->sin_addr.S_un.S_addr;
	}
	else
	{
		/* If the interface is without addresses we suppose to be in a C class network */
		netmask2 = 0xffffff;
	}


	/*
	 * Compile and set the filters
	 */

	 /* compile the filter for the first adapter */
	if (pcap_compile(adhandle1, &fcode, packet_filter, 1, netmask1) < 0)
	{
		fprintf(stderr, "\nUnable to compile the packet filter. Check the syntax.\n");

		/* Close the adapters */
		pcap_close(adhandle1);
		pcap_close(adhandle2);

		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/* set the filter for the first adapter*/
	if (pcap_setfilter(adhandle1, &fcode) < 0)
	{
		fprintf(stderr, "\nError setting the filter.\n");

		/* Close the adapters */
		pcap_close(adhandle1);
		pcap_close(adhandle2);

		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/* compile the filter for the second adapter */
	if (pcap_compile(adhandle2, &fcode, packet_filter, 1, netmask2) < 0)
	{
		fprintf(stderr, "\nUnable to compile the packet filter. Check the syntax.\n");

		/* Close the adapters */
		pcap_close(adhandle1);
		pcap_close(adhandle2);

		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/* set the filter for the second adapter*/
	if (pcap_setfilter(adhandle2, &fcode) < 0)
	{
		fprintf(stderr, "\nError setting the filter.\n");

		/* Close the adapters */
		pcap_close(adhandle1);
		pcap_close(adhandle2);

		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/* At this point, we don't need the device list any more. Free it */
	//pcap_freealldevs(alldevs);                                       //��ط���ȥ����

	/*
	 * Start the threads that will forward the packets
	 */

	 /* Initialize the critical section that will be used by the threads for console output */
	InitializeCriticalSection(&print_cs);

	/* Init input parameters of the threads */
	couple0.state = 0;
	couple0.input_adapter = adhandle1;
	couple0.output_adapter = adhandle2;
	couple1.state = 1;
	couple1.input_adapter = adhandle2;
	couple1.output_adapter = adhandle1;

	

	/* Start second thread */
	if ((threads[1] = CreateThread(
		NULL,
		0,
		CaptureAndForwardThread,
		&couple1,
		0,
		NULL)) == NULL)
	{
		fprintf(stderr, "error creating the second forward thread");

		/* Kill the first thread. Not very gentle at all...*/
		TerminateThread(threads[0], 0);

		/* Close the adapters */
		pcap_close(adhandle1);
		pcap_close(adhandle2);

		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}

	/*
	 * Install a CTRL+C handler that will do the cleanups on exit
	 */
	signal(SIGINT, ctrlc_handler);

	/*
	 * Done!
	 * Wait for the Greek calends...
	 */
	printf("\nStart bridging the two adapters...\n", d->description);
	Sleep(INFINITE);
	return 0;
}

/*******************************************************************
 * Forwarding thread.
 * Gets the packets from the input adapter and sends them to the output one.
 *******************************************************************/
DWORD WINAPI CaptureAndForwardThread(LPVOID lpParameter)
{
	struct pcap_pkthdr *header;
	const u_char *pkt_data;
	int res = 0;
	in_out_adapters* ad_couple = (in_out_adapters*)lpParameter;
	unsigned int n_fwd = 0;

	/*
	 * Loop receiving packets from the first input adapter
	 */

	while ((!kill_forwaders) && (res = pcap_next_ex(ad_couple->input_adapter, &header, &pkt_data)) >= 0)
	{
		if (res != 0)	/* Note: res=0 means "read timeout elapsed"*/
		{
			/*
			 * Print something, just to show when we have activity.
			 * BEWARE: acquiring a critical section and printing strings with printf
			 * is something inefficient that you seriously want to avoid in your packet loop!
			 * However, since this is a *sample program*, we privilege visual output to efficiency.
			 */

			EnterCriticalSection(&print_cs);

			struct ether_header* ethernet_protocol = (struct ether_header*)pkt_data;//������ݰ�����
			u_short ethernet_type = ntohs(ethernet_protocol->ether_type);//�����̫������
			u_char *in_string;
			u_char *out_string;
			in_string = ethernet_protocol->ether_shost;
			out_string = ethernet_protocol->ether_dhost;
			pcap_if_t *d;
			int i;
			for (d = alldevs, i = 0; i < inum1 - 1;d = d->next, i++);
			printf("Captured a package from %s\n", d->description);
			printf("MACԴ��ַ:%02x:%02x:%02x:%02x:%02x:%02x\n", *in_string, *(in_string + 1), *(in_string + 2), *(in_string + 3), *(in_string + 4), *(in_string + 5));
			printf("MACĿ�ĵ�ַ:%02x:%02x:%02x:%02x:%02x:%02x\n", *out_string, *(out_string + 1), *(out_string + 2), *(out_string + 3), *(out_string + 4), *(out_string + 5));
			for (int i = 0;i < 6;i++)
			{
				*(in_string + i) = 11;                  //outside mac��ַ��Ϊ11:11:11:11:11:11 
			}
			if (ethernet_type == 0x0800)//��������IPЭ��
			{
				struct ip_header *ip_protocol;
				u_int header_length = 0;
				u_int16_t checksum;
				struct tcphdr *tcp_protocol;
				int origin_source_port;
				int dest_port;

				ip_protocol = (struct ip_header *)(pkt_data + sizeof(ether_header));
				tcp_protocol = (struct tcphdr*)(pkt_data + sizeof(ip_header));

				header_length = ip_protocol->ip_header_length;
				checksum = ntohs(ip_protocol->ip_checksum);
				printf("---------ԭЭ��---------\n");
				printf("�����:%d\n", checksum);
				printf("ԴIP��ַ:%s\n", inet_ntoa(ip_protocol->ip_souce_address));
				printf("Ŀ�ĵ�ַ:%s\n", inet_ntoa(ip_protocol->ip_destination_address));
				//filter��Ҫ����tcp
				if (ip_protocol->ip_protocol == 6)         //����tcpЭ��
				{
					origin_source_port = ntohs(tcp_protocol->source_port);
					dest_port = ntohs(tcp_protocol->dest_port);
					printf("Դ�˿�:%d\n", origin_source_port);
					printf("Ŀ�Ķ˿�:%d\n", dest_port);
				}

				int flag;
				int position;
				for (i = 0, flag = 0;i < table_size;i++)
				{
					if (ip_protocol->ip_souce_address.S_un.S_addr == nat_table[i].inside_ip.S_un.S_addr&&origin_source_port == nat_table[i].inside_port)
					{
						flag = 1;
						position = i;
					}
				}
				if (flag == 1)                    //nat�����Ѵ���ԭip��ַ��ֱ�Ӹ�ץ���İ� 
				{
					memcpy(&ip_protocol->ip_souce_address, &nat_table[position].outside_ip, 4);
					tcp_protocol->source_port = htons(nat_table[position].outside_port);
					printf("��ǰNAT��Ϊ��\n");
					printf("inside IP	  inside port	 outside IP		outside port\n");
					for (i = 0;i < table_size;i++)
					{
						printf("%s		", inet_ntoa(nat_table[i].inside_ip));
						printf("%d		", nat_table[i].inside_port);
						printf("%s		", inet_ntoa(nat_table[i].outside_ip));
						printf("%d		\n", nat_table[i].outside_port);
					}
				}
				if (flag == 0)                 //nat���в�����ԭip��ַ����������֮���ץ���İ� 
				{
					nat_table[table_size].inside_ip = ip_protocol->ip_souce_address;
					nat_table[table_size].inside_port = ntohs(tcp_protocol->source_port);
					printf("NAT����û����һԭ��ַ�������룺");
					char ip[16];
					u_long tmp_ip_num;
					scanf("%s%d", ip, &nat_table[table_size].outside_port);             //�� nat�������� 
					tmp_ip_num = inet_addr(ip);
					memcpy(&nat_table[table_size].outside_ip, &tmp_ip_num, 4);
					
					memcpy(&ip_protocol->ip_souce_address, &nat_table[table_size].outside_ip, 4);   //��ץ���İ� 
					tcp_protocol->source_port = htons(nat_table[table_size].outside_port);

					table_size++;

					printf("��ǰNAT��Ϊ��\n");
					printf("inside IP	  inside port	 outside IP		outside port\n");
					for (i = 0;i < table_size;i++)
					{
						printf("%s		", inet_ntoa(nat_table[i].inside_ip));
						printf("%d		", nat_table[i].inside_port);
						printf("%s		", inet_ntoa(nat_table[i].outside_ip));
						printf("%d		\n", nat_table[i].outside_port);
					}
				}

				ip_protocol->ip_checksum = 0;
				USHORT newChecksum = checksumCalulator((USHORT*)ip_protocol, header_length * 4);
				ip_protocol->ip_checksum = newChecksum;                       //������У��� 

				printf("---------��Э��---------\n");
				printf("�����:%d\n", ip_protocol->ip_checksum);
				printf("ԴIP��ַ:%s\n", inet_ntoa(ip_protocol->ip_souce_address));
				printf("Ŀ�ĵ�ַ:%s\n", inet_ntoa(ip_protocol->ip_destination_address));
				printf("Դ�˿�:%d\n", ntohs(tcp_protocol->source_port));
				printf("Ŀ�Ķ˿�:%d\n\n", ntohs(tcp_protocol->dest_port));
			}
			


			LeaveCriticalSection(&print_cs);

			/*
			 * Send the just received packet to the output adaper
			 */
			if (pcap_sendpacket(ad_couple->output_adapter, pkt_data, header->caplen) != 0)
			{
				EnterCriticalSection(&print_cs);

				printf("Error sending a %u bytes packets on interface %u: %s\n",
					header->caplen,
					ad_couple->state,
					pcap_geterr(ad_couple->output_adapter));
				printf("the packet will be dropped\n");

				LeaveCriticalSection(&print_cs);
			}
			else
			{
				n_fwd++;
			}
		}
	}

	/*
	 * We're out of the main loop. Check the reason.
	 */
	if (res < 0)
	{
		EnterCriticalSection(&print_cs);

		printf("Error capturing the packets: %s\n", pcap_geterr(ad_couple->input_adapter));
		fflush(stdout);

		LeaveCriticalSection(&print_cs);
	}
	else
	{
		EnterCriticalSection(&print_cs);

		printf("End of bridging on interface %u. Forwarded packets:%u\n",
			ad_couple->state,
			n_fwd);
		fflush(stdout);

		LeaveCriticalSection(&print_cs);
	}

	return 0;
}

/*******************************************************************
 * CTRL+C hanlder.
 * We order the threads to die and then we patiently wait for their
 * suicide.
 *******************************************************************/
void ctrlc_handler(int sig)
{
	/*
	 * unused variable
	 */
	(VOID)(sig);

	kill_forwaders = 1;

	WaitForMultipleObjects(2,
		threads,
		TRUE,		/* Wait for all the handles */
		5000);		/* Timeout */

	exit(0);
}
