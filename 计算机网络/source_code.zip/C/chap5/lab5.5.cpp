#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring> 

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

typedef struct route_item
{
	int ip1,ip2,ip3,ip4;
	unsigned int ip;
	int netmask;
	char nexthoop[20];
}route_item;

int main(int argc, char** argv) 
{
	int line=0;
	route_item route_table[10];                //·�ɱ���󳤶���Ϊ10
	int ip1,ip2,ip3,ip4;
	
	FILE *f;
	char c;
	f=fopen("config.txt","r");
	while((c=fgetc(f))!=EOF)
	{
		if(c=='\n')
			line++;
	}
	fclose(f);
	
	f=fopen("config.txt","r");
	for(int i=0;i<line;i++)
	{
		if(i<line-1)
		{
			fscanf(f,"%d.%d.%d.%d/%d  ",&route_table[i].ip1,&route_table[i].ip2,&route_table[i].ip3,&route_table[i].ip4,&route_table[i].netmask);
			fgets(route_table[i].nexthoop,20,f);
		}
		if(i==line-1)
		{
			for(int j=5;j>0;j--)
			{
				fgetc(f);
			}
			fgets(route_table[line-1].nexthoop,20,f);
			route_table[line-1].ip=0;
			route_table[line-1].netmask=0;
		}	
	}
	
	printf("����ip��ַ��");
	scanf("%d.%d.%d.%d",&ip1,&ip2,&ip3,&ip4);
	printf("\n");
	
	printf("��ǰ·�ɱ�Ϊ��\n"); 
	for(int i=0;i<line-1;i++)
	{
		printf("%d.%d.%d.%d/%d  ",route_table[i].ip1,route_table[i].ip2,route_table[i].ip3,route_table[i].ip4,route_table[i].netmask);
		puts(route_table[i].nexthoop);
	}
	printf("0/0  ");
	puts(route_table[line-1].nexthoop);
	printf("\n");
	
	unsigned int ip;
	unsigned int tmp;
	int num=-1;
	int cur_netmask=0;
	ip=(ip1<<24)+(ip2<<16)+(ip3<<8)+ip4;
	for(int i=0;i<line-1;i++)
	{
		route_table[i].ip=(route_table[i].ip1<<24)+(route_table[i].ip2<<16)+(route_table[i].ip3<<8)+route_table[i].ip4;
		tmp=(ip>>(32-route_table[i].netmask))^(route_table[i].ip>>(32-route_table[i].netmask));
		if(tmp==0&&route_table[i].netmask>cur_netmask)
		{
			num=i;
			cur_netmask=route_table[i].netmask;
			printf("��%d��·��ƥ��\n",i+1);
		}
		if(tmp!=0)
		{
			printf("��%d��·�ɲ�ƥ��\n",i+1);
		}
	}
	if(num!=-1)
	{
		printf("��һ��Ϊ��");
		puts(route_table[num].nexthoop);
	}
	if(num==-1)
	{
		printf("û��ƥ�䣬��Ĭ��·�ɷ��ͣ���һ��Ϊ��");
		puts(route_table[line-1].nexthoop);
	}
	
	return 0;
}
