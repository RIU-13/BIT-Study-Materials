

#先运行createFile，生成文件

#运行sender.py

#运行receiver.py