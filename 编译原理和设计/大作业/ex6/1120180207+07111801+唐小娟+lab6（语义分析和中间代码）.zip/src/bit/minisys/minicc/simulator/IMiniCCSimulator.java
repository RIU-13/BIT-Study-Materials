package bit.minisys.minicc.simulator;

public interface IMiniCCSimulator {
	/*
	 * @param input input file path
	 */
	public void run(String input) throws Exception;
}
